@echo off
title Merge LoRA - VieNeu-TTS
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo =========================================================
echo.
echo    MERGE LORA VAO MODEL GOC
echo.
echo =========================================================
echo.
echo [!] Qua trinh nay se ghep LoRA adapter vao model goc.
echo     Co the mat 5-10 phut. Vui long khong tat cua so nay!
echo.

set BASE_MODEL=pnnbao-ump/VieNeu-TTS-0.3B
set ADAPTER_PATH=finetune\output\VieNeu-TTS-0.3B-LoRA
set OUTPUT_PATH=finetune\output\VieNeu-TTS-0.3B-Merged

if not exist "%ADAPTER_PATH%\adapter_config.json" (
    echo [!] Khong tim thay LoRA adapter tai: %ADAPTER_PATH%
    echo     Vui long chay run_finetune.bat truoc!
    pause
    exit
)

call .venv\Scripts\activate.bat

echo.
echo [1/2] Dang merge LoRA weights vao model goc...
echo.
python finetune/merge_lora.py ^
    --base_model "%BASE_MODEL%" ^
    --adapter "%ADAPTER_PATH%" ^
    --output "%OUTPUT_PATH%"

if errorlevel 1 (
    echo.
    echo [!] Da co loi xay ra khi merge! Kiem tra log o tren.
    pause
    exit
)

echo.
echo [2/2] Dang cap nhat config.yaml...
python -c "
import yaml, os

config_path = 'config.yaml'
with open(config_path, 'r', encoding='utf-8') as f:
    content = f.read()

new_entry = '''  \"VieNeu-TTS-Custom (Fine-tuned)\":
    repo: finetune/output/VieNeu-TTS-0.3B-Merged
    supports_streaming: false
    description: \"Model da duoc fine-tune voi giong noi cua ban\"
'''

if 'VieNeu-TTS-Custom' not in content:
    # Chen vao sau dong backbone_configs:
    content = content.replace('backbone_configs:\n', 'backbone_configs:\n' + new_entry)
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print('Da them model vao config.yaml!')
else:
    print('Model da co san trong config.yaml.')
"

echo.
echo =========================================================
echo    HOAN TAT!
echo.
echo    Model da duoc luu tai: %OUTPUT_PATH%
echo    Ban co the chay run.bat va chon:
echo    "VieNeu-TTS-Custom (Fine-tuned)" de dung model moi!
echo =========================================================
echo.
pause
exit
