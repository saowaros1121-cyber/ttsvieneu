# Primary goal

Bản VieNeu-TTS đang dùng nhận đầy đủ lõi suy luận 3.8.3 từ bản v0.18.12, đồng thời tiếp tục xử lý TXT hàng loạt, tự cắt câu, đặt tên audio theo TXT và xuất vào thư mục người dùng chọn.

## Phase 0: Xác định nguồn nâng cấp

**How this serves the primary goal:** Chỉ lấy API và mẫu triển khai có thật từ bản mới, tránh ghép nhầm hoặc làm mất chức năng riêng.

- Nguồn chuẩn: `src/vieneu`, `src/vieneu_utils`, `apps`, `tests`, `finetune`, `pyproject.toml`, `uv.lock` trong thư mục v0.18.12.
- API được phép: các class/hàm/signature có sẵn trong chính bản 3.8.3; không tự đặt thêm tham số cho engine.
- Giữ nguyên: `apps/batch_files.py`, `apps/text_processing.py`, `tests/test_batch_txt.py`, dữ liệu và output huấn luyện hiện có.
- Kiểm tra: lập danh sách file mới, file đổi và file chỉ có ở bản hiện tại.
- Tránh: chép đè toàn bộ thư mục hiện tại hoặc xóa file không có trong bản mới.

## Phase 1: Sao lưu và thay lõi

**How this serves the primary goal:** Cho phép khôi phục nhanh nếu một backend hoặc model cũ không tương thích.

- Sao lưu mọi file sắp thay vào thư mục `backups/core-before-3.8.3-*`.
- Chép các module lõi 3.8.3 từ `src/vieneu` và `src/vieneu_utils`, gồm chống lặp, giới hạn frame, retry chống babble, fused/streaming và v3 Nano.
- Kiểm tra: so hash nguồn mới với file đích và biên dịch toàn bộ module Python.
- Tránh: sao chép `__pycache__`, `.pyc` và xóa asset hiện có.

## Phase 2: Ghép ứng dụng và tính năng riêng

**How this serves the primary goal:** Người dùng nhận các API/SRT/voice mới mà luồng TXT hàng loạt vẫn chạy như trước.

- Thêm các app mới `openai_speech.py`, `srt_speech.py`, `user_voices.py` và cập nhật streaming.
- Ghép thay đổi 3.8.3 vào Gradio theo API thật, giữ nguyên xử lý TXT hàng loạt, tự cắt câu, tên output và thư mục xuất.
- Giữ mặc định tốc độ đã chọn: đoạn 256 ký tự, temperature 0.6, batch bật, batch size 8.
- Kiểm tra: import app, kiểm tra callback và chạy test batch TXT.
- Tránh: thay `gradio_main.py` nguyên file nếu làm mất custom batch.

## Phase 3: Cấu hình, phụ thuộc và LoRA

**How this serves the primary goal:** Lõi mới có đúng thư viện, model và công cụ huấn luyện mà nó yêu cầu.

- Cập nhật metadata/phụ thuộc 3.8.3, lock file và các module LoRA mới; giữ dataset/checkpoint của người dùng.
- Ghép cấu hình model mới nhưng bảo toàn thiết lập tốc độ/chất lượng hiện tại.
- Kiểm tra: xác nhận phiên bản package, dependency import và parse cấu hình.
- Tránh: xóa môi trường ảo hoặc tải lại model không cần thiết.

## Phase 4: Verification

**How this serves the primary goal:** Chứng minh lõi mới và luồng TXT hàng loạt cùng hoạt động trước khi bàn giao.

- Chạy compile, test anti-babble, repetition history, Nano, serve guards, API/SRT/user voices và batch TXT.
- Chạy smoke import cho UI và engine; rà soát đường dẫn output ngoài workspace.
- Kiểm tra không còn import/API cũ xung đột và ghi lại các kiểm tra không thể chạy do thiếu GPU/model.
