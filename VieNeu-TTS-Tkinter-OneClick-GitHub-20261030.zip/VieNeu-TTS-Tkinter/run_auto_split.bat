@echo off
title Auto Split Audio (Whisper)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo =========================================================
echo.
echo    TU DONG TACH CAU VA NHAN DIEN GIONG NOI
echo.
echo =========================================================
echo.
echo Vui long keo tha file am thanh goc (1 file dai) vao cua so nay roi an Enter.
echo (Hoac danh duong dan den file am thanh do, vi du: C:\Users\Admin\Desktop\audio.wav)
echo.
set /p AUDIO_FILE="Duong dan file am thanh: "

:: Xóa dấu ngoặc kép nếu người dùng kéo thả có dấu ngoặc kép
set AUDIO_FILE=%AUDIO_FILE:"=%

if not exist "%AUDIO_FILE%" (
    echo [!] Khong tim thay file: "%AUDIO_FILE%"
    pause
    exit
)

call .venv\Scripts\activate.bat

echo.
echo Dang chay qua trinh tu dong... Vui long doi. 
echo Phan mem se dung Card Do Hoa (GPU) de nhan dien giong noi nen se rat nhanh.
echo.
python finetune/data_scripts/auto_split.py "%AUDIO_FILE%" --model large-v3 --lang vi

echo.
echo =========================================================
echo DA XONG!
echo Ban co the kiem tra tai thu muc finetune/dataset/
echo =========================================================
pause
exit
