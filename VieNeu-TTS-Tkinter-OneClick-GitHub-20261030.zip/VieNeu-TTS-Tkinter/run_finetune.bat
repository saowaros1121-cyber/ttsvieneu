@echo off
title VieNeu-TTS Finetuning
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo =========================================================
echo.
echo    QUY TRINH HUAN LUYEN (FINE-TUNE) VieNeu-TTS
echo.
echo =========================================================
echo.

if not exist "finetune\dataset\metadata.csv" (
    echo [!] Khong tim thay file metadata.csv trong finetune\dataset\
    echo [!] Vui long chuan bi du lieu theo huong dan truoc khi chay.
    echo.
    echo Bam phim bat ky de chay thu script tai du lieu mau tu HuggingFace...
    pause
    call .venv\Scripts\activate.bat
    python finetune/data_scripts/get_hf_sample.py
    echo.
)

call .venv\Scripts\activate.bat

echo [Bước 1] Loc du lieu (filter_data.py)...
python finetune/data_scripts/filter_data.py
if %ERRORLEVEL% neq 0 goto ERROR_HANDLER

echo.
echo [Bước 2] Ma hoa am thanh (encode_data.py)...
python finetune/data_scripts/encode_data.py
if %ERRORLEVEL% neq 0 goto ERROR_HANDLER

echo.
echo [Bước 3] Bat dau huan luyen (train.py)...
python finetune/train.py
if %ERRORLEVEL% neq 0 goto ERROR_HANDLER

echo.
echo =========================================================
echo    HUAN LUYEN HOAN TAT THANG CONG!
echo    Model duoc luu tai thu muc finetune/output/
echo =========================================================
pause
exit

:ERROR_HANDLER
echo.
echo [!] Da co loi xay ra trong qua trinh chay script. Vui long kiem tra lai log o tren.
pause
exit
