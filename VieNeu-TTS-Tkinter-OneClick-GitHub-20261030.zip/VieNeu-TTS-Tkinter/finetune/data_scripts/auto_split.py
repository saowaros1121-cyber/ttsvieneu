import os
import argparse
import torch
import torchaudio
import torchaudio.functional as F
import whisper
from tqdm import tqdm

def process_audio(input_file, model_size="large-v3", language="vi", pad_sec=0.2):
    print(f"Đang tải file âm thanh: {input_file}...")
    orig_waveform, orig_sample_rate = torchaudio.load(input_file)
    duration = orig_waveform.shape[1] / orig_sample_rate
    
    # Chuyển về mono nếu là stereo
    if orig_waveform.shape[0] > 1:
        waveform = orig_waveform.mean(dim=0, keepdim=True)
    else:
        waveform = orig_waveform
        
    # Resample về 16kHz cho Whisper
    if orig_sample_rate != 16000:
        waveform_16k = F.resample(waveform, orig_sample_rate, 16000)
    else:
        waveform_16k = waveform
        
    audio_np = waveform_16k.squeeze().numpy()
    
    print(f"Đang tải mô hình Whisper ({model_size})... Có thể mất một chút thời gian ở lần đầu tiên.")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = whisper.load_model(model_size, device=device)
    
    print(f"Bắt đầu nhận diện và tách câu (Sử dụng {device.upper()})...")
    print(f"   ⏱️  File dài {duration:.1f}s — sẽ mất khoảng {int(duration/60*0.4 + 1)} phút với model '{model_size}'")
    # Dùng beam_size=1 (greedy) để tăng tốc gấp đôi, vẫn chính xác với tiếng Việt
    result = model.transcribe(
        audio_np,
        language=language,
        beam_size=1,           # Greedy decode — nhanh hơn beam=5 (~2x)
        best_of=1,             # Không sample nhiều lần
        temperature=0,         # Deterministic, ổn định hơn
        condition_on_previous_text=False,  # Tránh bị lặp text
        verbose=True,          # Hiện tiến trình từng đoạn
    )
    
    output_dir = os.path.join("finetune", "dataset", "raw_audio")
    os.makedirs(output_dir, exist_ok=True)
    metadata_path = os.path.join("finetune", "dataset", "metadata.csv")
    
    base_name = os.path.splitext(os.path.basename(input_file))[0]
    
    print(f"Đã nhận diện được {len(result['segments'])} câu. Đang cắt audio...")
    
    with open(metadata_path, "a", encoding="utf-8") as meta_file:
        for i, segment in enumerate(tqdm(result["segments"])):
            start_time = max(0, segment["start"] - pad_sec)
            end_time = min(duration, segment["end"] + pad_sec)
            text = segment["text"].strip()
            
            # Bỏ qua các câu quá ngắn hoặc không có chữ
            if not text or (end_time - start_time) < 1.0:
                continue
                
            start_sample = int(start_time * orig_sample_rate)
            end_sample = int(end_time * orig_sample_rate)
            
            chunk = orig_waveform[:, start_sample:end_sample]
            
            chunk_filename = f"{base_name}_{i:04d}.wav"
            chunk_filepath = os.path.join(output_dir, chunk_filename)
            
            # Lưu file âm thanh cắt nhỏ
            torchaudio.save(chunk_filepath, chunk, orig_sample_rate)
            
            # Ghi vào metadata
            meta_file.write(f"{chunk_filename}|{text}\n")
            
    print(f"\nHoàn tất! Các file âm thanh đã lưu tại: {output_dir}")
    print(f"Văn bản đã được thêm vào: {metadata_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Tự động cắt file âm thanh dài và nhận diện giọng nói bằng Whisper.")
    parser.add_argument("input_audio", help="Đường dẫn đến file âm thanh dài (VD: audio_dai.wav)")
    parser.add_argument("--model", default="large-v3", help="Kích thước mô hình Whisper. Mặc định: large-v3 (đã có sẵn trên máy)")
    parser.add_argument("--lang", default="vi", help="Ngôn ngữ (mặc định: vi)")
    args = parser.parse_args()
    
    process_audio(args.input_audio, args.model, args.lang)
