import os
from transformers import TrainingArguments
from peft import LoraConfig, TaskType

# Cấu hình LoRA
lora_config = LoraConfig(
    r=8,            # Giữ r=8 để khớp với checkpoint-5000 đã lưu
    lora_alpha=32,  # alpha/r = 4 (tỷ lệ tốt)
    target_modules=[
        "q_proj", "k_proj", "v_proj", "o_proj", 
        "gate_proj", "up_proj", "down_proj"
    ],
    lora_dropout=0.05, 
    bias="none",
    task_type=TaskType.CAUSAL_LM, 
)

training_config = {
    'model': "pnnbao-ump/VieNeu-TTS-0.3B",
    'run_name': "VieNeu-TTS-0.3B-LoRA",
    'output_dir': os.path.join("finetune", "output"),
    
    'per_device_train_batch_size': 1, 
    'gradient_accumulation_steps': 4,  # Tăng từ 1 → 4: batch hiệu quả hơn (effective batch = 4)
    
    'learning_rate': 1e-4,  # Giảm từ 2e-4 → 1e-4: train ổn định hơn, tránh overshoot
    'max_steps': 1500,     # Giảm xuống 1500 steps cho nhanh (phù hợp với data ít)
    'logging_steps': 50,
    'save_steps': 500,
    'eval_steps': 500,
    
    'warmup_ratio': 0.05,
    'bf16': False, 
    'fp16': True,
    
    'use_4bit': False,

    # --- Resume từ checkpoint tốt nhất ---
    'resume_from_checkpoint': os.path.join("finetune", "output", "VieNeu-TTS-0.3B-LoRA", "checkpoint-5000"),
}

def get_training_args(config):
    return TrainingArguments(
        output_dir=os.path.join(config['output_dir'], config['run_name']),
        do_train=True,
        do_eval=False,
        max_steps=config['max_steps'],
        per_device_train_batch_size=config['per_device_train_batch_size'],
        gradient_accumulation_steps=config['gradient_accumulation_steps'],
        learning_rate=config['learning_rate'],
        warmup_ratio=config['warmup_ratio'],
        bf16=config.get('bf16', False),
        fp16=config.get('fp16', True),
        logging_steps=config['logging_steps'],
        save_steps=config['save_steps'],
        eval_strategy="no",
        save_strategy="steps",
        save_total_limit=2,
        report_to="none", 
        dataloader_num_workers=0,
        ddp_find_unused_parameters=False,
    )
