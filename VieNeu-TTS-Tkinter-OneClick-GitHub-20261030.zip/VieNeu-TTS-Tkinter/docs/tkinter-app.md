# VieNeu-TTS Desktop (Tkinter)

Ứng dụng desktop dùng trực tiếp lõi VieNeu-TTS, không cần mở trình duyệt.

## Cài đặt và mở ứng dụng bằng một lần bấm

Nhấp đúp `run_tkinter.bat` ở thư mục gốc. File này tự động:

1. Nhận diện GPU NVIDIA hoặc CPU.
2. Tải trình quản lý `uv` chính thức nếu máy chưa có.
3. Tạo `.venv` với Python 3.12 và cài toàn bộ thư viện.
4. Cài PyTorch CUDA khi có NVIDIA; nếu thất bại sẽ tự chuyển sang CPU.
5. Kiểm tra môi trường rồi mở ứng dụng.

Lần đầu cần Internet và có thể mất 5–30 phút. Những lần sau dùng lại `.venv` nên mở nhanh. Có thể đặt biến môi trường `VIENEU_INSTALL_MODE=cpu` hoặc `VIENEU_INSTALL_MODE=gpu` để ép chế độ. Model chỉ được nạp khi bấm **Tải model**, vì vậy cửa sổ không chiếm VRAM ngay khi mở.

## Chức năng

- Đọc truyện bằng giọng preset hoặc clone từ audio mẫu.
- Chọn giọng đã train trong `finetune/dataset/raw_audio`; ứng dụng tự nạp file đại diện.
- Dùng và nghe thử trực tiếp các audio clone mẫu trong `examples/audio_ref`.
- Nhập TXT/PDF, tách câu thông minh và giữ dấu chấm/xuống dòng riêng biệt.
- Điều chỉnh ngắt nghỉ theo từng dấu câu và xuống dòng.
- Batch GPU, Temperature, Max chars, WAV/MP3 và Quality+.
- Xử lý nhiều TXT lần lượt; audio giữ đúng tên file TXT và lưu vào thư mục đã chọn.
- Hội thoại nhiều nhân vật với ánh xạ từng giọng.
- Lưu/xóa giọng clone trong thư viện người dùng.
- Chạy nền, hiển thị tiến độ, nhật ký và nút dừng an toàn sau lượt hiện tại.

## Thiết lập mặc định

Turbo fp32, Temperature 0.4, Max chars 224, Batch size 16. Quality+ chỉ dùng với Turbo và audio clone; chế độ này chậm hơn vì tự kiểm tra và sinh lại đoạn lỗi.

FFmpeg dùng để xuất MP3 được cài kèm trong `.venv`, không cần cài thủ công.
