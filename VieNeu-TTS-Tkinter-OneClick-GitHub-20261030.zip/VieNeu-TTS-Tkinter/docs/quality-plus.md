# Quality+ cho Voice Cloning v3 Turbo

Khởi động lại ứng dụng, mở tab Voice Cloning và bật **Quality+**. Áp dụng
cho nút tạo giọng thường và danh sách TXT. Khi bật, chế độ này xử lý tuần tự,
bỏ qua Batch Size để kiểm tra từng ứng viên. Khi tắt, Batch 16 vẫn hoạt động.

Quy trình:

- Chuyển mẫu sang mono, bỏ im lặng đầu/cuối, chọn cửa sổ tối đa 8 giây có
  nhiều tín hiệu và ít clipping bằng heuristic, cân âm lượng; khử nhiễu theo
  công tắc Denoise. Đây không phải phép xác định khách quan đoạn hay nhất.
- Whisper large-v3-turbo đã tải trên máy nhận diện mẫu và các bản sinh trên CPU.
  Không có checkpoint thì báo lỗi, không âm thầm bỏ bước đánh giá.
- Tái sử dụng cùng speaker embedding và reference codes cho toàn bộ danh sách.
- Sinh hai ứng viên mỗi câu; nếu cả lựa chọn tốt nhất còn sai lời hoặc lệch
  giọng theo ngưỡng, sinh ứng viên thứ ba. Chọn theo lỗi từ, độ giống embedding
  và clipping. Không huấn luyện lại model.
- Cân mức âm nhẹ (giới hạn ±6 dB), giảm đỉnh vượt .97 và fade 5 ms ở hai đầu.
  Ghép với khoảng nghỉ riêng theo dấu câu và xuống dòng, không chồng tiếng nói.
- Lưu báo cáo `ten-audio.mp3.quality.json` cạnh audio. Các đoạn đáng nghi vẫn
  được giữ nhưng có cảnh báo, không được coi là đã đạt chất lượng tuyệt đối.

Giới hạn: thời lượng được ước lượng từ tốc độ mẫu. Mục tiêu 8–15 giây chỉ là
tham khảo: hiện mỗi câu hoàn chỉnh vẫn là một đơn vị để giữ đúng nghỉ dấu câu;
không ép mọi đoạn vào khoảng này. Câu quá dài (>650 ký tự phoneme) báo lỗi yêu
cầu thêm dấu chấm thay vì cắt giữa câu. Whisper có thể sai với tên riêng, số,
tiếng địa phương và lời cảm xúc; điểm giọng không đo được toàn bộ độ tự nhiên.
Không bảo đảm chất lượng ngang OmniVoice hoặc chỉ chậm 2–3 lần.

Nút Dừng có hiệu lực giữa các lượt tạo/nhận diện; không ngắt giữa một lần
suy luận đang chạy. Báo cáo của chế độ thường ở cạnh MP3 trong thư mục tạm;
báo cáo TXT nằm trong thư mục xuất người dùng đã chọn.
