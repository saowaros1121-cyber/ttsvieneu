@echo off
setlocal EnableExtensions
chcp 65001 >nul
title VieNeu-TTS Desktop - One Click Setup
cd /d "%~dp0"

set "VENV_PYTHON=%CD%\.venv\Scripts\python.exe"
set "INSTALL_MODE=cpu"
set "MODE_FORCED=0"

if /I "%VIENEU_INSTALL_MODE%"=="cpu" (
  set "INSTALL_MODE=cpu"
  set "MODE_FORCED=1"
  goto :MODE_READY
)
if /I "%VIENEU_INSTALL_MODE%"=="gpu" (
  set "INSTALL_MODE=gpu"
  set "MODE_FORCED=1"
  goto :MODE_READY
)

where nvidia-smi.exe >nul 2>&1
if not errorlevel 1 set "INSTALL_MODE=gpu"

:MODE_READY
echo =========================================================
echo             VieNeu-TTS Desktop - One Click
echo =========================================================
echo [*] Che do tu dong: %INSTALL_MODE%
echo [*] Lan dau co the mat 5-30 phut de tai thu vien/model.
echo.

if not exist "%VENV_PYTHON%" goto :SETUP

echo [1/3] Dang kiem tra moi truong hien co...
"%VENV_PYTHON%" -c "import tkinter, numpy, soundfile, onnxruntime, gradio, fitz, pydub, imageio_ffmpeg; from apps.tkinter_app.gui import VieNeuDesktop" >nul 2>&1
if errorlevel 1 goto :SETUP
if /I not "%INSTALL_MODE%"=="gpu" goto :RUN_APP
"%VENV_PYTHON%" -c "import torch; assert torch.cuda.is_available()" >nul 2>&1
if errorlevel 1 goto :SETUP
goto :RUN_APP

:SETUP
echo [1/3] Chua du thu vien. Dang chuan bi trinh cai dat uv...
call :FIND_UV
if defined UV_EXE goto :SYNC

echo [*] Chua co uv. Dang tai uv tu trang chinh thuc Astral...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
set "PATH=%USERPROFILE%\.local\bin;%USERPROFILE%\.cargo\bin;%PATH%"
call :FIND_UV
if not defined UV_EXE goto :NO_UV

:SYNC
echo [2/3] Dang tao .venv va cai thu vien cho %INSTALL_MODE%...
if /I "%INSTALL_MODE%"=="gpu" goto :SYNC_GPU

"%UV_EXE%" sync --python 3.12 --extra pdf
if errorlevel 1 goto :INSTALL_FAILED
goto :VERIFY

:SYNC_GPU
"%UV_EXE%" sync --python 3.12 --extra pdf --extra cuda
if not errorlevel 1 goto :VERIFY
if "%MODE_FORCED%"=="1" goto :INSTALL_FAILED
echo.
echo [!] Cai GPU khong thanh cong. Dang tu dong chuyen sang CPU...
set "INSTALL_MODE=cpu"
"%UV_EXE%" sync --python 3.12 --extra pdf
if errorlevel 1 goto :INSTALL_FAILED

:VERIFY
echo [3/3] Dang kiem tra sau cai dat...
if not exist "%VENV_PYTHON%" goto :INSTALL_FAILED
"%VENV_PYTHON%" -c "import tkinter, numpy, soundfile, onnxruntime, gradio, fitz, pydub, imageio_ffmpeg; from apps.tkinter_app.gui import VieNeuDesktop" >nul 2>&1
if errorlevel 1 goto :INSTALL_FAILED

:RUN_APP
if "%VIENEU_BOOTSTRAP_CHECK_ONLY%"=="1" (
  echo [OK] Moi truong da san sang. Che do: %INSTALL_MODE%
  exit /b 0
)
echo.
echo [OK] Moi truong da san sang. Dang mo VieNeu-TTS Desktop...
"%VENV_PYTHON%" -m apps.tkinter_app
if errorlevel 1 goto :APP_FAILED
exit /b 0

:FIND_UV
set "UV_EXE="
for /f "delims=" %%U in ('where uv.exe 2^>nul') do if not defined UV_EXE set "UV_EXE=%%U"
if defined UV_EXE exit /b 0
if exist "%USERPROFILE%\.local\bin\uv.exe" set "UV_EXE=%USERPROFILE%\.local\bin\uv.exe"
if exist "%USERPROFILE%\.cargo\bin\uv.exe" set "UV_EXE=%USERPROFILE%\.cargo\bin\uv.exe"
exit /b 0

:NO_UV
echo.
echo [LOI] Khong the cai uv. Hay kiem tra Internet va chay lai file nay.
pause
exit /b 1

:INSTALL_FAILED
echo.
echo [LOI] Cai thu vien khong thanh cong.
echo Hay kiem tra Internet, dung luong o dia va chay lai.
pause
exit /b 1

:APP_FAILED
echo.
echo [LOI] Ung dung da dung do co loi. Xem thong bao phia tren.
pause
exit /b 1
