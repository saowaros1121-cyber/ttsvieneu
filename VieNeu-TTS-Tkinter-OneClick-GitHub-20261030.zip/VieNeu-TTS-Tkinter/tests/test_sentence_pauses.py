import numpy as np

from vieneu_utils.core_utils import (
    SMART_SPLIT_BREAK,
    V3_GAP_SILENCE,
    gaps_to_silence,
    join_audio_chunks,
)
from vieneu_utils.phonemize_text import normalize_to_chunks_v3_with_gaps
from apps.text_processing import smart_reformat_script


def test_v3_keeps_sentence_and_paragraph_boundaries():
    text = (
        "Đây là câu đầu tiên có đầy đủ nội dung để kiểm tra. "
        "Đây là câu thứ hai cũng đủ dài để tạo một đoạn riêng!\n"
        "Tiêu đề không có dấu cuối\n"
        "Đây là đoạn mới sau khi xuống dòng và cần nghỉ lâu hơn."
    )
    chunks, gaps = normalize_to_chunks_v3_with_gaps(text, max_chars=256)

    assert len(chunks) == 4
    assert gaps == ["dot", "newline", "newline"]


def test_story_pauses_are_audible():
    assert V3_GAP_SILENCE["comma"] == 0.40
    assert V3_GAP_SILENCE["dot"] == 0.75
    assert V3_GAP_SILENCE["newline"] == 1.10

    sr = 1000
    chunks = [np.ones(100, dtype=np.float32), np.ones(100, dtype=np.float32)]
    joined = join_audio_chunks(
        chunks,
        sr=sr,
        silence_ps=gaps_to_silence(["dot"]),
    )
    assert len(joined) == 100 + 750 + 100


def test_smart_split_never_cuts_a_long_sentence_midway():
    first = (
        "Đây là một câu cố ý rất dài để vượt xa giới hạn nhỏ nhưng vẫn phải "
        "được giữ nguyên cho tới khi gặp dấu chấm kết thúc câu."
    )
    second = "Đây là câu tiếp theo và cũng kết thúc đầy đủ!"

    lines = [
        line.replace(SMART_SPLIT_BREAK, "")
        for line in smart_reformat_script(
            first + " " + second, max_chars=40
        ).splitlines()
    ]

    assert lines == [first, second]
    assert len(lines[0]) > 40
    assert lines[0].endswith(".")
    assert lines[1].endswith("!")


def test_smart_split_keeps_real_newline_distinct_from_generated_break():
    first = "Đây là câu đầu tiên đủ dài để model tạo thành một đoạn riêng."
    second = "Đây là câu thứ hai đủ dài để kiểm tra khoảng nghỉ tiếp theo."

    # Cùng một dòng: Smart Split sinh ranh giới kỹ thuật, vẫn nghỉ theo dấu chấm.
    generated = smart_reformat_script(f"{first} {second}", max_chars=30)
    assert SMART_SPLIT_BREAK in generated
    _, generated_gaps = normalize_to_chunks_v3_with_gaps(generated, max_chars=256)
    assert generated_gaps == ["dot"]

    # Xuống dòng do người dùng nhập: luôn dùng thiết lập "Xuống dòng", dù dòng
    # trước đã kết thúc bằng dấu chấm.
    original = smart_reformat_script(f"{first}\n{second}", max_chars=30)
    _, original_gaps = normalize_to_chunks_v3_with_gaps(original, max_chars=256)
    assert original_gaps == ["newline"]


def test_each_punctuation_uses_its_own_override():
    overrides = {
        "dot": 0.1,
        "comma": 0.2,
        "question": 0.3,
        "exclamation": 0.4,
        "colon": 0.5,
        "semicolon": 0.6,
        "ellipsis": 0.7,
        "newline": 0.8,
    }
    gaps = [
        "dot", "comma", "question", "exclamation",
        "colon", "semicolon", "ellipsis", "newline",
    ]
    assert gaps_to_silence(gaps, overrides) == [
        0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8,
    ]
