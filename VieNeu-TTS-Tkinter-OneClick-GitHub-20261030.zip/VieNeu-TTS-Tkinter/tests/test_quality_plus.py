from types import SimpleNamespace
from threading import Event
import numpy as np
import soundfile as sf
from apps import quality_plus as q
from apps.text_processing import smart_reformat_script


def test_boundaries_and_whole_sentences():
    a = 'Đây là một câu hoàn chỉnh cần được giữ nguyên.'
    b = 'Đây là câu tiếp theo cũng được giữ nguyên.'
    text = smart_reformat_script(a + ' ' + b + '\n' + a, 20)
    chunks, gaps, durations = q.duration_chunks(text)
    assert chunks == [a, b, a]
    assert gaps == ['dot', 'newline']
    assert all(t > 0 for t in durations)


def test_reference_selection_and_peak(tmp_path):
    sr = 16000
    wav = np.r_[np.zeros(sr), .1*np.sin(np.arange(sr*10)*.1), np.zeros(sr)]
    path = tmp_path / 'ref.wav'
    sf.write(path, wav, sr)
    prepared, out_sr = q.prepare_reference(path)
    assert out_sr == sr and 3*sr <= len(prepared) <= 8*sr
    assert np.max(np.abs(prepared)) <= .951
    polished = q.polish(prepared * 20, sr)
    assert np.max(np.abs(polished)) <= .971
    assert polished[0] == polished[-1] == 0


def test_candidate_selection_retry_report_and_stop(monkeypatch, tmp_path):
    text = 'Đây là một câu kiểm tra chất lượng giọng nói.'
    heard = iter(['sai hoàn toàn', 'vẫn đọc sai', text])
    monkeypatch.setattr(q, 'transcribe', lambda *args: next(heard))
    anchor = np.array([1., 0.])
    engine = SimpleNamespace(infer=lambda **kw: np.sin(np.arange(48000)*.1)*.1,
                             extract_speaker_emb=lambda *a, **kw: anchor)
    session = q.QualitySession(SimpleNamespace(engine=engine, sample_rate=48000),
                               anchor, None, Event())
    result = list(session.generate(text, .4, None))
    assert result[-1][0] is not None
    assert session.report[0]['selected'] == 3
    assert not session.report[0]['suspect']
    session.save_report(tmp_path / 'audio.mp3')
    assert (tmp_path / 'audio.mp3.quality.json').is_file()
    session.stop.set()
    assert list(session.generate(text, .4, None)) == []


def test_word_error_counts_missing_and_repeated_words():
    assert q.word_error('Xin chào!', 'xin chào') == 0
    assert q.word_error('xin chào', 'xin xin chào') == .5
    assert q.word_error('xin chào', 'xin') == .5


def test_batch_routes_quality_and_saves_named_report(tmp_path):
    from test_batch_txt import batch_function
    stop = Event()
    source = tmp_path / 'chapter.txt'
    source.write_text('Đây là nội dung một câu thử nghiệm.', encoding='utf-8')
    class FakeQuality:
        report = [{'segment': 1, 'suspect': True}]
        def generate(self, text, temperature, pauses):
            yield np.sin(np.arange(2400)*.1).astype(np.float32)*.1, 'verified'
        def save_report(self, path):
            self.saved = str(path)
    quality = FakeQuality()
    tts = SimpleNamespace(sample_rate=24000, engine=SimpleNamespace(device=None))
    fn = batch_function('gradio_main.py', '_synthesize_batch_txt_files', tts, stop)
    results = list(fn(batch_txt_files=[str(source)], ref_codes=None, v3_speaker_emb=None,
                      ref_text_raw='', auto_download_files=False, batch_output_dir=str(tmp_path/'out'),
                      use_batch=True, max_batch_size_run=16, temperature=.4,
                      max_chars_chunk=224, is_v3=True, quality_session=quality))
    assert quality.saved.endswith('chapter.mp3')
    assert 'chapter.txt: đoạn 1' in results[-1][1]
