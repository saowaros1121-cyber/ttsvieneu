"""Regression tests for batch exports, without loading TTS model weights."""
import ast
import gc
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import soundfile as sf

from apps.batch_files import (prepare_batch, audio_path_for_txt, read_batch_text,
                             require_batch_files, preserve_txt_upload_names, txt_filename,
                             choose_output_directory, allow_generated_audio)
from apps.ui_utils import wrap_with_estimate
from apps.text_processing import smart_reformat_script

ROOT = Path(__file__).resolve().parents[1]


def batch_function(filename, name, tts, stop):
    # Import only the handler, avoiding GPU initialization and the full web UI.
    tree = ast.parse((ROOT / "apps" / filename).read_text(encoding="utf-8"))
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)
    namespace = dict(
        os=os, time=time, gc=gc, np=np, sf=sf, tts=tts, _STOP_EVENT=stop,
        current_backbone="VieNeu-TTS-v2", current_codec="test", using_lmdeploy=False,
        prepare_batch=prepare_batch, audio_path_for_txt=audio_path_for_txt, read_batch_text=read_batch_text,
        txt_filename=txt_filename,
        smart_reformat_script=smart_reformat_script,
        allow_generated_audio=allow_generated_audio,
        cleanup_gpu_memory=lambda: None, _format_duration=lambda seconds: str(round(seconds)),
        normalize_to_chunks=lambda text, **kwargs: text.split("|"),
        join_audio_chunks=lambda chunks, **kwargs: np.concatenate(chunks) if chunks else np.array([]),
        postprocess_audio=lambda wav, *args, **kwargs: wav,
        gaps_to_silence=lambda gaps, overrides=None: gaps,
    )
    exec(compile(ast.Module(body=[function], type_ignores=[]), filename, "exec"), namespace)
    return namespace[name]


class BatchTxtTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.out = self.root / "audio thư mục"
        self.stop = threading.Event()
        def infer(text, **kwargs):
            if text == "FAIL":
                raise RuntimeError("broken chapter")
            return np.sin(np.arange(2400, dtype=np.float32) * 0.04) * 0.1
        self.tts = SimpleNamespace(infer=infer, sample_rate=24000)

    def tearDown(self):
        self.temp.cleanup()

    def txt(self, name, content, encoding="utf-8"):
        path = self.root / name
        path.write_text(content, encoding=encoding)
        return str(path)

    def run_batch(self, files, xpu=False, **options):
        filename = "gradio_xpu.py" if xpu else "gradio_main.py"
        name = "_synthesize_batch_txt_files_xpu" if xpu else "_synthesize_batch_txt_files"
        fn = batch_function(filename, name, self.tts, self.stop)
        params = dict(batch_txt_files=files, ref_codes=None, ref_text_raw="",
                      auto_download_files=False, batch_output_dir=str(self.out),
                      use_batch=False, max_batch_size_run=4, temperature=0.8, max_chars_chunk=256)
        if not xpu:
            params.update(v3_speaker_emb=None, is_v3=False)
        params.update(options)
        return list(fn(**params))

    def test_multiple_files_preserve_exact_names_and_continue_after_errors(self):
        for xpu in (False, True):
            with self.subTest(xpu=xpu):
                files = [self.txt("Chương 01. Một 'câu' (thử).txt", "Xin chào|Mọi người"),
                         self.txt("lỗi.txt", "FAIL"), self.txt("rỗng.txt", "  "),
                         self.txt("Chương 02.txt", "Tạm biệt", "utf-16")]
                results = self.run_batch(files, xpu=xpu)
                paths = results[-1][2]
                self.assertEqual([Path(p).name for p in paths], [Path(files[0]).stem + ".mp3", "Chương 02.mp3"])
                self.assertIn("2/4", results[-1][1])
                self.assertIn("broken chapter", results[-1][1])
                for path in paths:
                    audio, sr = sf.read(path)
                    self.assertEqual(sr, 24000)
                    self.assertGreater(len(audio), 0)
                    self.assertTrue(Path(path).is_relative_to(self.out))

    def test_duplicate_name_never_overwrites_and_keeps_basename(self):
        txt = self.txt("Chương.01.txt", "Hello")
        first = self.run_batch([txt])[-1][2][0]
        data = Path(first).read_bytes()
        second = self.run_batch([txt])[-1][2][0]
        self.assertNotEqual(first, second)
        self.assertEqual(Path(first).name, Path(second).name)
        self.assertEqual(Path(first).read_bytes(), data)

    def test_uploaded_original_name_survives_gradio_preprocessing(self):
        import gradio as gr
        from gradio.data_classes import FileData, ListFiles
        original = "Chương 01. 'Thử' (A).txt"
        cached = self.txt("Chương 01. Thử A.txt", "Xin chào")
        component = gr.File(file_count="multiple", type="filepath", file_types=[".txt"])
        preserve_txt_upload_names(component)
        paths = component.preprocess(ListFiles(root=[FileData(path=cached, orig_name=original)]))
        self.assertEqual(txt_filename(paths[0]), original)
        result = self.run_batch(paths)
        self.assertEqual(Path(result[-1][2][0]).name, Path(original).stem + ".mp3")
        self.assertEqual(Path(result[-1][2][0]).parent, self.out)

    def test_unwritable_target_and_no_files_report_errors(self):
        bad = self.root / "not-a-folder"
        bad.write_text("existing file")
        result = self.run_batch([self.txt("test.txt", "Hello")], batch_output_dir=str(bad))
        self.assertIn("❌", result[-1][1])
        self.assertEqual(result[-1][2], [])
        self.assertEqual(self.run_batch([])[-1][2], [])

    def test_cancel_preserves_completed_audio(self):
        def infer(text, **kwargs):
            self.stop.set()
            return np.zeros(2400, dtype=np.float32)
        self.tts.infer = infer
        results = self.run_batch([self.txt("one.txt", "Hello"), self.txt("two.txt", "Hi")])
        self.assertIn("Đã dừng", results[-1][1])
        self.assertTrue((self.out / "one.mp3").exists())
        self.assertFalse((self.out / "two.mp3").exists())

    def test_v3_sequential_batch(self):
        self.tts.engine = SimpleNamespace(infer=lambda **kwargs: np.zeros(4800, dtype=np.float32), device=None)
        self.tts.sample_rate = 48000
        module = SimpleNamespace(phonemize_text_with_emotions=lambda text: text,
                                 normalize_to_chunks_v3_with_gaps=lambda text, **kwargs: (text.split("|"), [0.1]))
        with patch.dict("sys.modules", {"vieneu_utils.phonemize_text": module}):
            result = self.run_batch([self.txt("v3.txt", "Xin chào|Tạm biệt")], is_v3=True)
        self.assertEqual(len(result[-1][2]), 1)
        self.assertEqual(sf.info(result[-1][2][0]).samplerate, 48000)

    def test_each_txt_automatically_uses_manual_smart_split_before_inference(self):
        texts = ["Xin chào mọi người. Hôm nay trời đẹp! Chúng ta cùng đi dạo nhé?",
                 "Đây là file tiếp theo. Mọi người đã sẵn sàng chưa? Bắt đầu thôi!"]
        limit = 32
        for xpu in (False, True):
            with self.subTest(xpu=xpu):
                spoken = []
                self.tts.infer = lambda text, **kwargs: spoken.append(text) or np.zeros(2400, dtype=np.float32)
                filename = "gradio_xpu.py" if xpu else "gradio_main.py"
                name = "_synthesize_batch_txt_files_xpu" if xpu else "_synthesize_batch_txt_files"
                fn = batch_function(filename, name, self.tts, self.stop)
                prepared = []
                def normalize(text, **kwargs):
                    prepared.append(text)
                    return text.splitlines()
                fn.__globals__["normalize_to_chunks"] = normalize
                files = [self.txt(f"auto_{i}.txt", text) for i, text in enumerate(texts)]
                params = dict(batch_txt_files=files, ref_codes=None, ref_text_raw="",
                              auto_download_files=False, batch_output_dir=str(self.out),
                              use_batch=False, max_batch_size_run=4, temperature=0.8, max_chars_chunk=limit)
                if not xpu:
                    params.update(v3_speaker_emb=None, is_v3=False)
                results = list(fn(**params))
                expected = [smart_reformat_script(text, max_chars=limit) for text in texts]
                self.assertEqual(prepared, expected)
                self.assertEqual(spoken, [line for text in expected for line in text.splitlines()])
                self.assertGreater(len(spoken), len(files))
                self.assertEqual(len(results[-1][2]), len(files))
                self.assertEqual(sum("Đã tự động tách câu thông minh" in item[1] for item in results), len(files))

    def test_v3_automatically_splits_before_phonemizing(self):
        raw = "Xin chào mọi người. Chúng ta cùng bắt đầu nhé! Hẹn gặp lại."
        prepared, spoken = [], []
        def normalize(text, **kwargs):
            prepared.append(text)
            chunks = text.splitlines()
            return chunks, ["para"] * (len(chunks) - 1)
        def infer(**kwargs):
            spoken.append(kwargs["phonemes"])
            return np.zeros(4800, dtype=np.float32)
        self.tts.engine = SimpleNamespace(infer=infer, device=None)
        self.tts.sample_rate = 48000
        module = SimpleNamespace(phonemize_text_with_emotions=lambda text: text,
                                 normalize_to_chunks_v3_with_gaps=normalize)
        with patch.dict("sys.modules", {"vieneu_utils.phonemize_text": module}):
            result = self.run_batch([self.txt("v3_auto.txt", raw)], is_v3=True, max_chars_chunk=30)
        expected = smart_reformat_script(raw, max_chars=30)
        self.assertEqual(prepared, [expected])
        self.assertEqual(spoken, expected.splitlines())
        self.assertEqual(len(result[-1][2]), 1)

    def test_encodings_and_output_wrapper(self):
        for encoding in ("utf-8-sig", "utf-16", "cp1258"):
            path = self.txt(encoding + ".txt", "Xin chào", encoding)
            self.assertEqual(read_batch_text(path), "Xin chào")
        def synthesis():
            yield None, "starting", []
            yield "one.mp3", "saved", ["one.mp3"]
            yield "one.mp3", "progress", ""
        updates = list(wrap_with_estimate(synthesis)())
        self.assertEqual(updates[1][3], ["one.mp3"])
        self.assertEqual(updates[2][3], {"__type__": "update"})

    def test_batch_button_requires_files_and_forces_clone_mode(self):
        def synthesize(mode_tab, batch_txt_files=None, batch_output_dir=""):
            yield None, mode_tab, batch_txt_files
        handler = require_batch_files(synthesize)
        self.assertIn("Vui lòng chọn", list(handler("preset_mode"))[0][1])
        txt = self.txt("one.txt", "Xin chào")
        result = list(handler("preset_mode", [txt], str(self.out)))
        self.assertEqual(result[0][1], "custom_mode")

    def test_windows_folder_picker_and_cancel(self):
        import subprocess
        with patch("apps.batch_files.sys.platform", "win32"), patch("apps.batch_files.subprocess.run") as run:
            run.return_value = SimpleNamespace(stdout=str(self.out))
            self.assertEqual(choose_output_directory("outputs"), str(self.out))
            self.assertIn("-STA", run.call_args.args[0])
            self.assertEqual(run.call_args.kwargs["creationflags"], subprocess.CREATE_NO_WINDOW)
            run.return_value = SimpleNamespace(stdout="")
            self.assertEqual(choose_output_directory("outputs"), "outputs")

    def test_external_folder_is_downloadable_without_exposing_entire_folder(self):
        import gradio as gr
        import requests
        from gradio_client import Client
        from gradio.context import LocalContext

        # A sibling of the workspace is outside both cwd and the system temp dir.
        with tempfile.TemporaryDirectory(prefix="vieneu_external_check_", dir=ROOT.parent) as folder:
            external = Path(folder)
            private = external / "unrelated.txt"
            private.write_text("not an exported audio", encoding="utf-8")
            files = [self.txt("Chapter 01.txt", "Xin chào."), self.txt("Chapter 02.txt", "Tạm biệt.")]
            fn = batch_function("gradio_main.py", "_synthesize_batch_txt_files", self.tts, self.stop)
            def generate():
                yield from fn(batch_txt_files=files, ref_codes=None, v3_speaker_emb=None,
                              ref_text_raw="", auto_download_files=False, batch_output_dir=str(external),
                              use_batch=False, max_batch_size_run=4, temperature=0.8,
                              max_chars_chunk=256, is_v3=False)
            token = LocalContext.blocks.set(None)
            try:
                with gr.Blocks() as demo:
                    audio = gr.Audio(type="filepath", format="mp3")
                    status, estimate = gr.Textbox(), gr.Textbox()
                    downloads = gr.File(file_count="multiple")
                    gr.Button().click(wrap_with_estimate(generate), outputs=[audio, status, estimate, downloads], api_name="batch")
                demo.queue().launch(server_name="127.0.0.1", server_port=None,
                                    prevent_thread_lock=True, quiet=True)
                try:
                    client = Client(demo.local_url, verbose=False, download_files=False)
                    result = client.predict(api_name="/batch")
                    self.assertIn("2/2", result[1])
                    self.assertEqual(len(result[3]), 2)
                    for item in result[3]:
                        url = item["url"]
                        if not url.startswith("http"):
                            url = demo.local_url.rstrip("/") + url
                        self.assertEqual(requests.get(url, timeout=10).status_code, 200)
                    self.assertNotIn(str(external), demo.allowed_paths)
                    self.assertNotIn(str(private), demo.allowed_paths)
                    self.assertTrue((external / "Chapter 01.mp3").exists())
                    self.assertTrue((external / "Chapter 02.mp3").exists())
                    self.assertEqual(len(demo.allowed_paths), 2)
                finally:
                    demo.close()
            finally:
                LocalContext.blocks.reset(token)


if __name__ == "__main__":
    unittest.main()
