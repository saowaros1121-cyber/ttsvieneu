from __future__ import annotations

from types import SimpleNamespace

import numpy as np

from apps.tkinter_app.config import DEFAULTS, load_config, save_config
from apps.tkinter_app.engine import DesktopEngine
from apps.tkinter_app.resources import clone_audio_examples, trained_voice_samples
from apps.tkinter_app.text_processing import analyze_text, parse_conversation, parse_voice_mapping


def test_desktop_engine_is_lazy():
    engine = DesktopEngine()
    assert engine.loaded is False


def test_text_analysis_keeps_period_and_real_newline_distinct():
    _, sentences = analyze_text("Câu một. Câu hai.\nCâu ba?", smart=True, max_chars=224)
    assert [item.text for item in sentences] == ["Câu một.", "Câu hai.", "Câu ba?"]
    assert sentences[0].boundary_after == "dot"
    assert sentences[1].boundary_after == "newline"


def test_conversation_and_voice_mapping_parsers():
    script = "Lan: Xin chào.\nĐây là phần nối tiếp.\nMinh：Chào Lan!"
    assert parse_conversation(script) == [
        ("Lan", "Xin chào. Đây là phần nối tiếp."),
        ("Minh", "Chào Lan!"),
    ]
    assert parse_voice_mapping("Lan=Giọng A\nMinh = Giọng B") == {
        "Lan": "Giọng A",
        "Minh": "Giọng B",
    }


def test_config_round_trip(tmp_path, monkeypatch):
    monkeypatch.setenv("VIENEU_HOME", str(tmp_path))
    changed = dict(DEFAULTS)
    changed["temperature"] = 0.55
    changed["pauses"] = {**DEFAULTS["pauses"], "newline": 1.25}
    save_config(changed)
    loaded = load_config()
    assert loaded["temperature"] == 0.55
    assert loaded["pauses"]["newline"] == 1.25


def test_nano_path_uses_adjustable_pause_table():
    class FakeNano:
        sample_rate = 1000
        _preset_voices = {"Mẫu": {"speaker_emb": np.ones(2), "codes": np.ones((2, 2))}}

        def get_preset_voice(self, _voice):
            return self._preset_voices["Mẫu"]

    fake = FakeNano()
    fake.engine = SimpleNamespace(
        infer=lambda **_kwargs: np.ones(100, dtype=np.float32),
    )
    engine = DesktopEngine()
    engine.tts = fake
    engine.model_name = "VieNeu-TTS v3 Nano"

    short = engine.synthesize("Một.\nHai.", voice="Mẫu", pauses={"newline": 0.1})
    long = engine.synthesize("Một.\nHai.", voice="Mẫu", pauses={"newline": 0.5})
    assert len(long) - len(short) == 400


def test_trained_voice_samples_choose_middle_file(tmp_path):
    folder = tmp_path / "finetune" / "dataset" / "raw_audio"
    folder.mkdir(parents=True)
    for number in (0, 1, 2):
        (folder / f"Lan_{number:04d}.wav").write_bytes(b"wav")
    (folder / "Minh.wav").write_bytes(b"wav")
    found = trained_voice_samples(tmp_path)
    assert found["Lan"].name == "Lan_0001.wav"
    assert found["Minh"].name == "Minh.wav"


def test_clone_examples_include_transcript_in_label(tmp_path):
    folder = tmp_path / "examples" / "audio_ref"
    folder.mkdir(parents=True)
    (folder / "example.wav").write_bytes(b"wav")
    (folder / "example.txt").write_text("Xin chào, đây là audio mẫu.", encoding="utf-8")
    found = clone_audio_examples(tmp_path)
    label, path = next(iter(found.items()))
    assert "Xin chào" in label
    assert path.name == "example.wav"

