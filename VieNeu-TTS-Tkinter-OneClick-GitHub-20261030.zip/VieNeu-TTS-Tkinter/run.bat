@echo off
title VieNeu-TTS Web UI
cd /d "%~dp0"

echo =========================================================
echo.
echo    DANG KHOI DONG VieNeu-TTS... Vui long cho!
echo.
echo =========================================================
echo.

:: Tat tien trinh cu dang chiem port 7860 (neu co)
echo [*] Dang kiem tra va tat tien trinh cu tren port 7860...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":7860 " ^| findstr "LISTENING"') do (
    echo     -> Dang tat tien trinh PID: %%a
    taskkill /PID %%a /F >nul 2>&1
)
:: Doi 1 giay de port giai phong hoan toan
timeout /t 1 /nobreak >nul
echo [*] San sang khoi dong!
echo.

call .venv\Scripts\activate.bat

:: Mo trinh duyet sau 5 giay (du thoi gian de server khoi dong)
start "" powershell -WindowStyle Hidden -Command "Start-Sleep -Seconds 5; Start-Process 'http://localhost:7860'"

python -m apps.gradio_main

echo.
pause
