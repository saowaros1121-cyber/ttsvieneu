import sys
import io
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

import gradio as gr
print("⏳ Đang khởi động VieNeu-TTS... Vui lòng chờ...")
import soundfile as sf
import tempfile
from vieneu import Vieneu
import os
import time
import numpy as np
import queue
import threading
import yaml
import uuid
from vieneu_utils.core_utils import (
    join_audio_chunks, env_bool, get_silence_duration_v2, gaps_to_silence,
    postprocess_audio, trust_remote_code_enabled, pause_settings,
)
from vieneu_utils.phonemize_text import phonemize_to_chunks, normalize_to_chunks, normalize_to_chunks_v3, normalize_to_chunks_v3_with_gaps
# PuncNormalizer = sea_g2p.Normalizer luôn bật punc_norm=True.
from vieneu_utils.phonemize_text import PuncNormalizer as Normalizer
import gc
from apps.text_processing import smart_reformat_script
from apps.batch_files import (
    prepare_batch, audio_path_for_txt, read_batch_text, choose_output_directory,
    require_batch_files, preserve_txt_upload_names, txt_filename, allow_generated_audio,
)
from apps.user_voices import load_user_voices

# PDF text extraction
try:
    import fitz  # PyMuPDF
    HAS_FITZ = True
except ImportError:
    HAS_FITZ = False
    fitz = None

from apps.ui_utils import (
    _format_duration,
    _split_estimate_status,
    estimate_time_ui,
    wrap_with_estimate,
    cleanup_gpu_memory,
    get_ref_text_cached,
    on_codec_change,
    validate_audio_duration,
    on_custom_id_change
)
from apps.ui_constants import (
    theme,
    css,
    head_html,
    batch_download_js,
    DEFAULT_TEXT_GPU,
    DEFAULT_TEXT_TURBO,
    DEFAULT_TEXT_V3
)

# --- CONSTANTS & CONFIG ---
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")
try:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        _config = yaml.safe_load(f) or {}
except Exception as e:
    raise RuntimeError(f"Không thể đọc config.yaml: {e}")

BACKBONE_CONFIGS = _config.get("backbone_configs", {})
CODEC_CONFIGS = _config.get("codec_configs", {})

# Refilter and Simplify Configs per requirements
HAS_GPU = False
try:
    import torch
    HAS_GPU = torch.cuda.is_available() or (sys.platform == "darwin" and torch.backends.mps.is_available())
except ImportError:
    pass

filtered_backbones = {}


def _watermark_available() -> bool:
    """Return whether the optional Resemble Perth watermarker is usable."""
    try:
        import perth

        return getattr(perth, "PerthImplicitWatermarker", None) is not None
    except Exception:
        return False


# VieNeu-TTS v3 Turbo (early access) — PyTorch, runs on both CPU and GPU.
if not HAS_GPU:
    filtered_backbones["VieNeu-TTS-v3-Turbo (int8)"] = {
        "repo": "pnnbao-ump/VieNeu-TTS-v3-Turbo",
        "precision": "int8",
        "supports_streaming": False,
        "description": "🆕 v3 Turbo (int8) — 48kHz, TỐI ƯU CHO CPU: nhanh nhất (backbone nén int8, ~3x/frame, nhẹ 4x). Khuyến nghị cho máy CPU. Giọng mặc định dùng speaker token; Voice Cloning clone từ audio mẫu; tag cảm xúc [cười]/[hắng giọng]/[thở dài] (thử nghiệm)."
    }
filtered_backbones["VieNeu-TTS-v3-Turbo"] = {
    "repo": "pnnbao-ump/VieNeu-TTS-v3-Turbo",
    "precision": "fp32",
    "supports_streaming": False,
    "description": (
        "🆕 v3 Turbo — 48kHz. Giọng mặc định dùng speaker token (ổn định hơn); Voice Cloning "
        "clone từ audio mẫu; tag cảm xúc [cười]/[hắng giọng]/[thở dài] (thử nghiệm)."
        + ("" if HAS_GPU else " Trên CPU đây là bản chất-lượng-tối-đa (chậm hơn bản int8).")
    )
}
filtered_backbones["VieNeu-TTS-v3-Nano (preview)"] = {
    "repo": "pnnbao-ump/VieNeu-TTS-v3-Nano",
    "supports_streaming": False,
    "description": (
        "🪶 v3 Nano (preview) — 24kHz, chạy rất nhanh trên CPU yếu hoặc thiết bị edge. "
        "Có giọng preset và clone giọng, nhưng chất lượng thấp hơn v3 Turbo, nhất là tiếng Anh/song ngữ."
    ),
}

# GPU-only extras. On GPU the default is VieNeu-TTS-v2 (GPU); v3 Turbo stays the
# default (and only option) on CPU machines (the v2/v1 GGUF CPU builds were removed).
if HAS_GPU:
    filtered_backbones["VieNeu-TTS-v2 (GPU)"] = {
        "repo": "pnnbao-ump/VieNeu-TTS-v2",
        "supports_streaming": False,
        "description": "VieNeu-TTS Version 2 - hỗ trợ song ngữ (Anh-Việt) và chế độ podcast"
    }
    filtered_backbones["VieNeu-TTS (GPU)"] = {
        "repo": "pnnbao-ump/VieNeu-TTS",
        "supports_streaming": False,
        "description": "VieNeu-TTS Version 1 - ổn định, production-ready"
    }

BACKBONE_CONFIGS = filtered_backbones

filtered_codecs = {
    "NeuCodec (Distill)": {
        "repo": "neuphonic/distill-neucodec",
        "description": "Codec mặc định cho model GPU",
        "use_preencoded": False
    },
    "NeuCodec (ONNX)": {
        "repo": "neuphonic/neucodec-onnx-decoder-int8",
        "description": "Codec siêu nhẹ, tối ưu cho CPU (ONNX)",
        "use_preencoded": False
    },
    "VieNeu-Codec": {
        "repo": "pnnbao-ump/VieNeu-Codec",
        "description": "Codec tối ưu cho Turbo v2 (ONNX)",
        "use_preencoded": False
    }
}
CODEC_CONFIGS = filtered_codecs

_text_settings = _config.get("text_settings", {})
MAX_CHARS_PER_CHUNK = _text_settings.get("max_chars_per_chunk", 224)
MAX_TOTAL_CHARS_STREAMING = _text_settings.get("max_total_chars_streaming", 3000)
DEFAULT_GENERATION_TEMPERATURE = 0.4
DEFAULT_GENERATION_BATCH_SIZE = 16
DEFAULT_USE_BATCH = True

PAUSE_DEFAULTS = pause_settings()
PAUSE_KEYS = (
    "dot", "comma", "question", "exclamation",
    "colon", "semicolon", "ellipsis", "newline",
)


def _pause_overrides(dot, comma, question, exclamation,
                     colon, semicolon, ellipsis, newline):
    return pause_settings(dict(zip(PAUSE_KEYS, (
        dot, comma, question, exclamation,
        colon, semicolon, ellipsis, newline,
    ))))

if not BACKBONE_CONFIGS or not CODEC_CONFIGS:
    raise ValueError("config.yaml thiếu backbone_configs hoặc codec_configs")

# --- 1. MODEL CONFIGURATION ---
# Global model instance
tts = None
current_backbone = None
current_codec = None
model_loaded = False
using_lmdeploy = False
PRESET_VOICES_CACHE = []  # List of all voices (tuples or strings)
CONV_VOICES_CACHE = []    # Filtered list for conversation (podcast=True)
MAX_SPEAKERS = 8          # Max concurrent speakers in conversation tab

# Normalizer (module-level singleton)
_text_normalizer = Normalizer()

def get_available_devices() -> list[str]:
    """Get list of available devices for current platform."""
    devices = ["Auto", "CPU"]
    
    try:
        import torch
        if sys.platform == "darwin" and torch.backends.mps.is_available():
            devices.append("MPS")
        elif torch.cuda.is_available():
            devices.append("CUDA")
    except ImportError:
        pass

    return devices

def get_trained_voices():
    """Scan finetune/dataset/raw_audio/ and group WAV files by voice prefix.
    Returns a dict {display_name: [list_of_wav_paths]} and a choice list.
    """
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    raw_audio_dir = os.path.join(project_root, "finetune", "dataset", "raw_audio")
    voices = {}
    if os.path.isdir(raw_audio_dir):
        for fname in sorted(os.listdir(raw_audio_dir)):
            if not fname.lower().endswith(".wav"):
                continue
            # Extract prefix: everything before the last _NNNN part
            parts = fname.rsplit("_", 1)
            prefix = parts[0] if len(parts) == 2 and parts[1].split(".")[0].isdigit() else fname
            if prefix not in voices:
                voices[prefix] = []
            voices[prefix].append(os.path.join(raw_audio_dir, fname))
    return voices

def _get_trained_voice_choices():
    """Return list of display names for the dropdown."""
    voices = get_trained_voices()
    if not voices:
        return ["-- Chưa có giọng nào được train --"]
    return ["-- Chọn giọng đã train --"] + list(voices.keys())

def _get_conv_character_voice_choices():
    """Return list of voice choices for conversation speaker mapping."""
    choices = ["-- Tải lên audio mẫu bên cạnh --"]
    voices = get_trained_voices()
    if voices:
        choices.extend([f"Giọng train: {k}" for k in sorted(voices.keys())])
    if CONV_VOICES_CACHE:
        choices.extend(CONV_VOICES_CACHE)
    elif PRESET_VOICES_CACHE:
        choices.extend(PRESET_VOICES_CACHE)
    return choices

def _load_trained_voice_audio(voice_name: str):
    """Return path to a representative WAV file for the chosen voice."""
    if not voice_name or voice_name.startswith("--"):
        return None
    # Strip optional 'Giọng train: ' prefix
    vname = str(voice_name).replace("Giọng train: ", "").strip()
    voices = get_trained_voices()
    files = voices.get(vname, [])
    if not files:
        return None
    # Pick the middle file as the most representative sample
    return files[len(files) // 2]

def _supports_cloning(backbone_choice: str) -> bool:
    """Voice Cloning availability by model.

    v3+ clones directly from a sample audio; VieNeu-TTS-v2 (GPU) clones from
    audio plus a reference transcript. v1 and the CPU/Turbo builds stay
    preset-only.
    """
    c = (backbone_choice or "").lower()
    return "v3" in c or c == "vieneu-tts-v2 (gpu)"

def get_model_status_message() -> str:
    """Reconstruct status message from global state"""
    global model_loaded, tts, using_lmdeploy, current_backbone, current_codec
    if not model_loaded or tts is None:
        return "⏳ Chưa tải model."
    
    if "v2-Turbo" in (current_backbone or ""):
        backend_name = "⚡ Turbo (v2)"
    elif using_lmdeploy:
        backend_name = "🚀 LMDeploy (Optimized)"
    else:
        backend_name = "📦 Standard"
    
    # We don't track the exact device strings perfectly in global state, so we estimate
    try:
        import torch
        has_mps = torch.backends.mps.is_available()
        has_cuda = torch.cuda.is_available()
    except:
        has_mps = has_cuda = False

    device_info = "GPU (CUDA)" if (using_lmdeploy or "CUDA" in (current_backbone or "")) else ("MPS (Metal)" if has_mps else "Auto")
    
    if "v2-Turbo" in (current_backbone or ""):
        codec_device = "GPU/MPS" if (has_cuda or has_mps) else "CPU"
    elif "ONNX" in (current_codec or ""):
        codec_device = "CPU"
    else:
        codec_device = "GPU/MPS" if (has_cuda or has_mps) else "CPU"

    preencoded_note = ""    
    opt_info = ""
    if using_lmdeploy and hasattr(tts, 'get_optimization_stats'):
        stats = tts.get_optimization_stats()
        opt_info = (
            f"\n\n🔧 Tối ưu hóa:"
            f"\n  • Triton: {'✅' if stats['triton_enabled'] else '❌'}"
            f"\n  • Max Batch Size (Default): {stats.get('max_batch_size', 'N/A')}"
            f"\n  • Reference Cache: {stats['cached_references']} voices"
            f"\n  • Prefix Caching: ❌"
        )

    return (
        f"✅ Model đã tải thành công!\n\n"
        f"🔧 Backend: {backend_name}\n"
        f" Parrot: {current_backbone} on {device_info}\n"
        f"🎵 Codec: {current_codec} on {codec_device}{preencoded_note}{opt_info}"
    )

def restore_ui_state():
    """Update UI components based on persistence"""
    global model_loaded
    msg = get_model_status_message()
    return (
        msg, 
        gr.update(interactive=model_loaded), # btn_generate
        gr.update(interactive=model_loaded), # btn_generate_conv
        gr.update(interactive=False)         # btn_stop
    )

def should_use_lmdeploy(backbone_choice: str, device_choice: str) -> bool:
    """Determine if we should use LMDeploy backend."""
    # LMDeploy not supported on macOS
    if sys.platform == "darwin":
        return False

    # GGUF, v2-Turbo và v3 Turbo đều KHÔNG dùng LMDeploy (v3 là PyTorch, có engine riêng).
    bc = backbone_choice.lower()
    if "gguf" in bc or "v2-turbo" in bc or "v3" in bc:
        return False
    
    try:
        import torch
        if device_choice == "Auto":
            has_gpu = torch.cuda.is_available()
        elif device_choice == "CUDA":
            has_gpu = torch.cuda.is_available()
        else:
            has_gpu = False
        return has_gpu
    except ImportError:
        return False

def load_model(backbone_choice: str, codec_choice: str, device_choice: str, 
               force_lmdeploy: bool, custom_model_id: str = "", custom_base_model: str = "", 
               custom_hf_token: str = ""):
    """Load model with optimizations and max batch size control"""
    global tts, current_backbone, current_codec, model_loaded, using_lmdeploy
    lmdeploy_error_reason = None
    model_loaded = False # Ensure we don't try to use a half-loaded model
    
    # Helper for slot updates (initially no change)
    slot_no_updates = [gr.update()] * MAX_SPEAKERS

    yield (
        "⏳ Đang tải model với tối ưu hóa... Lưu ý: Quá trình này sẽ tốn thời gian. Vui lòng kiên nhẫn.",
        gr.update(interactive=False), # btn_generate
        gr.update(interactive=False), # btn_generate_conv
        gr.update(interactive=False), # btn_load
        gr.update(interactive=False), # btn_stop
        gr.update(), # voice_select
        gr.update(), gr.update(), gr.update(), gr.update(), # tab_p, tab_c, tab_sel, mode_state
        gr.update(), # conv_tab
        *slot_no_updates
    )
    
    try:
        # Cleanup before loading new model
        if tts is not None:
            tts = None # Reset instead of del to avoid NameError if load fails
            cleanup_gpu_memory()
        
        # Prepare Backbone Config/Repo
        custom_loading = False
        is_merged_lora = False

        if backbone_choice == "Custom Model":
            custom_loading = True
            if not custom_model_id or not custom_model_id.strip():
                yield (
                    "❌ Lỗi: Vui lòng nhập Model ID cho Custom Model.",
                    gr.update(interactive=False), gr.update(interactive=False), gr.update(interactive=True), gr.update(interactive=False), gr.update(),
                    gr.update(), gr.update(), gr.update(), gr.update(),
                    gr.update(), # conv_tab
                    *slot_no_updates
                )
                return

            # Check if it is a LoRA to merge
            if "lora" in custom_model_id.lower():
                # Merging mode
                print(f"🔄 Detected LoRA in name. preparing merge with base: {custom_base_model}")
                if custom_base_model not in BACKBONE_CONFIGS:
                    yield (
                        f"❌ Lỗi: Base Model '{custom_base_model}' không hợp lệ.",
                        gr.update(interactive=False), gr.update(interactive=False), gr.update(interactive=True), gr.update(interactive=False),
                        gr.update(), gr.update(), gr.update(), gr.update(), gr.update(),
                        gr.update(), # conv_tab
                        *slot_no_updates
                    )
                    return
                
                base_config = BACKBONE_CONFIGS[custom_base_model]
                backbone_config = {
                    "repo": base_config["repo"], # Load base first
                    "supports_streaming": base_config["supports_streaming"],
                    "description": f"Custom Merged: {custom_model_id} + {custom_base_model}"
                }
                is_merged_lora = True
            else:
                # Normal custom model
                backbone_config = {
                    "repo": custom_model_id.strip(),
                    "supports_streaming": False, # Assume false for unknown
                    "description": f"Custom Model: {custom_model_id}"
                }
        else:
            backbone_config = BACKBONE_CONFIGS[backbone_choice]
            
        codec_config = CODEC_CONFIGS[codec_choice]
        use_lmdeploy = False
        
        # Override LMDeploy if custom
        if custom_loading:
             if "gguf" in backbone_config['repo'].lower() or "v2-turbo" in backbone_config['repo'].lower():
                 # GGUF must use Standard/Turbo backend
                 use_lmdeploy = False
             elif is_merged_lora:
                 # LoRA can use LMDeploy if we merge first (checked logic below) or Standard
                 use_lmdeploy = force_lmdeploy and should_use_lmdeploy(custom_base_model, device_choice)
             else:
                 # A typed custom repository can execute remote model code through
                 # LMDeploy, so require an explicit opt-in.
                 use_lmdeploy = (
                     force_lmdeploy
                     and trust_remote_code_enabled()
                     and should_use_lmdeploy("VieNeu-TTS (GPU)", device_choice)
                 )
        # Use LMDeploy only if Force LMDeploy is set and the model is compatible
        # NOTE: For VieNeu-v2-Turbo, we handle LMDeploy inside TurboGPUVieNeuTTS class, 
        # so we set use_lmdeploy = False here to avoid generic FastVieNeuTTS loading.
        # NOTE: For custom_loading, the block above already decided use_lmdeploy correctly
        # (e.g. False for GGUF repos). Do NOT override that decision here.
        if "v2-Turbo" in backbone_choice or "v3" in backbone_choice.lower():
             # v2-Turbo có LMDeploy riêng trong class; v3 Turbo là PyTorch (engine riêng,
             # không bao giờ dùng LMDeploy) — bỏ qua FastVieNeuTTS generic.
             should_use_generic_fast = False
        elif custom_loading:
             should_use_generic_fast = False  # already handled above per repo name
        else:
             should_use_generic_fast = force_lmdeploy and should_use_lmdeploy(backbone_choice, device_choice)
             
        if should_use_generic_fast:
            use_lmdeploy = True
        
        if use_lmdeploy:
            lmdeploy_error_reason = None
            print(f"🚀 Using LMDeploy backend with optimizations")
            
            backbone_device = "cuda"
            
            if "ONNX" in codec_choice:
                codec_device = "cpu"
            else:
                try:
                    import torch
                    codec_device = "cuda" if torch.cuda.is_available() else "cpu"
                except ImportError:
                    codec_device = "cpu"
            
            # Special handling for Custom LoRA + LMDeploy -> Merge & Save
            target_backbone_repo = backbone_config["repo"]
            
            if custom_loading and is_merged_lora:
                safe_name = custom_model_id.strip().replace("/", "_").replace("\\", "_").replace(":", "")
                cache_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "merged_models_cache", safe_name)
                target_backbone_repo = os.path.abspath(cache_dir)
                
                # Check if already merged (and voices.json exists)
                if not os.path.exists(cache_dir) or not os.path.exists(os.path.join(cache_dir, "vocab.json")):
                    print(f"🔄 Merging LoRA for LMDeploy optimization: {cache_dir}")
                    if os.path.exists(cache_dir):
                        print("   ⚠️ Detected incomplete cache, rebuilding...")
                    yield (
                         f"⏳ Đang merge và lưu model LoRA để tối ưu cho LMDeploy (thao tác này chỉ chạy một lần)...",
                         gr.update(interactive=False),
                         gr.update(interactive=False),
                         gr.update(interactive=False),
                         gr.update(interactive=False),
                         gr.update(),
                         gr.update(), gr.update(), gr.update(), gr.update(),
                         gr.update(), # conv_tab
                         *slot_no_updates
                    )
                    
                    try:
                        # Use GPU for merging if available for speed
                        # We use the Base Model specified
                        from vieneu.standard import VieNeuTTS
                        base_repo = BACKBONE_CONFIGS[custom_base_model]["repo"]
                        merge_device = "cuda" if torch.cuda.is_available() else "cpu"
                        
                        print(f"   • Loading base: {base_repo} ({merge_device})")
                        temp_tts = VieNeuTTS(
                            backbone_repo=base_repo,
                            backbone_device=merge_device, 
                            codec_repo=codec_config["repo"],
                            codec_device="cpu", # Codec unused for merging, keep on CPU
                            hf_token=custom_hf_token
                        )
                        
                        print(f"   • Loading Adapter: {custom_model_id}")
                        temp_tts.load_lora_adapter(custom_model_id.strip(), hf_token=custom_hf_token)
                        
                        print(f"   • Merging...")
                        if hasattr(temp_tts.backbone, "merge_and_unload"):
                            temp_tts.backbone = temp_tts.backbone.merge_and_unload()
                        
                        print(f"   • Saving to cache: {cache_dir}")
                        temp_tts.backbone.save_pretrained(cache_dir)
                        temp_tts.tokenizer.save_pretrained(cache_dir)
                        
                        # Fix for LMDeploy: Explicitly save legacy tokenizer files (vocab.json, merges.txt)
                        # because LMDeploy/Transformers might default to slow tokenizer if fast one has issues,
                        # and save_pretrained on fast tokenizer sometimes omits legacy files.
                        try:
                            print("   • Ensuring legacy tokenizer files...")
                            from transformers import AutoTokenizer
                            slow_tokenizer = AutoTokenizer.from_pretrained(base_repo, use_fast=False)
                            slow_tokenizer.save_pretrained(cache_dir)
                        except Exception as e:
                            print(f"   ⚠️ Warning: Could not save slow tokenizer files: {e}")

                        # Save voices.json to cache directory so FastVieNeuTTS can find it
                        print(f"   • Saving voices definition...")
                        import json
                        voices_json_path = os.path.join(cache_dir, "voices.json")
                        voices_content = {
                             "meta": { "note": "Automatically generated during LoRA merge" },
                             "default_voice": temp_tts._default_voice,
                             "presets": temp_tts._preset_voices
                        }
                        with open(voices_json_path, 'w', encoding='utf-8') as f:
                             json.dump(voices_content, f, ensure_ascii=False, indent=2)

                        del temp_tts
                        cleanup_gpu_memory()
                        print("   ✅ Merge & Save successfully!")
                        
                    except Exception as e:
                        import traceback
                        traceback.print_exc()
                        raise RuntimeError(f"Failed to merge & save LoRA for LMDeploy: {e}")

            print(f"📦 Loading optimized model...")
            print(f"   Backbone: {target_backbone_repo} on {backbone_device}")
            print(f"   Codec: {codec_config['repo']} on {codec_device}")
            print(f"   Triton: Enabled")
            
            try:
                from vieneu.fast import FastVieNeuTTS
                tts = FastVieNeuTTS(
                    backbone_repo=target_backbone_repo,
                    backbone_device=backbone_device,
                    codec_repo=codec_config["repo"],
                    codec_device=codec_device,
                    memory_util=0.3,
                    tp=1,
                    enable_prefix_caching=False,
                    enable_triton=True,
                    hf_token=custom_hf_token
                )
                using_lmdeploy = True
                
                # Legacy caching removed
                print(f"   ✅ Optimized backend initialized")
                
            except Exception as e:
                import traceback
                traceback.print_exc()
                
                error_str = str(e)
                if "$env:CUDA_PATH" in error_str:
                    lmdeploy_error_reason = "Không tìm thấy biến môi trường CUDA_PATH. Vui lòng cài đặt NVIDIA GPU Computing Toolkit."
                else:
                    lmdeploy_error_reason = f"{error_str}"
                
                yield (
                    f"⚠️ LMDeploy Init Error: {lmdeploy_error_reason}. Đang loading model với backend mặc định - tốc độ chậm hơn so với lmdeploy...",
                    gr.update(interactive=False),
                    gr.update(interactive=False),
                    gr.update(interactive=False),
                    gr.update(interactive=False),
                    gr.update(),
                    gr.update(), gr.update(), gr.update(), gr.update(),
                    gr.update(), # conv_tab
                    *slot_no_updates
                )
                time.sleep(1)
                use_lmdeploy = False
                using_lmdeploy = False
        
        if not use_lmdeploy:
            print(f"📦 Using original backend")

            if device_choice == "Auto":
                repo_lower = backbone_config['repo'].lower()
                is_gguf_backbone = "gguf" in repo_lower

                if is_gguf_backbone:
                    # GGUF backbones (llama-cpp-python): Metal on Mac, CUDA on Windows/Linux
                    if sys.platform == "darwin":
                        backbone_device = "gpu"  # llama-cpp-python uses Metal via n_gpu_layers
                    else:
                        try:
                            import torch
                            backbone_device = "gpu" if torch.cuda.is_available() else "cpu"
                        except ImportError:
                            backbone_device = "cpu"
                else:
                    # PyTorch backbones (Standard, Turbo GPU): use native torch device
                    try:
                        import torch
                        if sys.platform == "darwin":
                            backbone_device = "mps" if torch.backends.mps.is_available() else "cpu"
                        else:
                            backbone_device = "cuda" if torch.cuda.is_available() else "cpu"
                    except ImportError:
                        backbone_device = "cpu"

                # Codec device
                if "ONNX" in codec_choice:
                    codec_device = "cpu"
                else:
                    try:
                        import torch
                        if sys.platform == "darwin":
                            codec_device = "mps" if torch.backends.mps.is_available() else "cpu"
                        else:
                            codec_device = "cuda" if torch.cuda.is_available() else "cpu"
                    except ImportError:
                        codec_device = "cpu"

            elif device_choice == "MPS":
                backbone_device = "mps"
                codec_device = "mps" if "ONNX" not in codec_choice else "cpu"

            else:
                backbone_device = device_choice.lower()
                codec_device = device_choice.lower()

                if "ONNX" in codec_choice:
                    codec_device = "cpu"

            if "gguf" in backbone_config['repo'].lower() and backbone_device == "cuda":
                # Only Llama-cpp (GGUF) uses the 'gpu' string for CUDA
                backbone_device = "gpu"
            
            print(f"📦 Loading model...")
            print(f"   Backbone: {backbone_config['repo']} on {backbone_device}")
            print(f"   Codec: {codec_config['repo']} on {codec_device}")
            
            if "v3-Nano" in backbone_choice:
                print("   🪶 Mode: v3 Nano (ONNX/CPU, 24 kHz)")
                tts = Vieneu(
                    mode="v3nano",
                    backbone_repo=backbone_config["repo"],
                    hf_token=custom_hf_token,
                )
            elif "v3-Turbo" in backbone_choice:
                # VieNeu v3 Turbo. CPU → ONNX Runtime; GPU → PyTorch. The backend is
                # auto-selected from the device inside Vieneu(mode="v3turbo"); ONNX
                # graphs are fetched from the model repo's onnx/ subfolder.
                print("   🆕 Mode: v3 Turbo (CPU=ONNX / GPU=PyTorch)")
                # Map the app's device string to what the v3 engine understands.
                v3_device = "cpu" if str(backbone_device).lower() == "cpu" else "auto"
                # precision: "int8" (mặc định, subfolder onnx_int8) | "fp32" (onnx_update).
                # Chỉ ảnh hưởng đường CPU/ONNX; trên GPU dùng PyTorch nên bỏ qua.
                v3_precision = backbone_config.get("precision", "int8")
                print(f"   🎚️  Precision: {v3_precision}")
                tts = Vieneu(
                    mode="v3turbo",
                    backbone_repo=backbone_config["repo"],
                    device=v3_device,
                    precision=v3_precision,
                    hf_token=custom_hf_token,
                )
            elif "v2-Turbo" in backbone_choice:
                # VieNeu v2 Turbo uses the dedicated backend
                print("   ⚡ Mode: Turbo")
                mode = "turbo_gpu" if "GPU" in backbone_choice else "turbo"
                tts = Vieneu(
                    mode=mode,
                    backbone_repo=backbone_config["repo"],
                    decoder_repo=codec_config["repo"],
                    device=backbone_device,
                    backend="lmdeploy" if force_lmdeploy and "GPU" in backbone_choice else "standard",
                    hf_token=custom_hf_token
                )
            else:
                from vieneu.standard import VieNeuTTS
                tts = VieNeuTTS(
                    backbone_repo=backbone_config["repo"],
                    backbone_device=backbone_device,
                    codec_repo=codec_config["repo"],
                    codec_device=codec_device,
                    hf_token=custom_hf_token,
                    gguf_filename=backbone_config.get("gguf_filename")
                )

            # Perform LoRA Merge if needed (ONLY for Standard Backend)
            # For LMDeploy, we handled it above by saving to disk
            if is_merged_lora and custom_loading and not using_lmdeploy:
                yield (
                    f"🔄 Đang tải và merge LoRA adapter: {custom_model_id}...",
                    gr.update(interactive=False), gr.update(interactive=False), gr.update(interactive=False), gr.update(interactive=False), gr.update(),
                    gr.update(), gr.update(), gr.update(), gr.update(),
                    gr.update(), # conv_tab
                    *slot_no_updates
                )
                try:
                    # 1. Load Adapter
                    tts.load_lora_adapter(custom_model_id.strip(), hf_token=custom_hf_token)
                    
                    # 2. Merge and Unload
                    # Check if backbone matches expected type for merge
                    if hasattr(tts, 'backbone') and hasattr(tts.backbone, 'merge_and_unload'):
                        print("   🔄 Merging LoRA into backbone...")
                        tts.backbone = tts.backbone.merge_and_unload()
                        
                        # Reset LoRA state so it behaves like a normal model
                        tts._lora_loaded = False 
                        tts._current_lora_repo = None
                        print("   ✅ Merged successfully!")
                    else:
                        print("   ⚠️ Warning: Model does not support merge_and_unload, keeping adapter active.")
                        
                except Exception as e:
                     raise RuntimeError(f"Failed to merge LoRA: {e}")

            using_lmdeploy = False
        
        current_backbone = backbone_choice
        current_codec = codec_choice
        model_loaded = True
        
        # Success message with optimization info
        backend_name = "🚀 LMDeploy (Optimized)" if using_lmdeploy else "📦 Standard"
        device_info = "cuda" if use_lmdeploy else (backbone_device if not use_lmdeploy else "N/A")
        
        streaming_support = "✅ Có" if backbone_config['supports_streaming'] else "❌ Không"
        preencoded_note = "\n⚠️ Codec này cần sử dụng pre-encoded codes (.pt files)" if codec_config['use_preencoded'] else ""
        
        opt_info = ""
        if using_lmdeploy and hasattr(tts, 'get_optimization_stats'):
            stats = tts.get_optimization_stats()
            opt_info = (
                f"\n\n🔧 Tối ưu hóa:"
                f"\n  • Triton: {'✅' if stats['triton_enabled'] else '❌'}"
                f"\n  • Max Batch Size (Default): {stats.get('max_batch_size', 'N/A')}"
                f"\n  • Reference Cache: {stats['cached_references']} voices"
                f"\n  • Prefix Caching: ❌"
            )
        
        warning_msg = ""
        if lmdeploy_error_reason:
             warning_msg = (
                 f"\n\n⚠️ **Cảnh báo:** Không thể kích hoạt LMDeploy (Optimized Backend) do lỗi sau:\n"
                 f"👉 {lmdeploy_error_reason}\n"
                 f"💡 Hệ thống đã tự động chuyển về chế độ Standard (chậm hơn)."
             )

        success_msg = get_model_status_message()
        if warning_msg:
            success_msg += warning_msg

        try:
            saved_voices = load_user_voices(tts)
            if saved_voices:
                print(f"   💾 Loaded {len(saved_voices)} saved voice(s)")
        except Exception as e:
            print(f"   ⚠️ Không đọc được giọng đã lưu: {e}")
            
        # Prepare voice update
        try:
            # Get voices with descriptions for UI from SDK
            voices = tts.list_preset_voices()
        except Exception:
            voices = []

        has_voices = len(voices) > 0
        
        if has_voices:
            default_v = tts._default_voice
            
            # Helper to get values list
            is_tuple = (len(voices) > 0 and isinstance(voices[0], tuple))
            voice_values = [v[1] for v in voices] if is_tuple else voices
            
            if not default_v and voice_values:
                 default_v = voice_values[0]

            # Ensure default_v is in the list and selected correctly
            if default_v and default_v not in voice_values:
                if is_tuple:
                    # Try to find a nice description if possible, else use ID
                    voices.append((default_v, default_v))
                else:
                    voices.append(default_v)
            
            # Sort voices by name/label for better UX
            if is_tuple:
                voices.sort(key=lambda x: str(x[0]))
            else:
                voices.sort()

            voice_update = gr.update(choices=voices, value=default_v, interactive=True)
            
            global PRESET_VOICES_CACHE, CONV_VOICES_CACHE
            PRESET_VOICES_CACHE = voices
            
            # Filter voices for conversation tab (podcast=True)
            # Handle both boolean True/False and string "True"/"False"
            def _check_podcast(v_id):
                val = tts._preset_voices.get(v_id, {}).get('podcast', True)
                if isinstance(val, str):
                    return val.strip().lower() == "true"
                return bool(val)

            CONV_VOICES_CACHE = [v for v in voices if _check_podcast(v[1])]
            
            slot_dd_update = gr.update(choices=CONV_VOICES_CACHE)
            
            # Show Standard Tabs
            tab_p = gr.update(visible=True)
            tab_c = gr.update(visible=_supports_cloning(backbone_choice))
            tab_sel = gr.update(selected="preset_mode")
            mode_state = "preset_mode"
        else:
            # Missing voices.json case
            msg = "⚠️ Không tìm thấy file voices.json. Vui lòng dùng Tab Voice Cloning."
            voice_update = gr.update(choices=[msg], value=msg, interactive=False)
            slot_dd_update = gr.update(choices=[])
            
            # Show Preset Tab (to see message) and Custom Tab
            tab_p = gr.update(visible=True)
            tab_c = gr.update(visible=_supports_cloning(backbone_choice))
            tab_sel = gr.update(selected="preset_mode")
            mode_state = "preset_mode"

        # Conversation tab: available for v2 (sequential) and v3 Turbo (batched).
        is_v2 = (backbone_choice == "VieNeu-TTS-v2 (GPU)" or backbone_choice == "VieNeu-TTS-v2 (CPU)")
        is_v3_conv = "v3" in (backbone_choice or "").lower()
        conv_tab_update = gr.update(visible=is_v2 or is_v3_conv)

        # Update all MAX_SPEAKERS slot dropdowns
        slot_updates = [slot_dd_update] * MAX_SPEAKERS

        yield (
            success_msg,
            gr.update(interactive=True), # btn_generate
            gr.update(interactive=True), # btn_generate_conv
            gr.update(interactive=True), # btn_load
            gr.update(interactive=False), # btn_stop
            voice_update,
            tab_p, tab_c, tab_sel, mode_state,
            conv_tab_update,
            *slot_updates
        )
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        model_loaded = False
        using_lmdeploy = False

        if "$env:CUDA_PATH" in str(e):
            yield (
                "❌ Lỗi khi tải model: Không tìm thấy biến môi trường CUDA_PATH. Vui lòng cài đặt NVIDIA GPU Computing Toolkit (https://developer.nvidia.com/cuda/toolkit)",
                gr.update(interactive=False),
                gr.update(interactive=False), # btn_generate_conv
                gr.update(interactive=True), # btn_load
                gr.update(interactive=False), # btn_stop
                gr.update(), # voice_select
                gr.update(), gr.update(), gr.update(), gr.update(),
                gr.update(), # conv_tab
                *slot_no_updates
            )
        else: 
            yield (
                f"❌ Lỗi khi tải model: {str(e)}",
                gr.update(interactive=False),
                gr.update(interactive=False),
                gr.update(interactive=True),
                gr.update(interactive=False),
                gr.update(),
                gr.update(), gr.update(), gr.update(), gr.update(),
                gr.update(), # conv_tab
                *slot_no_updates
            )


def resolve_voice_id(v_id: str) -> str:
    """Robustly resolve voice ID, handling both display labels and internal IDs."""
    if not v_id:
        return v_id
    
    global PRESET_VOICES_CACHE
    if not PRESET_VOICES_CACHE:
        return v_id
        
    for item in PRESET_VOICES_CACHE:
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            label, value = item[0], item[1]
            if v_id == value or v_id == label:
                return value
        else:
            if v_id == item:
                return item
            
    return v_id

# --- 2. DATA & HELPERS ---

# Phong cách đọc (style) đã bỏ trên v3 Turbo: style nằm sẵn trong reference
# (speaker embedding + ref codes) nên mọi lần sinh đều là giọng tự nhiên.



def _synthesize_batch_txt_files(
    batch_txt_files: list,
    ref_codes,
    v3_speaker_emb,
    ref_text_raw: str,
    auto_download_files: bool,
    batch_output_dir: str,
    use_batch: bool,
    max_batch_size_run: int,
    temperature: float,
    max_chars_chunk: int,
    is_v3: bool,
    pause_overrides=None,
    quality_session=None,
):
    """Read each TXT into a named MP3 and stream completed files to the UI."""
    global tts, current_backbone, current_codec, using_lmdeploy
    quality_warnings = []
    
    try:
        out_dir, valid_files = prepare_batch(batch_txt_files, batch_output_dir)
    except (OSError, ValueError) as err:
        yield None, f"❌ Không thể lưu audio vào thư mục đã chọn: {err}", []
        return
    max_batch_size_run = max(1, int(max_batch_size_run))
    max_chars_chunk = int(max_chars_chunk)
    total_files = len(valid_files)
    if total_files == 0:
        yield None, "❌ Không tìm thấy file .txt hợp lệ nào để xử lý.", []
        return
    
    sr = getattr(tts, "sample_rate", 48000 if is_v3 else 24000)
    completed_count = 0
    completed_paths = []
    failed_files = []
    t_batch_start = time.time()
    last_audio_path = None
    
    yield None, f"📂 Bắt đầu xử lý hàng loạt {total_files} file .txt (Treo qua đêm)...", []
    
    for file_idx, file_path in enumerate(valid_files):
        if _STOP_EVENT.is_set():
            yield last_audio_path, f"⏹️ Đã dừng hàng đợi qua đêm. Đã hoàn thành {completed_count}/{total_files} file.", ""
            return
            
        orig_fname = txt_filename(file_path)
        try:
            out_file_path = audio_path_for_txt(out_dir, file_path)
            raw_text = read_batch_text(file_path)
        except (OSError, ValueError) as err:
            failed_files.append((orig_fname, str(err)))
            yield last_audio_path, f"❌ Không đọc được {orig_fname}: {err}. Tiếp tục file sau...", ""
            continue

        if not raw_text:
            failed_files.append((orig_fname, "File rỗng hoặc không đọc được nội dung"))
            yield last_audio_path, f"⚠️ [File {file_idx+1}/{total_files}] Bỏ qua {orig_fname} vì file rỗng hoặc lỗi đọc.", ""
            continue
            
        yield last_audio_path, f"⏳ [File {file_idx+1}/{total_files}: {orig_fname}] Đang chuẩn bị văn bản ({len(raw_text):,} ký tự)...", ""
        
        try:
            raw_text = smart_reformat_script(raw_text, max_chars=max_chars_chunk)
            n_groups = len(raw_text.splitlines())
            yield last_audio_path, (
                f"✂️ [File {file_idx+1}/{total_files}: {orig_fname}] "
                f"Đã tự động tách câu thông minh thành {n_groups} nhóm; bắt đầu tạo audio..."
            ), ""
            if _STOP_EVENT.is_set():
                yield last_audio_path, "⏹️ Đã dừng tạo giọng nói.", ""
                return
            # === v3 TURBO ===
            if is_v3:
                from vieneu_utils.phonemize_text import phonemize_text_with_emotions, normalize_to_chunks_v3_with_gaps
                v3_chunks, v3_gaps = normalize_to_chunks_v3_with_gaps(raw_text, max_chars=max_chars_chunk)
                v3_bs = max(1, int(max_batch_size_run)) if use_batch else 1
                v3_engine_dev = getattr(getattr(tts, "engine", None), "device", None)
                v3_can_batch = (
                    v3_bs > 1 and len(v3_chunks) > 1
                    and v3_engine_dev is not None and v3_engine_dev.type == "cuda"
                )
                
                if quality_session is not None:
                    wav = None
                    for result, message in quality_session.generate(raw_text, temperature, pause_overrides):
                        yield last_audio_path, f"[{orig_fname}] {message}", ""
                        if result is not None:
                            wav = result
                    if _STOP_EVENT.is_set():
                        yield last_audio_path, "⏹️ Đã dừng Quality+.", ""
                        return
                elif v3_can_batch:
                    from vieneu.v3_turbo_serve import V3TurboBatchEngine
                    if getattr(tts, "_v3_batch_engine", None) is None:
                        tts._v3_batch_engine = V3TurboBatchEngine(tts.engine)
                    v3_phs = [phonemize_text_with_emotions(c) for c in v3_chunks]
                    v3_order = sorted(range(len(v3_chunks)), key=lambda k: len(v3_phs[k]))
                    v3_wavs = [None] * len(v3_chunks)
                    for bi, i in enumerate(range(0, len(v3_order), v3_bs)):
                        if _STOP_EVENT.is_set():
                            yield last_audio_path, "⏹️ Đã dừng tạo giọng nói.", ""
                            return
                        idxs = v3_order[i:i + v3_bs]
                        yield last_audio_path, f"⚡ [File {file_idx+1}/{total_files}: {orig_fname}] Lô {bi + 1}/{(len(v3_order)+v3_bs-1)//v3_bs} ({len(idxs)} đoạn)...", ""
                        reqs = [{"phonemes": v3_phs[j], "speaker_emb": v3_speaker_emb,
                                 "ref_codes": ref_codes, "use_ref_codes": True} for j in idxs]
                        for j, w in zip(idxs, tts._v3_batch_engine.generate_batch(
                                reqs, temperature=temperature, max_new_frames=300)):
                            v3_wavs[j] = w
                    wav = join_audio_chunks(
                        v3_wavs, sr=sr,
                        silence_ps=gaps_to_silence(v3_gaps, pause_overrides),
                    )
                else:
                    total_v3 = len(v3_chunks)
                    v3_wavs = []
                    for ci, chunk in enumerate(v3_chunks):
                        if _STOP_EVENT.is_set():
                            yield last_audio_path, "⏹️ Đã dừng tạo giọng nói.", ""
                            return
                        yield last_audio_path, f"⏳ [File {file_idx+1}/{total_files}: {orig_fname}] Đang đọc đoạn {ci+1}/{total_v3}...", ""
                        ph = phonemize_text_with_emotions(chunk)
                        chunk_wav = tts.engine.infer(
                            phonemes=ph, speaker_emb=v3_speaker_emb, ref_codes=ref_codes,
                            use_ref_codes=True, temperature=temperature, max_new_frames=300
                        )
                        v3_wavs.append(chunk_wav if chunk_wav is not None else np.zeros(0, dtype=np.float32))
                    wav = join_audio_chunks(
                        v3_wavs, sr=sr,
                        silence_ps=gaps_to_silence(v3_gaps, pause_overrides),
                    )
                
                if wav is None or len(wav) == 0:
                    failed_files.append((orig_fname, "Không sinh được audio"))
                    yield last_audio_path, f"❌ [File {file_idx+1}/{total_files}: {orig_fname}] Không sinh được audio, tiếp tục file sau...", ""
                    continue
                sf.write(out_file_path, wav, sr)
                if quality_session is not None:
                    quality_session.save_report(out_file_path)
                    suspects = [str(r["segment"]) for r in quality_session.report if r["suspect"]]
                    if suspects:
                        quality_warnings.append(f"{orig_fname}: đoạn {', '.join(suspects)}")

            # === v2 / v1 ===
            else:
                is_v2_turbo = "v2-Turbo" in (current_backbone or "")
                if is_v2_turbo:
                    text_chunks = phonemize_to_chunks(raw_text, max_chars=max_chars_chunk)
                else:
                    text_chunks = normalize_to_chunks(raw_text, max_chars=max_chars_chunk)
                    
                total_chunks = len(text_chunks)
                all_wavs = []
                
                if is_v2_turbo:
                    for ci, chunk in enumerate(text_chunks):
                        if _STOP_EVENT.is_set():
                            yield last_audio_path, "⏹️ Đã dừng tạo giọng nói.", ""
                            return
                        yield last_audio_path, f"⚡ [File {file_idx+1}/{total_files}: {orig_fname}] Turbo v2: đoạn {ci+1}/{total_chunks}...", ""
                        chunk_wav = tts.infer(
                            chunk.text, ref_codes=ref_codes, temperature=temperature,
                            max_chars=max_chars_chunk, skip_normalize=True, skip_phonemize=True
                        )
                        if chunk_wav is not None and len(chunk_wav) > 0:
                            all_wavs.append(chunk_wav)
                            if ci < total_chunks - 1:
                                sil_dur = get_silence_duration_v2(chunk, pause_overrides)
                                all_wavs.append(np.zeros(int(sr * sil_dur), dtype=np.float32))
                    final_wav = join_audio_chunks(all_wavs, sr=sr, silence_p=0.0)
                elif use_batch and using_lmdeploy and hasattr(tts, 'infer_batch') and total_chunks > 1:
                    num_batches = (total_chunks + max_batch_size_run - 1) // max_batch_size_run
                    for bi, i in enumerate(range(0, total_chunks, max_batch_size_run)):
                        if _STOP_EVENT.is_set():
                            yield last_audio_path, "⏹️ Đã dừng tạo giọng nói.", ""
                            return
                        yield last_audio_path, f"⚡ [File {file_idx+1}/{total_files}: {orig_fname}] Batch {bi+1}/{num_batches}...", ""
                        current_batch = text_chunks[i : i + max_batch_size_run]
                        batch_wavs = tts.infer_batch(
                            current_batch, ref_codes=ref_codes, ref_text=ref_text_raw,
                            max_batch_size=max_batch_size_run, temperature=temperature, skip_normalize=True
                        )
                        for chunk_wav in batch_wavs:
                            if chunk_wav is not None and len(chunk_wav) > 0:
                                all_wavs.append(chunk_wav)
                    final_wav = join_audio_chunks(all_wavs, sr=sr, crossfade_p=0.03)
                else:
                    for ci, chunk in enumerate(text_chunks):
                        if _STOP_EVENT.is_set():
                            yield last_audio_path, "⏹️ Đã dừng tạo giọng nói.", ""
                            return
                        yield last_audio_path, f"⏳ [File {file_idx+1}/{total_files}: {orig_fname}] Đoạn {ci+1}/{total_chunks}...", ""
                        chunk_wav = tts.infer(
                            chunk, ref_codes=ref_codes, ref_text=ref_text_raw,
                            temperature=temperature, max_chars=max_chars_chunk, skip_normalize=True
                        )
                        if chunk_wav is not None and len(chunk_wav) > 0:
                            all_wavs.append(chunk_wav)
                    final_wav = join_audio_chunks(all_wavs, sr=sr, crossfade_p=0.03)
                
                if not all_wavs:
                    failed_files.append((orig_fname, "Không sinh được audio"))
                    yield last_audio_path, f"❌ [File {file_idx+1}/{total_files}: {orig_fname}] Không sinh được audio, tiếp tục file sau...", ""
                    continue
                    
                final_wav = postprocess_audio(final_wav, sr, speed=0.88, volume=0.80)
                sf.write(out_file_path, final_wav, sr)

            allow_generated_audio(out_file_path)
            completed_count += 1
            last_audio_path = out_file_path
            file_size_mb = os.path.getsize(out_file_path) / (1024 * 1024)
            safe_dl_name = os.path.basename(out_file_path)
            completed_paths.append(out_file_path)

            next_info = (
                f" Chuyển sang file {file_idx+2}/{total_files}: `{txt_filename(valid_files[file_idx+1])}`..."
                if file_idx + 1 < total_files
                else " Đã hoàn tất danh sách!"
            )
            status_msg = f"✅ [Đã xong {completed_count}/{total_files} file] Đã lưu: {safe_dl_name} ({file_size_mb:.1f} MB)!{next_info}"
            yield out_file_path, status_msg, list(completed_paths)
            
        except Exception as err:
            import traceback
            traceback.print_exc()
            failed_files.append((orig_fname, str(err)))
            yield last_audio_path, f"❌ Lỗi ở file {orig_fname}: {str(err)}. Tiếp tục xử lý các file còn lại...", ""
            
        finally:
            cleanup_gpu_memory()
            gc.collect()
            
    total_time = time.time() - t_batch_start
    fail_note = f"\n⚠️ File lỗi ({len(failed_files)}): " + ", ".join(f"{f[0]} ({f[1]})" for f in failed_files) if failed_files else ""
    if quality_warnings:
        fail_note += "\n⚠️ Quality+ — cần nghe kiểm tra: " + "; ".join(quality_warnings)
    summary_msg = (
        f"🎉 HOÀN THÀNH TOÀN BỘ HÀNG ĐỢI ({completed_count}/{total_files} file thành công)!\n"
        f"⏱️ Tổng thời gian chạy: {_format_duration(total_time)}\n"
        f"📁 Tất cả audio đã được lưu an toàn tại: {os.path.abspath(out_dir)}\n"
        f"📥 Audio đã hoàn thành nằm trong danh sách bên dưới để tải lại.{fail_note}"
    )
    yield last_audio_path, summary_msg, list(completed_paths)


def synthesize_speech(text: str, voice_choice: str, custom_audio, custom_text: str,
                      mode_tab: str, generation_mode: str, use_batch: bool, max_batch_size_run: int,
                      temperature: float, max_chars_chunk: int,
                      denoise_ref: bool = True, session_id: str = None,
                      batch_txt_files: list = None, auto_download_files: bool = True,
                      batch_output_dir: str = "outputs/batch_cloned",
                      pause_dot: float = 0.75, pause_comma: float = 0.40,
                      pause_question: float = 0.80, pause_exclamation: float = 0.80,
                      pause_colon: float = 0.40, pause_semicolon: float = 0.40,
                      pause_ellipsis: float = 0.90, pause_newline: float = 1.10,
                      quality_plus: bool = False):
    """Synthesis with optimization support, batch overnight processing, and max batch size control"""
    global tts, current_backbone, current_codec, model_loaded, using_lmdeploy
    
    _STOP_EVENT.clear()  # Reset for new generation
    
    if not model_loaded or tts is None:
        yield None, "⚠️ Vui lòng tải model trước!"
        return
    
    is_batch_txt = bool(batch_txt_files and len(batch_txt_files) > 0 and mode_tab == "custom_mode")
    if not is_batch_txt and (not text or text.strip() == ""):
        yield None, "⚠️ Vui lòng nhập văn bản!"
        return
    
    raw_text = text.strip() if text else ""
    pause_overrides = _pause_overrides(
        pause_dot, pause_comma, pause_question, pause_exclamation,
        pause_colon, pause_semicolon, pause_ellipsis, pause_newline,
    )
    
    codec_config = CODEC_CONFIGS[current_codec]
    use_preencoded = codec_config['use_preencoded']
    
    # Setup Reference
    yield None, "📄 Đang xử lý Reference..."
    
    is_v3 = "v3" in (current_backbone or "").lower()
    quality_session = None
    quality_enabled = quality_plus and mode_tab == "custom_mode"
    if quality_enabled and "v3-turbo" not in (current_backbone or "").lower():
        yield None, "⚠️ Quality+ hiện hỗ trợ Voice Cloning với VieNeu v3 Turbo."
        return
    v3_speaker_emb = None
    try:
        ref_codes = None
        ref_text_raw = ""
        v3_voice_token_id = None
        v_id = None

        if mode_tab == "preset_mode":
            if not voice_choice:
                raise ValueError("Vui lòng chọn giọng mẫu.")
            if "⚠️" in voice_choice:
                raise ValueError("Không có giọng mẫu khả dụng. Vui lòng chuyển sang Tab Voice Cloning.")

            # Use SDK method - handles caching and JSON internally
            v_id = resolve_voice_id(voice_choice)
            voice_data = tts.get_preset_voice(v_id)
            if is_v3:
                # v3 presets carry a speaker embedding + reference codes.
                v3_speaker_emb = voice_data['speaker_emb']
                ref_codes = voice_data.get('codes')
            else:
                ref_codes = voice_data['codes']
                ref_text_raw = voice_data.get('text', '')
                v3_voice_token_id = voice_data.get('reserved_id')

        elif mode_tab == "custom_mode":
            if custom_audio is None:
                raise ValueError("Vui lòng upload file Audio mẫu (Reference Audio)!")

            cb_lower = (current_backbone or "").lower()
            # Turbo v2 and v3 clone purely from audio → no reference transcript needed.
            needs_ref_text = "v2-turbo" not in cb_lower and "v3" not in cb_lower
            if needs_ref_text and (not custom_text or not custom_text.strip()):
                raise ValueError("Vui lòng nhập nội dung văn bản của Audio mẫu (Reference Text)!")

            ref_text_raw = custom_text.strip() if custom_text else ""
            if is_v3:
                # Enroll once: (optionally) denoise + trim ≤8s → speaker embedding + ref codes.
                if quality_enabled:
                    from apps.quality_plus import prepare_reference, transcribe, words, QualitySession
                    yield None, "Quality+: chọn đoạn mẫu, kiểm tra lời bằng Whisper trên CPU (lần đầu có thể lâu)..."
                    ref_wav, ref_sr = prepare_reference(custom_audio)
                    if denoise_ref and getattr(tts.engine, "denoiser", None) is not None:
                        ref_wav = tts.engine.denoiser.denoise(ref_wav, ref_sr)
                        ref_sr = 44100
                    heard = transcribe(ref_wav, ref_sr)
                    if _STOP_EVENT.is_set():
                        yield None, "⏹️ Đã dừng Quality+."
                        return
                    if len(words(heard)) < 3:
                        raise ValueError("Whisper không nhận rõ lời mẫu. Hãy chọn audio sạch hơn.")
                    with tempfile.TemporaryDirectory(prefix="vieneu_quality_") as ref_dir:
                        ref_path = os.path.join(ref_dir, "reference.wav")
                        sf.write(ref_path, ref_wav, ref_sr)
                        v3_speaker_emb, ref_codes = tts.encode_reference(ref_path, denoise=False)
                    quality_session = QualitySession(tts, v3_speaker_emb, ref_codes, _STOP_EVENT,
                        rate=len(words(heard)) / (len(ref_wav) / ref_sr))
                    yield None, f"Quality+: nội dung mẫu nhận diện: {heard}"
                else:
                    v3_speaker_emb, ref_codes = tts.encode_reference(custom_audio, denoise=denoise_ref)
            else:
                ref_codes = tts.encode_reference(custom_audio)

        # Ensure numpy for inference
        if 'torch' in sys.modules:
            import torch
            if isinstance(ref_codes, torch.Tensor):
                ref_codes = ref_codes.cpu().numpy()

    except Exception as e:
        yield None, f"❌ Lỗi xử lý Reference Audio: {str(e)}"
        return
    
    # === XỬ LÝ HÀNG LOẠT FILE TXT QUA ĐÊM TRONG TAB VOICE CLONING ===
    if is_batch_txt:
        yield from _synthesize_batch_txt_files(
            batch_txt_files=batch_txt_files,
            ref_codes=ref_codes,
            v3_speaker_emb=v3_speaker_emb,
            ref_text_raw=ref_text_raw,
            auto_download_files=auto_download_files,
            batch_output_dir=batch_output_dir,
            use_batch=use_batch,
            max_batch_size_run=max_batch_size_run,
            temperature=temperature,
            max_chars_chunk=max_chars_chunk,
            is_v3=is_v3,
            pause_overrides=pause_overrides,
            quality_session=quality_session,
        )
        return
    
    # === STANDARD MODE ===
    if generation_mode == "Standard (Một lần)":
        # ============================ v3 TURBO BRANCH ========================
        # VieNeu-TTS v3 Turbo: split the text into chunks and run them through the
        # batched serving engine (vieneu.v3_turbo_serve) so multiple chunks share
        # each forward step (big GPU throughput win at Batch Size 32). Falls back
        # to single-utterance generation on CPU / 1 chunk / batching disabled.
        if "v3" in (current_backbone or "").lower():
            _t0 = time.time()
            yield None, "⏳ Đang tổng hợp (v3 Turbo)..."
            sr_v3 = getattr(tts, "sample_rate", 48000)
            try:
                from vieneu_utils.phonemize_text import phonemize_text_with_emotions

                # Chia chunk theo TEXT đã normalize (giống v2-gpu, không vụn), giữ
                # inline cues; phonemize TỪNG chunk khi dựng request.
                v3_chunks, v3_gaps = normalize_to_chunks_v3_with_gaps(raw_text, max_chars=max_chars_chunk)
                v3_bs = max(1, int(max_batch_size_run)) if use_batch else 1
                v3_engine_dev = getattr(getattr(tts, "engine", None), "device", None)
                v3_can_batch = (
                    v3_bs > 1 and len(v3_chunks) > 1
                    and v3_engine_dev is not None and v3_engine_dev.type == "cuda"
                )

                if quality_session is not None:
                    wav = None
                    for result, message in quality_session.generate(raw_text, temperature, pause_overrides):
                        yield None, message
                        if result is not None:
                            wav = result
                    if _STOP_EVENT.is_set():
                        yield None, "⏹️ Đã dừng Quality+."
                        return
                elif v3_can_batch:
                    from vieneu.v3_turbo_serve import V3TurboBatchEngine
                    if getattr(tts, "_v3_batch_engine", None) is None:
                        tts._v3_batch_engine = V3TurboBatchEngine(tts.engine)
                    # Phonemize từng TEXT chunk (giữ inline cues) rồi gộp lô theo ĐỘ DÀI
                    # phoneme (length bucketing): các prompt cùng cỡ vào chung lô để
                    # giảm left-padding — đỡ tốn prefill và đỡ nhiễu số học do pad.
                    # Kết quả được trả về đúng vị trí gốc nên khớp v3_gaps khi join.
                    v3_phs = [phonemize_text_with_emotions(c) for c in v3_chunks]
                    v3_order = sorted(range(len(v3_chunks)), key=lambda k: len(v3_phs[k]))
                    v3_wavs = [None] * len(v3_chunks)
                    for bi, i in enumerate(range(0, len(v3_order), v3_bs)):
                        if _STOP_EVENT.is_set():
                            yield None, "⏹️ Đã dừng tạo giọng nói."
                            return
                        idxs = v3_order[i:i + v3_bs]
                        yield None, f"⚡ v3 Turbo: lô {bi + 1} ({len(idxs)} đoạn, batch size {v3_bs})..."
                        reqs = [{"phonemes": v3_phs[j], "speaker_emb": v3_speaker_emb,
                                 "ref_codes": ref_codes, "use_ref_codes": True} for j in idxs]
                        for j, w in zip(idxs, tts._v3_batch_engine.generate_batch(
                                reqs, temperature=temperature, max_new_frames=300)):
                            v3_wavs[j] = w
                    wav = join_audio_chunks(
                        v3_wavs, sr=sr_v3,
                        silence_ps=gaps_to_silence(v3_gaps, pause_overrides),
                    )
                else:
                    # CPU (ONNX) hoặc GPU khi tắt batch: xử lý TUẦN TỰ từng đoạn.
                    # Gọi engine 1 lần / đoạn (giống nhánh batch nhưng tuần tự) để có
                    # ĐÚNG 1 wav / đoạn -> khớp với v3_gaps khi join, đồng thời báo cho
                    # người dùng đang xử lý đến đoạn nào + ước tính thời gian còn lại —
                    # quan trọng trên CPU vì mỗi đoạn có thể mất nhiều giây.
                    # (KHÔNG enumerate tts.infer(): infer() trả về 1 mảng đã ghép sẵn,
                    #  lặp qua nó sẽ ra từng sample numpy.float32 -> len() ném lỗi.)
                    total_v3 = len(v3_chunks)
                    v3_wavs = []
                    chunk_durations = []
                    last_t = time.time()
                    for i, chunk in enumerate(v3_chunks):
                        if _STOP_EVENT.is_set():
                            yield None, "⏹️ Đã dừng tạo giọng nói."
                            return
                        yield None, f"⏳ v3 Turbo: Đang xử lý đoạn {i + 1}/{total_v3}..."
                        ph = phonemize_text_with_emotions(chunk)
                        chunk_wav = tts.engine.infer(
                            phonemes=ph, speaker_emb=v3_speaker_emb, ref_codes=ref_codes,
                            use_ref_codes=True,
                            temperature=temperature, max_new_frames=300)
                        now = time.time()
                        chunk_durations.append(now - last_t)
                        last_t = now
                        # Luôn append (kể cả rỗng) để v3_wavs khớp 1-1 với v3_chunks —
                        # lọc bớt ở đây sẽ làm lệch v3_gaps khi join.
                        v3_wavs.append(chunk_wav if chunk_wav is not None
                                       else np.zeros(0, dtype=np.float32))
                        done = i + 1
                        if done < total_v3:
                            avg = sum(chunk_durations) / len(chunk_durations)
                            eta = avg * (total_v3 - done)
                            yield None, (
                                f"⏳ v3 Turbo: Đã xong {done}/{total_v3} đoạn "
                                f"(ước tính còn lại: {_format_duration(eta)})... "
                                f"đang xử lý đoạn {done + 1}/{total_v3}"
                            )
                    wav = join_audio_chunks(
                        v3_wavs, sr=sr_v3,
                        silence_ps=gaps_to_silence(v3_gaps, pause_overrides),
                    )
            except Exception as e:
                yield None, f"❌ Lỗi tổng hợp (v3 Turbo): {str(e)}"
                return
            if wav is None or len(wav) == 0:
                yield None, "❌ Không sinh được audio nào."
                return
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
                sf.write(tmp.name, wav, sr_v3)
                out_path_v3 = tmp.name
            quality_note = ""
            if quality_session is not None:
                quality_session.save_report(out_path_v3)
                suspect = sum(r["suspect"] for r in quality_session.report)
                quality_note = f" Quality+: {suspect} đoạn cần nghe kiểm tra; báo cáo .quality.json cạnh audio."
            _dt = time.time() - _t0
            _spd = f", Tốc độ: {len(wav)/sr_v3/_dt:.2f}x realtime" if _dt > 0 else ""
            yield out_path_v3, f"✅ Hoàn tất! (v3 Turbo, Thời gian: {_dt:.2f}s{_spd}){quality_note}"
            cleanup_gpu_memory()
            return
        # ========================== end v3 TURBO BRANCH ======================

        backend_name = "LMDeploy" if using_lmdeploy else "Standard"

        is_v2_turbo = "v2-Turbo" in (current_backbone or "")
        
        if is_v2_turbo:
            text_chunks = phonemize_to_chunks(raw_text, max_chars=max_chars_chunk)
        else:
            # Chia chunk SAU normalize: normalize cả văn bản trước rồi mới cắt theo
            # độ dài ĐÃ chuẩn hóa (tránh chunk phình quá max_chars khi norm mở rộng).
            text_chunks = normalize_to_chunks(raw_text, max_chars=max_chars_chunk)
            
        total_chunks = len(text_chunks)

        batch_info = " (Batch Mode)" if use_batch and using_lmdeploy and total_chunks > 1 else ""
        
        # Show batch size info
        batch_size_info = ""
        if use_batch and using_lmdeploy and hasattr(tts, 'max_batch_size'):
            batch_size_info = f" [Max batch: {tts.max_batch_size}]"
        
        yield None, f"🚀 Bắt đầu tổng hợp {backend_name}{batch_info}{batch_size_info} ({total_chunks} đoạn)..."
        
        all_wavs = []
        sr = 24000
        
        start_time = time.time()
        
        try:
            if is_v2_turbo:
                # Sequential processing with progress updates
                total_chunks = len(text_chunks)
                for i, chunk in enumerate(text_chunks):
                    if _STOP_EVENT.is_set():
                        yield None, "⏹️ Đã dừng tạo giọng nói."
                        return
                    yield None, f"⚡ Turbo v2: Đang xử lý đoạn {i+1}/{total_chunks}..."
                    
                    chunk_wav = tts.infer(
                        chunk.text, 
                        ref_codes=ref_codes, 
                        temperature=temperature,
                        max_chars=max_chars_chunk,
                        skip_normalize=True,
                        skip_phonemize=True
                    )
                    
                    if chunk_wav is not None and len(chunk_wav) > 0:
                        all_wavs.append(chunk_wav)
                        # Add silence between Gradio-level chunks for Turbo
                        if i < total_chunks - 1:
                            sil_dur = get_silence_duration_v2(chunk, pause_overrides)
                            sil_wav = np.zeros(int(sr * sil_dur), dtype=np.float32)
                            all_wavs.append(sil_wav)
            
            # Use batch processing if enabled and using LMDeploy (for v1)
            elif use_batch and using_lmdeploy and hasattr(tts, 'infer_batch') and total_chunks > 1:
                # Process in mini-batches to allow cancellation between batches
                num_batches = (total_chunks + max_batch_size_run - 1) // max_batch_size_run
                total_batch_duration = 0.0
                completed_batches = 0
                
                for i in range(0, total_chunks, max_batch_size_run):
                    if _STOP_EVENT.is_set():
                        print("🛑 Synthesis stopped during batch processing.")
                        yield None, "⏹️ Đã dừng tạo giọng nói."
                        return
                    
                    batch_idx = i // max_batch_size_run
                    estimate_info = ""
                    if completed_batches > 0:
                        average_batch_duration = total_batch_duration / completed_batches
                        estimated_total = average_batch_duration * num_batches
                        estimated_remaining = average_batch_duration * max(0, num_batches - batch_idx)
                        estimate_info = (
                            f" | Ước tính còn lại: {_format_duration(estimated_remaining)}"
                            f" / tổng: {_format_duration(estimated_total)}"
                        )
                    yield None, f"⚡ Đang xử lý batch {batch_idx+1}/{num_batches} (đoạn {i+1}-{min(i+max_batch_size_run, total_chunks)}){estimate_info}..."
                    
                    current_batch = text_chunks[i : i + max_batch_size_run]
                    batch_start_time = time.time()
                    batch_wavs = tts.infer_batch(
                        current_batch, 
                        ref_codes=ref_codes, 
                        ref_text=ref_text_raw,
                        max_batch_size=max_batch_size_run,
                        temperature=temperature,
                        skip_normalize=True
                    )
                    batch_duration = time.time() - batch_start_time
                    total_batch_duration += batch_duration
                    completed_batches += 1
                    average_batch_duration = total_batch_duration / completed_batches
                    estimated_total = average_batch_duration * num_batches
                    estimated_remaining = average_batch_duration * max(0, num_batches - completed_batches)
                    for chunk_wav in batch_wavs:
                        if chunk_wav is not None and len(chunk_wav) > 0:
                            all_wavs.append(chunk_wav)
                    yield None, (
                        f"✅ Xong batch {batch_idx+1}/{num_batches} "
                        f"(trung bình batch: {_format_duration(average_batch_duration)}, "
                        f"ước tính còn lại: {_format_duration(estimated_remaining)}, "
                        f"tổng: {_format_duration(estimated_total)})"
                    )

            else:
                # Sequential processing (PyTorch or GGUF v1)
                for i, chunk in enumerate(text_chunks):
                    if _STOP_EVENT.is_set():
                        yield None, "⏹️ Đã dừng tạo giọng nói."
                        return
                    yield None, f"⏳ Đang xử lý đoạn {i+1}/{total_chunks}..."
                    chunk_wav = tts.infer(
                        chunk, 
                        ref_codes=ref_codes, 
                        ref_text=ref_text_raw,
                        temperature=temperature,
                        max_chars=max_chars_chunk,
                        skip_normalize=True
                    )
                    if chunk_wav is not None and len(chunk_wav) > 0:
                        all_wavs.append(chunk_wav)
            
            if not all_wavs:
                yield None, "❌ Không sinh được audio nào."
                return
            
            yield None, "💾 Đang ghép file và lưu..."
            
            # Use utility function for joining with silence/crossfade
            # Turbo v2 đã thêm silence nội bộ; v1 Standard dùng crossfade 30ms để
            # chỗ nối giữa chunk nghe mượt hơn thay vì có khoảng ngắt cứng.
            if is_v2_turbo:
                final_wav = join_audio_chunks(all_wavs, sr=sr, silence_p=0.0)
            else:
                final_wav = join_audio_chunks(all_wavs, sr=sr, crossfade_p=0.03)
            
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
                final_wav = postprocess_audio(final_wav, sr, speed=0.88, volume=0.80)
                sf.write(tmp.name, final_wav, sr)
                output_path = tmp.name
            
            process_time = time.time() - start_time
            backend_info = f" (Backend: {'LMDeploy 🚀' if using_lmdeploy else 'Standard 📦'})"
            speed_info = f", Tốc độ: {len(final_wav)/sr/process_time:.2f}x realtime" if process_time > 0 else ""
            
            
            yield output_path, f"✅ Hoàn tất! (Thời gian: {process_time:.2f}s{speed_info}){backend_info}"
            
            # Cleanup memory
            if using_lmdeploy and hasattr(tts, 'cleanup_memory'):
                tts.cleanup_memory()
            
            cleanup_gpu_memory()
            
        except Exception as e:
            # Check for CUDA OOM specifically if torch is loaded
            if 'torch' in sys.modules:
                import torch
                if isinstance(e, torch.cuda.OutOfMemoryError):
                    cleanup_gpu_memory()
                    yield None, (
                        f"❌ GPU hết VRAM! Hãy thử:\n"
                        f"• Giảm Max Batch Size (hiện tại: {tts.max_batch_size if hasattr(tts, 'max_batch_size') else 'N/A'})\n"
                        f"• Giảm độ dài văn bản\n\n"
                        f"Chi tiết: {str(e)}"
                    )
                    return
            
            import traceback
            traceback.print_exc()
            cleanup_gpu_memory()
            yield None, f"❌ Lỗi Standard Mode: {str(e)}"
            return
    
    # === STREAMING MODE ===
    else:
        sr = 24000
        crossfade_samples = int(sr * 0.03)
        audio_queue = queue.Queue(maxsize=100)
        PRE_BUFFER_SIZE = 3
        
        end_event = threading.Event()
        error_event = threading.Event()
        error_msg = ""
        
        is_v2_turbo = "v2-Turbo" in (current_backbone or "")
        if is_v2_turbo:
            text_chunks = phonemize_to_chunks(raw_text, max_chars=max_chars_chunk)
        else:
            # Chia chunk SAU normalize: normalize cả văn bản trước rồi mới cắt theo
            # độ dài ĐÃ chuẩn hóa (tránh chunk phình quá max_chars khi norm mở rộng).
            text_chunks = normalize_to_chunks(raw_text, max_chars=max_chars_chunk)
        
        def producer_thread():
            nonlocal error_msg
            try:
                previous_tail = None
                
                for i, chunk_text in enumerate(text_chunks):
                    if _STOP_EVENT.is_set():
                        break
                    
                    if is_v2_turbo:
                        stream_gen = tts.infer_stream(
                            chunk_text.text,
                            ref_codes=ref_codes, 
                            temperature=temperature,
                            max_chars=max_chars_chunk,
                            skip_normalize=True,
                            skip_phonemize=True,
                            emotion_tag=""
                        )
                    else:
                        stream_gen = tts.infer_stream(
                            chunk_text, 
                            ref_codes=ref_codes, 
                            ref_text=ref_text_raw,
                            temperature=temperature,
                            max_chars=max_chars_chunk,
                            skip_normalize=True,
                            emotion_tag=""
                        )
                    
                    for part_idx, audio_part in enumerate(stream_gen):
                        if _STOP_EVENT.is_set():
                            break
                        if audio_part is None or len(audio_part) == 0:
                            continue
                        
                        if previous_tail is not None and len(previous_tail) > 0:
                            overlap = min(len(previous_tail), len(audio_part), crossfade_samples)
                            if overlap > 0:
                                fade_out = np.linspace(1.0, 0.0, overlap, dtype=np.float32)
                                fade_in = np.linspace(0.0, 1.0, overlap, dtype=np.float32)
                                
                                blended = (audio_part[:overlap] * fade_in + 
                                         previous_tail[-overlap:] * fade_out)
                                
                                processed = np.concatenate([
                                    previous_tail[:-overlap] if len(previous_tail) > overlap else np.array([]),
                                    blended,
                                    audio_part[overlap:]
                                ])
                            else:
                                processed = np.concatenate([previous_tail, audio_part])
                            
                            tail_size = min(crossfade_samples, len(processed))
                            previous_tail = processed[-tail_size:].copy()
                            output_chunk = processed[:-tail_size] if len(processed) > tail_size else processed
                        else:
                            tail_size = min(crossfade_samples, len(audio_part))
                            previous_tail = audio_part[-tail_size:].copy()
                            output_chunk = audio_part[:-tail_size] if len(audio_part) > tail_size else audio_part
                        
                        if len(output_chunk) > 0:
                            audio_queue.put((sr, output_chunk))
                            
                    # Add silence between chunks for Turbo v2
                    if is_v2_turbo and i < len(text_chunks) - 1:
                        sil_dur = get_silence_duration_v2(chunk_text, pause_overrides)
                        sil_wav = np.zeros(int(sr * sil_dur), dtype=np.float32)
                        audio_queue.put((sr, sil_wav))
                
                if previous_tail is not None and len(previous_tail) > 0:
                    audio_queue.put((sr, previous_tail))
                    
            except Exception as e:
                import traceback
                traceback.print_exc()
                error_msg = str(e)
                error_event.set()
            finally:
                end_event.set()
                audio_queue.put(None)
        
        threading.Thread(target=producer_thread, daemon=True).start()
        
        yield (sr, np.zeros(int(sr * 0.05))), "📄 Đang buffering..."
        
        pre_buffer = []
        while len(pre_buffer) < PRE_BUFFER_SIZE:
            try:
                item = audio_queue.get(timeout=5.0)
                if item is None:
                    break
                pre_buffer.append(item)
            except queue.Empty:
                if error_event.is_set():
                    yield None, f"❌ Lỗi: {error_msg}"
                    return
                break
        
        full_audio_buffer = []
        backend_info = "🚀 LMDeploy" if using_lmdeploy else "📦 Standard"
        for sr, audio_data in pre_buffer:
            full_audio_buffer.append(audio_data)
            yield (sr, audio_data), f"🔊 Đang phát ({backend_info})..."
        
        while True:
            try:
                item = audio_queue.get(timeout=0.05)
                if item is None:
                    break
                sr, audio_data = item
                full_audio_buffer.append(audio_data)
                yield (sr, audio_data), f"🔊 Đang phát ({backend_info})..."
            except queue.Empty:
                if error_event.is_set():
                    yield None, f"❌ Lỗi: {error_msg}"
                    break
                if end_event.is_set() and audio_queue.empty():
                    break
                continue
        
        if full_audio_buffer:
            final_wav = np.concatenate(full_audio_buffer)
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
                final_wav = postprocess_audio(final_wav, sr, speed=0.88, volume=0.80)
                sf.write(tmp.name, final_wav, sr)
                
                yield tmp.name, f"✅ Hoàn tất Streaming! ({backend_info})"
            
            # Cleanup memory
            if using_lmdeploy and hasattr(tts, 'cleanup_memory'):
                tts.cleanup_memory()
            
            cleanup_gpu_memory()

synthesize_speech_with_estimate = wrap_with_estimate(synthesize_speech)
synthesize_batch_speech_with_estimate = wrap_with_estimate(require_batch_files(synthesize_speech))

def synthesize_conversation_with_empty_estimate(*args):
    for audio_path, status in synthesize_conversation(*args):
        yield audio_path, status, "", gr.skip()

# --- CANCELLATION ---
# threading.Event is a mutable object: never reassigned, always the same reference.
# All threads share the exact same object — no scoping/serialization issues.
_STOP_EVENT = threading.Event()

# --- 3. CONVERSATION LOGIC ---

def _synthesize_conversation_v3(lines, mapping, temperature, max_chars_chunk, silence_duration, denoise_ref=True):
    """v3 Turbo conversation: batch the WHOLE conversation at batch size 32.

    Unlike the v2 path (sequential, one turn at a time), every turn is split into
    chunks and ALL chunks across ALL turns are flattened into one request list, then
    fed to the V3 batched engine in groups of 32 — regardless of which speaker each
    chunk belongs to (each request carries its own speaker ref_codes + reserved
    token). Wavs are reassembled per turn (in order) and joined with inter-turn
    silence. Yields ``(audio_path, status)`` like the v2 path. 48 kHz.
    """
    global tts
    from collections import defaultdict
    from vieneu_utils.core_utils import join_audio_chunks, gaps_to_silence
    from vieneu_utils.phonemize_text import phonemize_text_with_emotions, normalize_to_chunks_v3_with_gaps
    # NOTE: KHÔNG import vieneu.v3_turbo_serve ở đây — module đó import torch ở cấp
    # module, nên trên bản cài CPU/macOS không-torch (ONNX) sẽ lỗi "No module named
    # 'torch'". Chỉ import bên trong nhánh CUDA bên dưới (nơi thực sự cần batch engine).

    sr = getattr(tts, "sample_rate", 48000)
    t0 = time.time()

    # Resolve each speaker → (speaker_emb, ref_codes), cached per speaker.
    def _voice_for(spk_name):
        cfg = mapping.get(spk_name.lower())
        # Custom clone audio support
        if cfg and cfg.get('type') == 'Custom' and cfg.get('audio') and os.path.exists(cfg['audio']):
            try:
                emb, rc = tts.encode_reference(cfg['audio'], denoise=denoise_ref)
                if 'torch' in sys.modules:
                    import torch
                    if isinstance(rc, torch.Tensor):
                        rc = rc.cpu().numpy()
                return (np.asarray(emb, dtype=np.float32) if emb is not None else None,
                        np.asarray(rc) if rc is not None else None)
            except Exception as e:
                print(f"❌ Lỗi encode reference audio cho '{spk_name}': {e}")

        # Fallback to preset voice
        v_id = (cfg or {}).get('voice') or tts._default_voice
        try:
            vd = tts.get_preset_voice(v_id)
        except Exception:
            vd = tts.get_preset_voice(tts._default_voice)
        emb = vd.get('speaker_emb')
        rc = vd.get('codes')
        if 'torch' in sys.modules:
            import torch
            if isinstance(rc, torch.Tensor):
                rc = rc.cpu().numpy()
        return (np.asarray(emb, dtype=np.float32) if emb is not None else None,
                np.asarray(rc) if rc is not None else None)

    # CPU (ONNX) has no batched engine → run sequentially, one turn at a time.
    dev = getattr(getattr(tts, "engine", None), "device", None)
    is_cuda = dev is not None and getattr(dev, "type", None) == "cuda"
    if not is_cuda:
        all_wavs = []
        for li, line in enumerate(lines):
            if _STOP_EVENT.is_set():
                yield None, "⏹️ Đã dừng hội thoại."
                return
            cfg = mapping.get(line['speaker'].lower())
            yield None, f"⏳ [{li+1}/{len(lines)}] {line['speaker']}: {line['text'][:30]}..."
            try:
                if cfg and cfg.get('type') == 'Custom' and cfg.get('audio') and os.path.exists(cfg['audio']):
                    wav = tts.infer(line['text'], ref_audio=cfg['audio'], denoise=denoise_ref,
                                    temperature=temperature, max_chars=max_chars_chunk)
                else:
                    v_id = (cfg or {}).get('voice') or tts._default_voice
                    wav = tts.infer(line['text'], voice=v_id,
                                    temperature=temperature, max_chars=max_chars_chunk)
            except Exception as e:
                print(f"❌ Lỗi câu {li+1}: {e}")
                continue
            if wav is not None and len(wav):
                all_wavs.append(wav)
                if li < len(lines) - 1 and silence_duration > 0:
                    all_wavs.append(np.zeros(int(sr * silence_duration), dtype=np.float32))
        if not all_wavs:
            yield None, "❌ Không thể tạo được âm thanh nào!"
            return
        yield None, "🪄 Đang ghép nối âm thanh..."
        final_wav = np.concatenate(all_wavs)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
            sf.write(tmp.name, final_wav, sr)
            yield tmp.name, f"✅ Hoàn tất hội thoại! ({len(lines)} câu, {time.time()-t0:.1f}s, CPU tuần tự)"
        cleanup_gpu_memory()
        return

    voice_cache = {}
    reqs, req_line = [], []
    line_gaps = {}
    for li, line in enumerate(lines):
        key = line['speaker'].lower()
        if key not in voice_cache:
            voice_cache[key] = _voice_for(line['speaker'])
        spk_emb, ref_codes = voice_cache[key]
        # Chia chunk theo TEXT đã normalize (giống v2-gpu), giữ inline cues, rồi
        # phonemize từng chunk. Hội thoại luôn dùng phong cách Tự nhiên.
        line_chunks, line_gaps[li] = normalize_to_chunks_v3_with_gaps(line['text'], max_chars=max_chars_chunk)
        for chunk in line_chunks:
            reqs.append({"phonemes": phonemize_text_with_emotions(chunk),
                         "speaker_emb": spk_emb, "ref_codes": ref_codes,
                         "use_ref_codes": True})
            req_line.append(li)

    if not reqs:
        yield None, "❌ Không có lời thoại để tổng hợp."
        return

    if getattr(tts, "_v3_batch_engine", None) is None:
        # Chỉ tới đây khi chạy trên CUDA → torch chắc chắn có sẵn.
        from vieneu.v3_turbo_serve import V3TurboBatchEngine
        tts._v3_batch_engine = V3TurboBatchEngine(tts.engine)

    BS = 32
    total_batches = (len(reqs) + BS - 1) // BS
    # Length bucketing: gộp lô theo độ dài phoneme để giảm left-padding; kết quả
    # đặt về đúng vị trí gốc nên vẫn khớp req_line khi gom theo lời thoại.
    req_order = sorted(range(len(reqs)), key=lambda k: len(reqs[k]["phonemes"]))
    wavs_flat = [None] * len(reqs)
    for bi, i in enumerate(range(0, len(req_order), BS)):
        if _STOP_EVENT.is_set():
            yield None, "⏹️ Đã dừng hội thoại."
            return
        idxs = req_order[i:i + BS]
        yield None, f"⚡ v3 Turbo hội thoại: lô {bi + 1}/{total_batches} ({len(idxs)} đoạn, batch 32)..."
        for j, w in zip(idxs, tts._v3_batch_engine.generate_batch(
                [reqs[k] for k in idxs], temperature=temperature, max_new_frames=300)):
            wavs_flat[j] = w

    # Reassemble per turn (in order), then join turns with inter-turn silence.
    by_line = defaultdict(list)
    for w, li in zip(wavs_flat, req_line):
        by_line[li].append(w)

    all_wavs = []
    for li in range(len(lines)):
        lw = join_audio_chunks(by_line[li], sr=sr, silence_ps=gaps_to_silence(line_gaps.get(li, []))) if by_line[li] else None
        if lw is None or len(lw) == 0:
            continue
        all_wavs.append(lw)
        if li < len(lines) - 1 and silence_duration > 0:
            all_wavs.append(np.zeros(int(sr * silence_duration), dtype=np.float32))

    if not all_wavs:
        yield None, "❌ Không thể tạo được âm thanh nào!"
        return

    yield None, "🪄 Đang ghép nối âm thanh..."
    final_wav = np.concatenate(all_wavs)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
        sf.write(tmp.name, final_wav, sr)
        elapsed = time.time() - t0
        yield tmp.name, f"✅ Hoàn tất hội thoại! ({len(lines)} câu, {len(reqs)} đoạn, {elapsed:.1f}s, batch 32)"
    cleanup_gpu_memory()


def synthesize_conversation(
    script_text: str,
    *args
):
    """
    Synthesizes multi-speaker conversation from a script.

    Layout: args[0..MAX_SPEAKERS-1] = speaker names,
            args[MAX_SPEAKERS..2*MAX_SPEAKERS-1] = voice IDs,
            (optional) args[2*MAX_SPEAKERS..3*MAX_SPEAKERS-1] = custom audio filepaths,
            silence_duration, temperature, max_chars_chunk, [denoise_ref], session_id
    """
    speaker_names  = list(args[:MAX_SPEAKERS])
    speaker_voices = list(args[MAX_SPEAKERS:MAX_SPEAKERS*2])
    
    if len(args) >= MAX_SPEAKERS * 3:
        speaker_audios = list(args[MAX_SPEAKERS*2:MAX_SPEAKERS*3])
        rest = args[MAX_SPEAKERS*3:]
    else:
        speaker_audios = [None] * MAX_SPEAKERS
        rest = args[MAX_SPEAKERS*2:]

    silence_duration = rest[0] if len(rest) > 0 else 0.1
    temperature      = rest[1] if len(rest) > 1 else 0.8
    max_chars_chunk  = rest[2] if len(rest) > 2 else 224
    denoise_ref      = rest[3] if len(rest) > 3 and isinstance(rest[3], bool) else True
    session_id       = rest[-1] if len(rest) > 0 and isinstance(rest[-1], str) else None

    global tts, model_loaded, using_lmdeploy
    
    _STOP_EVENT.clear()
    
    if not model_loaded or tts is None:
        yield None, "⚠️ Vui lòng tải model trước!"
        return
        
    if not script_text or script_text.strip() == "":
        yield None, "⚠️ Vui lòng nhập kịch bản hội thoại!"
        return

    # 1. Parse Script
    lines = []
    for line in script_text.strip().split('\n'):
        if not line.strip(): continue
        if ':' in line:
            parts = line.split(':', 1)
            lines.append({'speaker': parts[0].strip(), 'text': parts[1].strip()})
        else:
            if lines:
                lines[-1]['text'] += " " + line.strip()
            else:
                lines.append({'speaker': 'Narrator', 'text': line.strip()})

    if not lines:
        yield None, "⚠️ Không tìm thấy lời thoại hợp lệ (định dạng Nhân vật: Lời thoại)!"
        return

    # 2. Build Speaker Mapping from individual slot components
    mapping = {}
    for name, voice, audio_path in zip(speaker_names, speaker_voices, speaker_audios):
        name = str(name).strip() if name else ""
        if not name: continue
        
        # Priority 1: User uploaded custom audio file
        if audio_path and os.path.exists(audio_path):
            mapping[name.lower()] = {
                'type': 'Custom',
                'voice': audio_path,
                'audio': audio_path,
                'ref_text': ''
            }
        else:
            voice_str = str(voice).strip() if voice else ""
            if voice_str.startswith("Giọng train: "):
                voice_str = voice_str.replace("Giọng train: ", "").strip()
            trained_audio = _load_trained_voice_audio(voice_str)
            if trained_audio and os.path.exists(trained_audio):
                mapping[name.lower()] = {
                    'type': 'Custom',
                    'voice': trained_audio,
                    'audio': trained_audio,
                    'ref_text': ''
                }
            else:
                v_id = resolve_voice_id(voice_str) if voice_str and not voice_str.startswith("--") else ""
                mapping[name.lower()] = {
                    'type': 'Preset',
                    'voice': v_id,
                    'audio': None,
                    'ref_text': ''
                }

    # 2b. v3 Turbo: batch toàn bộ hội thoại (bs=32), bất kể speaker thay đổi.
    if "v3" in (current_backbone or "").lower():
        yield from _synthesize_conversation_v3(
            lines, mapping, temperature, max_chars_chunk, silence_duration, denoise_ref=denoise_ref
        )
        return

    # 3. Process Each Line
    all_wavs = []
    sr = 24000
    total_lines = len(lines)
    
    yield None, f"🎭 Đang khởi tạo hội thoại ({total_lines} câu)..."
    
    start_time = time.time()
    
    try:
        for i, line in enumerate(lines):
            if _STOP_EVENT.is_set():
                yield None, "⏹️ Đã dừng hội thoại."
                return
            spk_name = line['speaker']
            text = line['text']
            
            yield None, f"⏳ [{i+1}/{total_lines}] {spk_name}: {text[:30]}..."
            
            # Determine voice
            ref_codes = None
            ref_text_val = None
            current_voice_obj = None
            
            # Case-insensitive lookup
            config = mapping.get(spk_name.lower())
            
            if not config:
                print(f"  ⚠️ Character '{spk_name}' not found in mapping. Fallback to default.")
                # Fallback to default if speaker not mapped
                try:
                    # Get default voice data
                    default_v_id = tts._default_voice
                    if not default_v_id:
                        dv_list = tts.list_preset_voices()
                        if dv_list:
                            first = dv_list[0]
                            default_v_id = first[1] if isinstance(first, tuple) else first
                    
                    if default_v_id:
                        current_voice_obj = tts.get_preset_voice(default_v_id)
                        ref_codes = current_voice_obj['codes']
                        ref_text_val = current_voice_obj['text']
                except Exception as e:
                    print(f"  ❌ Fallback failed: {e}")
            else:
                try:
                    v_id = config['voice']
                    if config['type'] == "Preset":
                        current_voice_obj = tts.get_preset_voice(v_id)
                        if current_voice_obj and 'codes' in current_voice_obj:
                            ref_codes = current_voice_obj['codes']
                            ref_text_val = current_voice_obj['text']
                        else:
                            print(f"  ❌ Could not find codes for voice '{v_id}'")
                    else: # Custom
                        audio_path = config.get('audio') or config.get('voice')
                        if audio_path and os.path.exists(audio_path):
                            ref_codes = tts.encode_reference(audio_path)
                            ref_text_val = config.get('ref_text', '')
                            current_voice_obj = {'codes': ref_codes, 'text': ref_text_val}
                            print(f"  🦜 Using custom voice for '{spk_name}'")
                except Exception as e:
                    print(f"  ❌ Lỗi nạp giọng cho {spk_name} (ID: {config.get('voice')}): {e}")
            
            # Ensure numpy for inference
            if 'torch' in sys.modules:
                import torch
                if isinstance(ref_codes, torch.Tensor):
                    ref_codes = ref_codes.cpu().numpy()

            # Infer audio
            try:
                wav = tts.infer(
                    text,
                    voice=current_voice_obj, # Use full voice object
                    ref_codes=ref_codes,     # Fallback if object not supported
                    ref_text=ref_text_val,
                    temperature=temperature,
                    max_chars=max_chars_chunk,
                    emotion_tag="<|emotion_0|>" # Emotion tag for conversation
                )
                
                all_wavs.append(wav)
                
                # Add silence between turns
                if i < total_lines - 1 and silence_duration > 0:
                    silence_len = int(sr * silence_duration)
                    silence = np.zeros(silence_len)
                    all_wavs.append(silence)
                    
            except Exception as e:
                print(f"❌ Lỗi tổng hợp câu {i+1}: {e}")
                continue

        if not all_wavs:
            yield None, "❌ Không thể tạo được âm thanh nào!"
            return

        # 4. Merge and Output
        yield None, "🪄 Đang ghép nối âm thanh..."
        final_wav = np.concatenate(all_wavs)
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
            sf.write(tmp.name, final_wav, sr)
            elapsed = time.time() - start_time
            yield tmp.name, f"✅ Hoàn tất hội thoại! ({total_lines} câu, xử lý trong {elapsed:.1f}s)"
            
    except Exception as e:
        import traceback
        traceback.print_exc()
        yield None, f"❌ Lỗi hệ thống: {str(e)}"

def extract_speakers_from_script(script):
    """Find unique speakers and return gr.update() lists for the 8 slot components."""
    global CONV_VOICES_CACHE
    if not script:
        # Hide all slots
        name_updates = [gr.update(value="", visible=False)] * MAX_SPEAKERS
        dd_updates   = [gr.update(value=None, visible=False)] * MAX_SPEAKERS
        row_updates  = [gr.update(visible=False)] * MAX_SPEAKERS
        return name_updates + dd_updates + row_updates

    speakers = []
    seen = set()
    for line in script.strip().split('\n'):
        if ':' in line:
            s = line.split(':', 1)[0].strip()
            if s and s not in seen:
                seen.add(s)
                speakers.append(s)

    # Auto-match each speaker name to a preset voice
    def _best_match(name):
        if not CONV_VOICES_CACHE:
            return None
        
        name_l = name.lower()
        
        # 0. Manual overrides for specific common names
        overrides = {
            "phương": "Trúc Ly",
            "dũng": "Thanh Bình",
            "hùng": "Thái Sơn"
        }
        if name_l in overrides:
            target = overrides[name_l].lower()
            for v in CONV_VOICES_CACHE:
                label, value = (v[0], v[1]) if isinstance(v, tuple) else (v, v)
                if target in label.lower() or target in value.lower():
                    return value

        # 1. Try to find name in labels or values
        for v in CONV_VOICES_CACHE:
            label, value = (v[0], v[1]) if isinstance(v, tuple) else (v, v)
            if name_l == label.lower() or name_l == value.lower():
                return value
        
        # 2. Fuzzy match (contains)
        for v in CONV_VOICES_CACHE:
            label, value = (v[0], v[1]) if isinstance(v, tuple) else (v, v)
            if name_l in label.lower() or name_l in value.lower() or label.lower() in name_l or value.lower() in name_l:
                return value
        
        # 3. Default to first voice if no match
        first_voice = CONV_VOICES_CACHE[0]
        return first_voice[1] if isinstance(first_voice, tuple) else first_voice

    name_updates, dd_updates, row_updates = [], [], []
    for i in range(MAX_SPEAKERS):
        if i < len(speakers):
            name_updates.append(gr.update(value=speakers[i], visible=True))
            dd_updates.append(gr.update(value=_best_match(speakers[i]), choices=CONV_VOICES_CACHE, visible=True))
            row_updates.append(gr.update(visible=True))
        else:
            name_updates.append(gr.update(value="", visible=False))
            dd_updates.append(gr.update(value=None, choices=CONV_VOICES_CACHE, visible=False))
            row_updates.append(gr.update(visible=False))

    return name_updates + dd_updates + row_updates

def extract_speakers_for_clone_conv(script):
    """Find unique speakers for clone conversation tab and return component updates."""
    all_choices = _get_conv_character_voice_choices()
    if not script:
        name_updates = [gr.update(value="", visible=False)] * MAX_SPEAKERS
        dd_updates   = [gr.update(value=None, choices=all_choices, visible=False)] * MAX_SPEAKERS
        row_updates  = [gr.update(visible=False)] * MAX_SPEAKERS
        return name_updates + dd_updates + row_updates

    speakers = []
    seen = set()
    for line in script.strip().split('\n'):
        if ':' in line:
            s = line.split(':', 1)[0].strip()
            if s and s not in seen:
                seen.add(s)
                speakers.append(s)

    def _best_conv_match(name):
        if not CONV_VOICES_CACHE:
            return None
        name_l = name.lower()
        overrides = {
            "phương": "Trúc Ly",
            "dũng": "Thanh Bình",
            "hùng": "Thái Sơn"
        }
        if name_l in overrides:
            target = overrides[name_l].lower()
            for v in CONV_VOICES_CACHE:
                label, value = (v[0], v[1]) if isinstance(v, tuple) else (v, v)
                if target in label.lower() or target in value.lower():
                    return value
        for v in CONV_VOICES_CACHE:
            label, value = (v[0], v[1]) if isinstance(v, tuple) else (v, v)
            if name_l in label.lower() or name_l in value.lower() or label.lower() in name_l or value.lower() in name_l:
                return value
        first_voice = CONV_VOICES_CACHE[0]
        return first_voice[1] if isinstance(first_voice, tuple) else first_voice

    name_updates, dd_updates, row_updates = [], [], []
    for i in range(MAX_SPEAKERS):
        if i < len(speakers):
            name_updates.append(gr.update(value=speakers[i], visible=True))
            dd_updates.append(gr.update(value=_best_conv_match(speakers[i]), choices=all_choices, visible=True))
            row_updates.append(gr.update(visible=True))
        else:
            name_updates.append(gr.update(value="", visible=False))
            dd_updates.append(gr.update(value=None, choices=all_choices, visible=False))
            row_updates.append(gr.update(visible=False))

    return name_updates + dd_updates + row_updates

DEFAULT_CONV_SCRIPT = (
    "Phương: Chào mọi người, mình là Phương. Hôm nay team có một announcement cực lớn về VieNeu-TTS Version 2. Đồng hành cùng mình là anh Dũng và Hùng. Hi guys!\n\n"
    "Dũng: Yo, chào cả nhà. Mình sẽ đi thẳng vào technical side của bản nâng cấp này để mọi người có cái nhìn deep hơn nhé.\n\n"
    "Hùng: Chào mọi người. Thật sự V2 là một huge milestone. Nó phá vỡ rào cản của những công cụ đọc văn bản khô khan, hướng tới một sự natural communication đúng nghĩa.\n\n"
    "Phương: Correct! Và bất ngờ nhất là: nãy giờ mọi người đang nghe bản demo được tạo ra 100% bằng VieNeu-TTS V2 đấy. Tụi mình đều là sản phẩm của AI hết. Amazing, right?\n\n"
    "Dũng: Đỉnh thật sự! Tiện đây Hùng share thêm về cái nội công bên trong của model này đi.\n\n"
    "Hùng: Chắc chắn rồi. Model được train trên 10000 hours audio chất lượng cao, nên nó hỗ trợ code-switching Anh Việt cực mượt, tự nhiên như podcast. Đặc biệt, dự án này hoàn toàn open-source để cộng đồng cùng phát triển.\n\n"
    "Dũng: Về hiệu năng thì khỏi bàn. Khi test trên GPU quốc dân RTX 3060, tốc độ sinh audio nhanh gấp 10 lần realtime. Và đừng lo, nếu bạn không có card đồ hỏa xịn, tụi mình có sẵn bản CPU version để ai cũng có thể tiếp cận được.\n\n"
    "Phương: Tốc độ cực nhanh, hỗ trợ đa nền tảng và hoàn toàn miễn phí. Mọi người hãy cùng trải nghiệm nhé!"
)

def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract all text from a PDF file using PyMuPDF (fitz)."""
    global HAS_FITZ, fitz
    if not HAS_FITZ:
        return "⚠️ PyMuPDF chưa được cài đặt. Vui lòng chạy: pip install PyMuPDF"
    try:
        doc = fitz.open(pdf_path)
        pages_text = []
        for page_num, page in enumerate(doc):
            text = page.get_text()
            if text and text.strip():
                pages_text.append(text.strip())
        doc.close()
        if not pages_text:
            return "⚠️ Không tìm thấy văn bản trong file PDF."
        full_text = "\n\n".join(pages_text)
        return full_text
    except Exception as e:
        return f"⚠️ Lỗi khi đọc PDF: {str(e)}"

EXAMPLES_LIST = [
    ["Về miền Tây không chỉ để ngắm nhìn sông nước hữu tình, mà còn để cảm nhận tấm chân tình của người dân nơi đây.", "Vĩnh (nam miền Nam)"],
    ["Hà Nội những ngày vào thu mang một vẻ đẹp trầm mặc và cổ kính đến lạ thường.", "Bình (nam miền Bắc)"],
]

with gr.Blocks(theme=theme, css=css, title="VieNeu-TTS", head=head_html) as demo:
    # Session ID for cancellation tracking
    session_id_state = gr.State("")

    with gr.Column(elem_classes="container"):
        gr.HTML("""
<div class="header-box">
    <h1 class="header-title">
        <span class="header-icon">🦜</span>
        <span class="gradient-text">VieNeu-TTS Studio</span>
    </h1>
    <div class="model-card-content">
        <div class="model-card-item">
            <strong>Models:</strong>
            <a href="https://huggingface.co/pnnbao-ump/VieNeu-TTS" target="_blank" class="model-card-link">VieNeu-TTS</a>
            <span>•</span>
            <a href="https://huggingface.co/pnnbao-ump/VieNeu-TTS-v2" target="_blank" class="model-card-link">VieNeu-TTS-v2</a>
        </div>
        <div class="model-card-item">
            <strong>Repository:</strong>
            <a href="https://github.com/pnnbao97/VieNeu-TTS" target="_blank" class="model-card-link">GitHub</a>
        </div>
        <div class="model-card-item">
            <strong>Tác giả:</strong>
            <a href="https://www.facebook.com/pnnbao97" target="_blank" class="model-card-link">Phạm Nguyễn Ngọc Bảo</a>
        </div>
        <div class="model-card-item">
            <strong>Discord:</strong>
            <a href="https://discord.gg/yJt8kzjzWZ" target="_blank" class="model-card-link">Tham gia cộng đồng</a>
        </div>
    </div>
</div>
        """)
        
        # --- CONFIGURATION ---
        with gr.Group():
            with gr.Row():
                # --- BACKBONE & CODEC DEFAULT LOGIC ---
                # GPU users default to VieNeu-TTS-v3-Turbo (GPU); CPU-only users get v3 Turbo
                # (the only CPU backbone). v3 (GPU) is registered solely when HAS_GPU.
                # int8 là entry đầu tiên → mặc định trên cả CPU lẫn GPU (trên GPU dùng
                # PyTorch nên int8/fp32 như nhau; trên CPU int8 nhanh nhất).
                # Ưu tiên bản fp32 chất lượng cao nhất; chỉ fallback khi model
                # này không tồn tại trong cấu hình hiện hành.
                default_backbone = (
                    "VieNeu-TTS-v3-Turbo"
                    if "VieNeu-TTS-v3-Turbo" in BACKBONE_CONFIGS
                    else list(BACKBONE_CONFIGS.keys())[0]
                )
                
                # Default parameters based on backbone
                if "v3" in default_backbone.lower():
                    default_codec = "VieNeu-Codec"
                    default_temp = DEFAULT_GENERATION_TEMPERATURE
                    default_text = DEFAULT_TEXT_V3
                elif "Turbo" in default_backbone:
                    default_codec = "VieNeu-Codec"
                    default_temp = DEFAULT_GENERATION_TEMPERATURE
                    default_text = DEFAULT_TEXT_TURBO
                elif "(CPU)" in default_backbone:
                    default_codec = "NeuCodec (ONNX)"
                    default_temp = DEFAULT_GENERATION_TEMPERATURE
                    default_text = DEFAULT_TEXT_GPU
                else:
                    default_codec = "NeuCodec (Distill)" if "NeuCodec (Distill)" in CODEC_CONFIGS else list(CODEC_CONFIGS.keys())[0]
                    default_temp = DEFAULT_GENERATION_TEMPERATURE
                    default_text = DEFAULT_TEXT_GPU

                # Thiết lập mặc định tối ưu theo cấu hình máy hiện tại.
                default_batch_size = DEFAULT_GENERATION_BATCH_SIZE

                backbone_select = gr.Dropdown(
                    list(BACKBONE_CONFIGS.keys()) + ["Custom Model"],
                    value=default_backbone,
                    label="🦜 Backbone"
                )
                codec_select = gr.Dropdown(
                    list(CODEC_CONFIGS.keys()), 
                    value=default_codec, 
                    label="🎵 Codec",
                    interactive=False
                )
                device_choice = gr.Radio(get_available_devices(), value="Auto", label="🖥️ Device")
            
            with gr.Row(visible=False) as custom_model_group:
                custom_backbone_model_id = gr.Textbox(
                    label="📦 Custom Model ID",
                    placeholder="pnnbao-ump/VieNeu-TTS-0.3B-lora-ngoc-huyen",
                    info="Nhập HuggingFace Repo ID hoặc đường dẫn local",
                    scale=2
                )
                custom_backbone_hf_token = gr.Textbox(
                    label="🔑 HF Token (nếu private)",
                    placeholder="Để trống nếu repo public",
                    type="password",
                    info="Token để truy cập repo private",
                    scale=1
                )
                base_model_choices = [k for k in BACKBONE_CONFIGS.keys() if "turbo" not in k.lower() and k != "Custom Model"]
                custom_backbone_base_model = gr.Dropdown(
                    base_model_choices,
                    label="🔗 Base Model (cho LoRA)",
                    value=base_model_choices[0] if base_model_choices else None,
                    visible=False,
                    info="Model gốc để merge với LoRA (GPU Only)",
                    scale=1
                )
            
            with gr.Row():
                use_lmdeploy_cb = gr.Checkbox(
                    value=True,
                    label="🚀 Optimize with LMDeploy (Khuyên dùng cho NVIDIA GPU)",
                    info="Tick nếu bạn dùng GPU để tăng tốc độ tổng hợp đáng kể.",
                    visible="v3" not in default_backbone.lower(),  # v3 Turbo (PyTorch) không dùng LMDeploy
                )
            
            
            gr.Markdown("""
            💡 **Sử dụng Custom Model:** Chọn "Custom Model" để tải LoRA adapter hoặc bất kỳ model nào được finetune từ **VieNeu-TTS** hoặc **VieNeu-TTS-0.3B**.
            """)
            
            gr.HTML("""
            <div class="warning-banner">
                <div class="warning-banner-title">
                    🦜 Gợi ý tối ưu hiệu năng
                </div>
                <div class="warning-banner-grid">
                    <div class="warning-banner-item">
                        <strong>🐆 Hệ máy GPU</strong>
                        <div class="warning-banner-content">
                            <b>VieNeu-TTS-v3-Turbo (early access)</b> đã được phát hành để dùng thử trước, đã hỗ trợ các tag cảm xúc `[cười]` `[hắng giọng]` `[thở dài]`, tuy nhiên những tính năng này vẫn đang được thử nghiệm và chưa thực sự ổn định, có thể sẽ xảy ra lỗi không mong muốn, nếu có lỗi các bạn hãy thông báo với chúng tôi tại: https://discord.com/invite/yJt8kzjzWZ. Trong trường hợp bạn cần sự ổn định hãy sử dụng <b>VieNeu-TTS-v2 (GPU)</b>. 
                        </div>
                    </div>
                    <div class="warning-banner-item" style="background: #dcfce7; border-color: #86efac;">
                        <strong style="color: #15803d;">🐢 Hệ máy CPU</strong>
                        <div class="warning-banner-content" style="color: #166534;">
                            Máy <b>CPU</b> nên dùng bản <b>VieNeu-TTS-v3-Turbo (int8)</b> để tốc độ tối đa. Chuyển sang <b>VieNeu-TTS-v3-Turbo</b> nếu cần chất lượng cao hơn (nhưng chậm hơn trên CPU).
                        </div>
                    </div>
                </div>
                <div style="margin-top: 12px; font-size: 0.85rem; color: #92400e; border-top: 1px dashed #fcd34d; padding-top: 8px;">
                    💡 <b>Mẹo:</b> Nếu máy bạn có GPU mà không thấy các phiên bản GPU hãy xem lại cách cài đặt uv sync --group gpu
                </div>
            </div>
            """)

            gr.Markdown(
                "🆕 **VieNeu-TTS-v3-Turbo (early access)** đã được phát hành để **dùng thử trước** — "
                "48kHz, **hỗ trợ Voice Cloning** (tính năng clone chỉ có từ **v3** trở lên; v1/v2 không hỗ trợ). "
                "Bản **v3 đầy đủ** sẽ ra mắt trong **vài tuần tới**.\n\n"
                "🎭 v3 Turbo đã **hỗ trợ các tag cảm xúc** `[cười]` `[hắng giọng]` `[thở dài]` "
                "(chèn trực tiếp vào văn bản) — nhưng tính năng này **đang thử nghiệm và chưa thực sự ổn định**."
            )

            btn_load = gr.Button("🔄 Tải Model", variant="primary")
            model_status = gr.Markdown("⏳ Chưa tải model.")
        
        with gr.Row(elem_classes="container"):
            # --- INPUT ---
            with gr.Column(scale=3):
                with gr.Tabs() as main_input_tabs:
                    # --- TAB 1: SINGLE SPEAKER ---
                    with gr.Tab("🦜 Đọc truyện", id="single_tab") as single_tab:
                        with gr.Group(visible=True) as single_text_panel:
                            with gr.Accordion("📄 Tải lên PDF để trích xuất văn bản", open=False):
                                gr.Markdown(
                                    "Tải lên file PDF, văn bản sẽ được tự động trích xuất và điền vào ô bên dưới. "
                                    "Bạn có thể chỉnh sửa lại trước khi tạo audio."
                                )
                                with gr.Row():
                                    pdf_upload = gr.File(
                                        label="📄 Chọn file PDF",
                                        file_types=[".pdf"],
                                        file_count="single",
                                        type="filepath",
                                        scale=3,
                                    )
                                    btn_extract_pdf = gr.Button("📄 Trích xuất văn bản", variant="secondary", scale=1, min_width=150)
                                pdf_status = gr.Markdown(visible=False)
                            text_input = gr.Textbox(
                                label=f"Văn bản",
                                lines=8,
                                value=default_text,
                            )
                            with gr.Row():
                                btn_smart_split = gr.Button(
                                    "✂️ Tách câu thông minh",
                                    variant="secondary",
                                    scale=1,
                                    min_width=200,
                                    elem_id="btn-smart-split",
                                )
                                split_status_md = gr.Markdown(
                                    "",
                                    elem_classes="time-estimate",
                                )
                            time_estimate_md = gr.Markdown("⏳ **Ước tính thời gian:** ~1s", elem_classes="time-estimate")
                        
                        with gr.Tabs() as tabs:
                            with gr.TabItem("👤 Preset", id="preset_mode") as tab_preset:
                                voice_select = gr.Dropdown(choices=[], value=None, label="Giọng mẫu", allow_custom_value=True)
                            
                            # Voice cloning is only available on v3+ models. Hidden by
                            # default and toggled on by on_backbone_change when a v3
                            # model is selected.
                            with gr.TabItem("🦜 Voice Cloning", id="custom_mode", visible=False) as tab_custom:
                                clone_mode_radio = gr.Radio(
                                    ["Đơn giọng (1 người đọc)", "Hội thoại (Nhiều giọng clone)"],
                                    value="Đơn giọng (1 người đọc)",
                                    label="Chế độ Clone",
                                    info="Chọn đọc văn bản đơn lẻ với 1 giọng clone, hoặc đọc kịch bản hội thoại với nhiều giọng clone cho từng nhân vật."
                                )
                                # Initial clone-tab state must match the DEFAULT backbone:
                                # on_backbone_change only fires when the dropdown changes, so a
                                # v2-GPU default would otherwise keep v3's "no transcript" copy
                                # and a hidden reference-text box (-> false "missing ref text").
                                _default_is_v2_gpu = (default_backbone == "VieNeu-TTS-v2 (GPU)")
                                clone_info_md = gr.Markdown(
                                    "ℹ️ **Voice Cloning (VieNeu-TTS v2).** Tải lên audio mẫu 3–5 giây "
                                    "và **nhập đúng nội dung** của audio đó (kể cả dấu câu) — v2 cần "
                                    "reference transcript để clone giọng."
                                    if _default_is_v2_gpu else
                                    "ℹ️ **Voice Cloning (VieNeu-TTS v3).** Chỉ cần tải lên audio mẫu "
                                    "3–5 giây; v3 clone trực tiếp từ audio, không cần nhập nội dung."
                                )
                                with gr.Group(visible=True) as cloning_elements_group:
                                    trained_voice_dropdown = gr.Dropdown(
                                        choices=_get_trained_voice_choices(),
                                        value="-- Chọn giọng đã train --",
                                        label="🎤 Giọng đã train (tự động load audio mẫu)",
                                        info="Chọn giọng bạn đã finetune để tự động điền audio mẫu bên dưới.",
                                    )
                                    custom_audio = gr.Audio(label="Audio giọng mẫu (3-5 giây) (.wav)", type="filepath")
                                    quality_plus_checkbox = gr.Checkbox(
                                        value=False, label="✨ Quality+ — kiểm tra và chọn bản đọc tốt hơn",
                                        info="v3 Turbo: so 2–3 bản mỗi câu bằng Whisper và độ giống giọng, cân âm lượng. Chạy tuần tự khi bật; chậm hơn Batch 16. Cần Whisper đã tải trên máy. Câu dài giữ nguyên; dấu câu và xuống dòng vẫn nghỉ riêng."
                                    )
                                    cloning_warning_msg = gr.Markdown(visible=False, elem_id="cloning-warning")
                                    denoise_checkbox = gr.Checkbox(
                                        value=True, label="🔇 Denoise audio mẫu",
                                        info="Khử nhiễu nền + chuẩn hoá audio mẫu trước khi clone (khuyến nghị). Audio dài hơn 8 giây sẽ được cắt ngắn.",
                                    )
                                    # v3 clones from audio only — the reference transcript box
                                    # is hidden for v3 (toggled by on_backbone_change).
                                    custom_text = gr.Textbox(label="Nội dung audio mẫu - vui lòng gõ đúng nội dung của audio mẫu - kể cả dấu câu vì model rất nhạy cảm với dấu câu (.,?!)", visible=_default_is_v2_gpu)

                                    btn_pause_settings = gr.Button(
                                        "🎚️ Thiết lập ngắt nghỉ",
                                        variant="secondary",
                                        elem_id="btn-pause-settings",
                                    )
                                    with gr.Group(
                                        visible=False,
                                        elem_classes="pause-settings-panel",
                                    ) as pause_settings_panel:
                                        with gr.Row(elem_classes="pause-settings-header"):
                                            gr.Markdown(
                                                "### Thiết lập ngắt nghỉ\n"
                                                "Đơn vị là giây. Audio sẽ nghỉ đúng theo từng dấu bên dưới."
                                            )
                                            btn_close_pause = gr.Button("✕", size="sm", min_width=48)

                                        pause_values = {}
                                        pause_buttons = {}

                                        def _pause_control(label, symbol, key):
                                            with gr.Row(elem_classes="pause-control-row"):
                                                gr.Markdown(
                                                    f"**{label}** &nbsp; `{symbol}`",
                                                    elem_classes="pause-control-label",
                                                )
                                                minus = gr.Button("−", size="sm", min_width=42)
                                                value = gr.Number(
                                                    value=PAUSE_DEFAULTS[key],
                                                    minimum=0,
                                                    maximum=3,
                                                    step=0.1,
                                                    show_label=False,
                                                    container=False,
                                                    elem_classes="pause-number",
                                                )
                                                gr.Markdown("giây", elem_classes="pause-unit")
                                                plus = gr.Button("+", size="sm", min_width=42)
                                            pause_values[key] = value
                                            pause_buttons[key] = (minus, plus)

                                        with gr.Row():
                                            with gr.Column():
                                                _pause_control("Dấu chấm", ".", "dot")
                                                _pause_control("Dấu hỏi", "?", "question")
                                                _pause_control("Dấu hai chấm", ":", "colon")
                                                _pause_control("Dấu ba chấm", "…", "ellipsis")
                                            with gr.Column():
                                                _pause_control("Dấu phẩy", ",", "comma")
                                                _pause_control("Dấu chấm than", "!", "exclamation")
                                                _pause_control("Dấu chấm phẩy", ";", "semicolon")
                                                _pause_control("Xuống dòng", "↵", "newline")

                                        gr.Markdown(
                                            "💡 Câu dài vẫn được giữ đến dấu kết câu; thiết lập này chỉ điều khiển khoảng lặng khi ghép audio."
                                        )
                                        with gr.Row():
                                            btn_reset_pause = gr.Button("Đặt mặc định", variant="secondary")
                                            btn_done_pause = gr.Button("Xong", variant="primary")
                                    
                                    with gr.Accordion("📂 Xử lý hàng loạt file TXT (Treo máy qua đêm)", open=True, elem_classes="batch-txt-box"):
                                        gr.Markdown(
                                            "#### 🌙 Chế độ Đọc Hàng Loạt File TXT (Treo máy qua đêm)\n"
                                            "Tải lên nhiều file `.txt` (ví dụ: từng chương truyện). Hệ thống sẽ dùng giọng clone ở trên, "
                                            "**tự động tách câu thông minh cho từng TXT**, **đọc lần lượt từng file** và lưu MP3 vào thư mục bạn chọn. Tên audio giữ nguyên tên TXT, chỉ đổi đuôi thành `.mp3`."
                                        )
                                        batch_txt_files = gr.File(
                                            label="📂 Chọn nhiều file .txt để đọc qua đêm",
                                            file_types=[".txt"],
                                            file_count="multiple",
                                            type="filepath"
                                        )
                                        preserve_txt_upload_names(batch_txt_files)
                                        batch_txt_info = gr.Markdown(
                                            "💡 *Chưa chọn file nào. Kéo thả nhiều file .txt vào đây để kích hoạt chế độ chạy qua đêm.*",
                                            elem_classes="time-estimate"
                                        )
                                        with gr.Row():
                                            auto_download_cb = gr.Checkbox(
                                                value=False,
                                                label="📥 Tải thêm bản sao qua trình duyệt",
                                                elem_id="batch-auto-download",
                                                info="Bản chính luôn lưu vào thư mục đã chọn. Bản tải thêm dùng thư mục tải xuống của trình duyệt."
                                            )
                                            batch_output_dir = gr.Textbox(
                                                value="outputs/batch_cloned",
                                                label="📁 Thư mục lưu audio trên máy",
                                                info="Nhập đường dẫn hoặc bấm Chọn thư mục. File trùng tên được lưu trong thư mục con để giữ nguyên tên audio."
                                            )
                                        btn_choose_batch_dir = gr.Button("📁 Chọn thư mục lưu audio")
                                        btn_generate_batch = gr.Button("📚 Bắt đầu xử lý các file TXT", variant="primary")
                                        batch_clone_mode = gr.State("custom_mode")
                                    
                                    gr.Examples(
                                        examples=[
                                            [os.path.join(os.path.dirname(os.path.dirname(__file__)), "examples", "audio_ref", "example.wav"), "Ví dụ 2. Tính trung bình của dãy số."],
                                            [os.path.join(os.path.dirname(os.path.dirname(__file__)), "examples", "audio_ref", "example_2.wav"), "Trên thực tế, các nghi ngờ đã bắt đầu xuất hiện."],
                                            [os.path.join(os.path.dirname(os.path.dirname(__file__)), "examples", "audio_ref", "example_3.wav"), "Cậu có nhìn thấy không?"],
                                            [os.path.join(os.path.dirname(os.path.dirname(__file__)), "examples", "audio_ref", "example_4.wav"), "Tết là dịp mọi người háo hức đón chào một năm mới với nhiều hy vọng và mong ước."]
                                        ],
                                        inputs=[custom_audio, custom_text],
                                        label="Ví dụ mẫu để thử nghiệm clone giọng"
                                    )
                                    
                                    gr.Markdown("""
                                    **💡 Mẹo nhỏ:** Nếu kết quả Zero-shot Voice Cloning chưa như ý, bạn hãy cân nhắc **Finetune (LoRA)** để đạt chất lượng tốt nhất. 
                                    Hướng dẫn chi tiết có tại file: `finetune/README.md` hoặc xem trên [GitHub](https://github.com/pnnbao97/VieNeu-TTS/tree/main/finetune).
                                    """)

                                with gr.Group(visible=False) as conv_clone_group:
                                    conv_clone_script_input = gr.Textbox(
                                        label="Kịch bản hội thoại",
                                        placeholder="Phương: Chào mọi người, mình là Phương...\nDũng: Chào cả nhà...",
                                        lines=10,
                                        elem_classes="script-box",
                                        value=DEFAULT_CONV_SCRIPT,
                                    )
                                    conv_clone_time_estimate_md = gr.Markdown("⏳ **Ước tính thời gian:** ~19s", elem_classes="time-estimate")
                                    
                                    with gr.Row():
                                        btn_conv_clone_detect = gr.Button("🔍 Quét nhân vật", size="sm", variant="secondary")
                                        conv_clone_silence_slider = gr.Slider(minimum=0, maximum=3, value=0.1, step=0.1, label="⏱️ Khoảng lặng (giây)")
                                        conv_clone_denoise_cb = gr.Checkbox(value=True, label="🔇 Denoise audio mẫu", info="Khử nhiễu các audio mẫu trước khi clone")

                                    gr.Markdown("### 🎭 Cấu hình giọng đọc clone cho từng nhân vật")
                                    gr.Markdown("*Nhấn **Quét nhân vật** để tự động nhận diện các nhân vật trong kịch bản. Tải lên file Audio mẫu (3–5s) để clone giọng, hoặc chọn giọng đã train / preset bên dưới.*")

                                    clone_speaker_name_boxes = []
                                    clone_speaker_voice_dds  = []
                                    clone_speaker_audios     = []
                                    clone_speaker_slot_rows  = []

                                    for _i in range(MAX_SPEAKERS):
                                        _default_name = ""
                                        _default_voice = None
                                        _row_visible = False
                                        
                                        if _i == 0:
                                            _default_name = "Phương"
                                            _default_voice = "Trúc Ly"
                                            _row_visible = True
                                        elif _i == 1:
                                            _default_name = "Dũng"
                                            _default_voice = "Thanh Bình"
                                            _row_visible = True
                                        elif _i == 2:
                                            _default_name = "Hùng"
                                            _default_voice = "Thái Sơn"
                                            _row_visible = True

                                        with gr.Row(visible=_row_visible) as _row:
                                            _name = gr.Textbox(
                                                value=_default_name,
                                                label="👤 Nhân vật",
                                                interactive=False,
                                                scale=1,
                                                min_width=110
                                            )
                                            _dd = gr.Dropdown(
                                                choices=_get_conv_character_voice_choices(),
                                                value=_default_voice,
                                                label="🎤 Giọng đã train / Preset",
                                                interactive=True,
                                                scale=2,
                                                allow_custom_value=True
                                            )
                                            _audio = gr.Audio(
                                                label="🎵 Audio mẫu clone (3–5s) (.wav)",
                                                type="filepath",
                                                scale=3
                                            )
                                        clone_speaker_slot_rows.append(_row)
                                        clone_speaker_name_boxes.append(_name)
                                        clone_speaker_voice_dds.append(_dd)
                                        clone_speaker_audios.append(_audio)
                                    
                                    btn_generate_conv_clone = gr.Button("🎭 Bắt đầu hội thoại (Voice Cloning)", variant="primary", scale=2)
                        
                        generation_mode = gr.Radio(
                            ["Standard (Một lần)"],
                            value="Standard (Một lần)",
                            label="Chế độ sinh"
                        )
                        btn_generate = gr.Button("🎵 Bắt đầu", variant="primary", scale=2, interactive=False)

                    # --- TAB 2: MULTI-SPEAKER CONVERSATION ---
                    with gr.Tab("🎭 Hội thoại", id="conv_tab", visible=False) as conv_tab:
                        conv_script_input = gr.Textbox(
                            label="Kịch bản hội thoại",
                            placeholder="Phương: Chào mọi người, mình là Phương...",
                            lines=10,
                            elem_classes="script-box",
                            value='Phương: Chào mọi người, mình là Phương. Hôm nay team có một announcement cực lớn về VieNeu-TTS Version 2. Đồng hành cùng mình là anh Dũng và Hùng. Hi guys!\n\nDũng: Yo, chào cả nhà. Mình sẽ đi thẳng vào technical side của bản nâng cấp này để mọi người có cái nhìn deep hơn nhé.\n\nHùng: Chào mọi người. Thật sự V2 là một huge milestone. Nó phá vỡ rào cản của những công cụ đọc văn bản khô khan, hướng tới một sự natural communication đúng nghĩa.\n\nPhương: Correct! Và bất ngờ nhất là: nãy giờ mọi người đang nghe bản demo được tạo ra 100% bằng VieNeu-TTS V2 đấy. Tụi mình đều là sản phẩm của AI hết. Amazing, right?\n\nDũng: Đỉnh thật sự! Tiện đây Hùng share thêm về cái nội công bên trong của model này đi.\n\nHùng: Chắc chắn rồi. Model được train trên 10000 hours audio chất lượng cao, nên nó hỗ trợ code-switching Anh Việt cực mượt, tự nhiên như podcast. Đặc biệt, dự án này hoàn toàn open-source để cộng đồng cùng phát triển.\n\nDũng: Về hiệu năng thì khỏi bàn. Khi test trên GPU quốc dân RTX 3060, tốc độ sinh audio nhanh gấp 10 lần realtime. Và đừng lo, nếu bạn không có card đồ hỏa xịn, tụi mình có sẵn bản CPU version để ai cũng có thể tiếp cận được.\n\nPhương: Tốc độ cực nhanh, hỗ trợ đa nền tảng và hoàn toàn miễn phí. Mọi người hãy cùng trải nghiệm nhé!'
                        )
                        conv_time_estimate_md = gr.Markdown("⏳ **Ước tính thời gian:** ~19s", elem_classes="time-estimate")
                        
                        with gr.Row():
                            btn_detect_speakers = gr.Button("🔍 Quét nhân vật", size="sm", variant="secondary")
                            silence_slider = gr.Slider(minimum=0, maximum=3, value=0.1, step=0.1, label="⏱️ Khoảng lặng (giây)")

                        gr.Markdown("### 🎭 Cấu hình giọng đọc")
                        gr.Markdown("*Nhấn **Quét nhân vật** để tự động phát hiện và ánh xạ giọng đọc. Tải model trước để có danh sách giọng.*")

                        # Pre-build MAX_SPEAKERS speaker slot rows
                        speaker_name_boxes = []
                        speaker_voice_dds  = []
                        speaker_audios     = []
                        speaker_slot_rows  = []

                        for _i in range(MAX_SPEAKERS):
                            # Mặc định cho 3 nhân vật đầu tiên theo yêu cầu
                            _default_name = ""
                            _default_voice = None
                            _row_visible = False
                            
                            if _i == 0:
                                _default_name = "Phương"
                                _default_voice = "Ly"
                                _row_visible = True
                            elif _i == 1:
                                _default_name = "Dũng"
                                _default_voice = "Binh"
                                _row_visible = True
                            elif _i == 2:
                                _default_name = "Hùng"
                                _default_voice = "Sơn"
                                _row_visible = True
                            elif _i < 2:
                                _default_name = f"Nhân vật {_i+1}"
                                _row_visible = True

                            with gr.Row(visible=_row_visible) as _row:
                                _name = gr.Textbox(
                                    value=_default_name,
                                    label="👤 Nhân vật",
                                    interactive=False,
                                    scale=1,
                                    min_width=110
                                )
                                _dd = gr.Dropdown(
                                    choices=PRESET_VOICES_CACHE,
                                    value=_default_voice,
                                    label="🎤 Giọng đọc",
                                    interactive=True,
                                    scale=2,
                                    allow_custom_value=True
                                )
                                _audio = gr.Audio(
                                    label="🎵 Audio mẫu clone (.wav) (Tùy chọn)",
                                    type="filepath",
                                    scale=3
                                )
                            speaker_slot_rows.append(_row)
                            speaker_name_boxes.append(_name)
                            speaker_voice_dds.append(_dd)
                            speaker_audios.append(_audio)
                        
                        btn_generate_conv = gr.Button("🎭 Bắt đầu hội thoại", variant="primary", interactive=False)

                # Global Generation Settings
                with gr.Row():
                    use_batch = gr.Checkbox(
                        value=DEFAULT_USE_BATCH,
                        label="⚡ Batch Processing",
                        info="Mặc định xử lý 16 đoạn cùng lúc để tăng tốc. Giảm Batch Size nếu thiếu bộ nhớ."
                    )
                    max_batch_size_run = gr.Slider(
                        minimum=1,
                        maximum=32,
                        value=default_batch_size,
                        step=1,
                        label="📊 Batch Size (Generation)",
                        info="Số lượng đoạn văn bản xử lý cùng lúc. Giá trị cao = nhanh hơn nhưng tốn VRAM hơn. Giảm xuống nếu gặp lỗi Out of Memory."
                    )
                
                with gr.Accordion("⚙️ Cài đặt nâng cao (Generation)", open=False):
                    with gr.Row():
                        temperature_slider = gr.Slider(
                            minimum=0.1, maximum=1.5, value=default_temp, step=0.1,
                            label="🌡️ Temperature", 
                            info="Độ sáng tạo. Cao = đa dạng cảm xúc hơn nhưng dễ lỗi. Thấp = ổn định hơn."
                        )
                        max_chars_chunk_slider = gr.Slider(
                            minimum=128, maximum=512,
                            value=MAX_CHARS_PER_CHUNK, step=32,
                            label="📝 Max Chars per Chunk",
                            info="Mặc định 224 ký tự để giọng liền mạch hơn. Giảm xuống nếu gặp lỗi lặp hoặc thiếu lời."
                        )
                
                # State to track current mode
                current_mode_state = gr.State("preset_mode")
                
                with gr.Row():
                    btn_stop = gr.Button("⏹️ Dừng", variant="stop", scale=1, interactive=False)
            
            # --- OUTPUT ---
            with gr.Column(scale=2):
                audio_output = gr.Audio(
                    label="Kết quả",
                    type="filepath",
                    autoplay=True,
                    format="mp3",
                    show_download_button=True
                )
                with gr.Group():
                    status_output = gr.Textbox(
                        label="Trạng thái", 
                        elem_classes="status-box",
                        lines=2,
                        max_lines=10,
                        show_copy_button=True
                    )
                with gr.Group():
                    estimate_output = gr.Textbox(
                        label="Ước tính thời gian",
                        elem_classes="estimate-box",
                        lines=2,
                        max_lines=4,
                        show_copy_button=True
                    )
                download_btn = gr.DownloadButton(
                    "📥 Tải xuống file Audio",
                    variant="primary",
                    visible=False,
                    elem_classes="download-btn"
                )
                batch_audio_files = gr.File(
                    label="📥 Audio hàng loạt đã hoàn thành — bấm tên file để tải",
                    file_count="multiple",
                    type="filepath",
                    interactive=False,
                    elem_id="batch-audio-files"
                )
                gr.Markdown(
                    "<div style='text-align: center; color: #64748b; font-size: 0.8rem;'>🔒 Audio được đóng dấu bản quyền ẩn (Watermarker) để bảo mật và định danh AI.</div>",
                    visible=_watermark_available(),
                )
        
        codec_select.change(
            on_codec_change, 
            inputs=[codec_select, current_mode_state], 
            outputs=[tab_custom, tabs, current_mode_state]
        )
        
        # Bind tab events to update state
        tab_preset.select(
            fn=lambda: (gr.update(visible=True), "preset_mode"),
            outputs=[single_text_panel, current_mode_state]
        )
        tab_custom.select(
            fn=lambda mode: (gr.update(visible=(mode != "Hội thoại (Nhiều giọng clone)")), "custom_mode"),
            inputs=[clone_mode_radio],
            outputs=[single_text_panel, current_mode_state]
        )
        
        custom_audio.change(validate_audio_duration, inputs=[custom_audio], outputs=[cloning_warning_msg])
        trained_voice_dropdown.change(
            _load_trained_voice_audio,
            inputs=[trained_voice_dropdown],
            outputs=[custom_audio]
        )

        btn_pause_settings.click(
            lambda: gr.update(visible=True),
            outputs=pause_settings_panel,
            queue=False,
        )
        btn_close_pause.click(
            lambda: gr.update(visible=False),
            outputs=pause_settings_panel,
            queue=False,
        )
        btn_done_pause.click(
            lambda: gr.update(visible=False),
            outputs=pause_settings_panel,
            queue=False,
        )

        def _step_pause(value, delta):
            try:
                value = float(value)
            except (TypeError, ValueError):
                value = 0.0
            return round(min(3.0, max(0.0, value + delta)), 1)

        for _pause_key, (_minus, _plus) in pause_buttons.items():
            _value = pause_values[_pause_key]
            _minus.click(
                lambda value: _step_pause(value, -0.1),
                inputs=_value,
                outputs=_value,
                queue=False,
            )
            _plus.click(
                lambda value: _step_pause(value, 0.1),
                inputs=_value,
                outputs=_value,
                queue=False,
            )

        btn_reset_pause.click(
            lambda: tuple(PAUSE_DEFAULTS[key] for key in PAUSE_KEYS),
            outputs=[pause_values[key] for key in PAUSE_KEYS],
            queue=False,
        )
        
        # --- Custom Model Event Handlers ---

        def on_backbone_change(choice):
            is_custom = (choice == "Custom Model")
            is_v3 = "v3" in (choice or "").lower()
            is_v2_gpu = (choice == "VieNeu-TTS-v2 (GPU)")
            # Voice Cloning: v3 clones from audio only; v2 (GPU) clones from
            # audio + a reference transcript. Both expose the cloning tab.
            clone_ok = is_v3 or is_v2_gpu
            print(f"   🔄 Backbone changed to: {choice}")
            
            # 1. Device logic
            # Allow hardware acceleration (MPS/CUDA/Auto) for all GPU models AND Turbo (GGUF) models
            is_hw_accel_supported = "(GPU)" in choice or "v2-Turbo" in choice or "v3" in choice.lower() or is_custom
            
            if is_hw_accel_supported:
                dev_choices = get_available_devices()
                initial_dev = "Auto"
            else:
                dev_choices = ["CPU"]
                initial_dev = "CPU"
            
            # 2. Parameter logic
            if is_v3:
                # v3 Turbo uses its own MOSS codec; conservative sampling by default.
                codec_update = gr.update(value="VieNeu-Codec", interactive=False)
                text_update = gr.update(value=DEFAULT_TEXT_V3)
                temp_update = gr.update(value=DEFAULT_GENERATION_TEMPERATURE)
            elif "Turbo" in choice:
                codec_update = gr.update(value="VieNeu-Codec", interactive=False)
                text_update = gr.update(value=DEFAULT_TEXT_TURBO)
                temp_update = gr.update(value=DEFAULT_GENERATION_TEMPERATURE)
            elif "(CPU)" in choice:
                codec_update = gr.update(value="NeuCodec (ONNX)", interactive=False)
                text_update = gr.update(value=DEFAULT_TEXT_GPU)
                temp_update = gr.update(value=DEFAULT_GENERATION_TEMPERATURE)
            else:
                codec_update = gr.update(value="NeuCodec (Distill)", interactive=False)
                text_update = gr.update(value=DEFAULT_TEXT_GPU)
                temp_update = gr.update(value=DEFAULT_GENERATION_TEMPERATURE)

            # Reference-transcript box + info text differ between v2 and v3 clone.
            if is_v2_gpu:
                clone_info_update = gr.update(value=(
                    "ℹ️ **Voice Cloning (VieNeu-TTS v2).** Tải lên audio mẫu 3–5 giây "
                    "và **nhập đúng nội dung** của audio đó (kể cả dấu câu) — v2 cần "
                    "reference transcript để clone giọng."
                ))
            else:
                clone_info_update = gr.update(value=(
                    "ℹ️ **Voice Cloning (VieNeu-TTS v3).** Chỉ cần tải lên audio mẫu "
                    "3–5 giây; v3 clone trực tiếp từ audio, không cần nhập nội dung."
                ))

            return (
                gr.update(visible=is_custom),
                codec_update,
                text_update,
                temp_update,
                gr.update(choices=dev_choices, value=initial_dev),
                gr.update(visible=clone_ok),   # cloning_elements_group
                gr.update(visible=clone_ok),   # tab_custom — clone tab (v3 + v2 GPU)
                gr.update(value=DEFAULT_GENERATION_BATCH_SIZE),  # max_batch_size_run
                gr.update(visible=not is_v3),  # use_lmdeploy_cb — irrelevant for v3 (PyTorch, no LMDeploy)
                gr.update(visible=is_v2_gpu),  # custom_text — only v2 needs a reference transcript
                clone_info_update,             # clone_info_md
                gr.update(value=MAX_CHARS_PER_CHUNK),  # max_chars_chunk_slider
                gr.update(value=DEFAULT_USE_BATCH),  # use_batch
            )

        backbone_select.change(
            on_backbone_change,
            inputs=[backbone_select],
            outputs=[
                custom_model_group,
                codec_select,
                text_input,
                temperature_slider,
                device_choice,
                cloning_elements_group,
                tab_custom,
                max_batch_size_run,
                use_lmdeploy_cb,
                custom_text,
                clone_info_md,
                max_chars_chunk_slider,
                use_batch,
            ]
        )
        
        custom_backbone_model_id.change(
            on_custom_id_change,
            inputs=[custom_backbone_model_id],
            outputs=[custom_backbone_base_model, custom_audio, custom_text]
        )

        btn_load.click(
            fn=load_model,
            inputs=[backbone_select, codec_select, device_choice, use_lmdeploy_cb,
                    custom_backbone_model_id, custom_backbone_base_model, custom_backbone_hf_token],
            outputs=[model_status, btn_generate, btn_generate_conv, btn_load, btn_stop, voice_select,
                     tab_preset, tab_custom, tabs, current_mode_state,
                     conv_tab,
                     *speaker_voice_dds]
        )
        
        # --- PDF Upload Event Handlers ---
        def on_pdf_upload(pdf_file):
            """Extract text from uploaded PDF and populate text input."""
            if not pdf_file:
                return gr.update(), gr.update(visible=False)
            extracted = extract_text_from_pdf(pdf_file)
            if extracted.startswith("⚠️"):
                return gr.update(), gr.update(value=extracted, visible=True)
            char_count = len(extracted)
            return (
                gr.update(value=extracted),
                gr.update(
                    value=f"✅ Đã trích xuất **{char_count:,}** ký tự từ file PDF. Bạn có thể chỉnh sửa văn bản bên dưới.",
                    visible=True
                )
            )

        pdf_upload.change(
            fn=on_pdf_upload,
            inputs=[pdf_upload],
            outputs=[text_input, pdf_status]
        )
        btn_extract_pdf.click(
            fn=on_pdf_upload,
            inputs=[pdf_upload],
            outputs=[text_input, pdf_status]
        )

        # --- Conversation Event Handlers ---
        # Scan speakers → update all 8 slot rows/names/dropdowns
        btn_detect_speakers.click(
            fn=extract_speakers_from_script,
            inputs=[conv_script_input],
            outputs=speaker_name_boxes + speaker_voice_dds + speaker_slot_rows
        )
        
        conv_gen_event = btn_generate_conv.click(
            fn=synthesize_conversation_with_empty_estimate,
            inputs=[conv_script_input,
                    *speaker_name_boxes,
                    *speaker_voice_dds,
                    *speaker_audios,
                    silence_slider, temperature_slider, max_chars_chunk_slider,
                    session_id_state],
            outputs=[audio_output, status_output, estimate_output, batch_audio_files],
            concurrency_id="tts_generation", concurrency_limit=1
        )

        for _i in range(MAX_SPEAKERS):
            speaker_voice_dds[_i].change(
                fn=_load_trained_voice_audio,
                inputs=[speaker_voice_dds[_i]],
                outputs=[speaker_audios[_i]]
            )

        # --- Voice Cloning Conversation Event Handlers ---
        def on_clone_mode_change(mode):
            is_conv = (mode == "Hội thoại (Nhiều giọng clone)")
            return (
                gr.update(visible=not is_conv), # cloning_elements_group
                gr.update(visible=is_conv),     # conv_clone_group
                gr.update(visible=not is_conv), # single_text_panel
            )

        clone_mode_radio.change(
            fn=on_clone_mode_change,
            inputs=[clone_mode_radio],
            outputs=[cloning_elements_group, conv_clone_group, single_text_panel]
        )

        btn_conv_clone_detect.click(
            fn=extract_speakers_for_clone_conv,
            inputs=[conv_clone_script_input],
            outputs=clone_speaker_name_boxes + clone_speaker_voice_dds + clone_speaker_slot_rows
        )

        for _i in range(MAX_SPEAKERS):
            clone_speaker_voice_dds[_i].change(
                fn=_load_trained_voice_audio,
                inputs=[clone_speaker_voice_dds[_i]],
                outputs=[clone_speaker_audios[_i]]
            )

        conv_clone_gen_event = btn_generate_conv_clone.click(
            fn=synthesize_conversation_with_empty_estimate,
            inputs=[
                conv_clone_script_input,
                *clone_speaker_name_boxes,
                *clone_speaker_voice_dds,
                *clone_speaker_audios,
                conv_clone_silence_slider,
                temperature_slider,
                max_chars_chunk_slider,
                conv_clone_denoise_cb,
                session_id_state
            ],
            outputs=[audio_output, status_output, estimate_output, batch_audio_files],
            concurrency_id="tts_generation", concurrency_limit=1
        )
        btn_generate_conv_clone.click(lambda: gr.update(visible=False), outputs=[download_btn])
        btn_generate_conv_clone.click(lambda: gr.update(interactive=True), outputs=btn_stop)
        conv_clone_gen_event.then(lambda: gr.update(interactive=False), outputs=btn_stop)

        conv_clone_script_input.change(
            fn=estimate_time_ui,
            inputs=[conv_clone_script_input],
            outputs=[conv_clone_time_estimate_md]
        )
        btn_generate_conv.click(lambda: gr.update(visible=False), outputs=[download_btn])
        btn_generate_conv.click(lambda: gr.update(interactive=True), outputs=btn_stop)
        conv_gen_event.then(lambda: gr.update(interactive=False), outputs=btn_stop)

        # --- Auto-adjust Temperature on Tab Switch ---
        conv_tab.select(
            fn=lambda _bb: gr.update(value=DEFAULT_GENERATION_TEMPERATURE),
            inputs=backbone_select,
            outputs=temperature_slider
        )
        single_tab.select(
            fn=lambda _bb: gr.update(value=DEFAULT_GENERATION_TEMPERATURE),
            inputs=backbone_select,
            outputs=temperature_slider
        )
        
        # --- Batch Files Change Handler ---
        def on_batch_files_change(files):
            if not files:
                return "💡 *Chưa chọn file nào. Kéo thả nhiều file .txt vào đây để kích hoạt chế độ chạy qua đêm.*"
            n_files = len(files)
            total_bytes = 0
            file_lines = []
            for i, f in enumerate(files[:10]):
                fname = txt_filename(f)
                try:
                    sz = os.path.getsize(f)
                    total_bytes += sz
                    file_lines.append(f"{i+1}. 📄 `{fname}` (~{sz:,} bytes)")
                except Exception:
                    file_lines.append(f"{i+1}. 📄 `{fname}`")
            if n_files > 10:
                file_lines.append(f"... và còn {n_files - 10} file khác nữa.")
            est_sec = total_bytes / 80.5 if total_bytes > 0 else n_files * 60
            summary = (
                f"📋 **Đã chọn {n_files} file .txt để đọc qua đêm:**\n"
                + "\n".join(file_lines)
                + f"\n\n⏱️ **Ước tính thời gian:** ~{_format_duration(est_sec)}\n"
                f"💡 *Nhấn **📚 Bắt đầu xử lý các file TXT**, hệ thống sẽ tự động đọc tuần tự từng file và lưu audio vào thư mục đã chọn.*"
            )
            return summary

        batch_txt_files.change(
            fn=on_batch_files_change,
            inputs=[batch_txt_files],
            outputs=[batch_txt_info]
        )

        # --- Smart Split Handler ---
        def _do_smart_split(text: str, max_chars: int):
            """Wrapper gọi smart_reformat_script và trả về text mới + status."""
            if not text or not text.strip():
                return text, "⚠️ Chưa có văn bản để tách."
            reformatted = smart_reformat_script(text, max_chars=int(max_chars))
            n_lines = len([l for l in reformatted.splitlines() if l.strip()])
            return reformatted, (
                f"✅ Đã tách thành **{n_lines} đoạn** tại dấu kết câu. "
                f"Câu dài hơn {int(max_chars)} ký tự được giữ nguyên, không cắt giữa chừng."
            )

        btn_smart_split.click(
            fn=_do_smart_split,
            inputs=[text_input, max_chars_chunk_slider],
            outputs=[text_input, split_status_md],
        )

        # --- Standard Generation Handlers ---
        gen_event = btn_generate.click(
            fn=synthesize_speech_with_estimate,
            inputs=[text_input, voice_select, custom_audio, custom_text, current_mode_state,
                    generation_mode, use_batch, max_batch_size_run,
                    temperature_slider, max_chars_chunk_slider,
                    denoise_checkbox, session_id_state,
                    batch_txt_files, auto_download_cb, batch_output_dir,
                    *[pause_values[key] for key in PAUSE_KEYS], quality_plus_checkbox],
            outputs=[audio_output, status_output, estimate_output, batch_audio_files],
            concurrency_id="tts_generation", concurrency_limit=1
        )

        batch_audio_files.change(
            fn=None, inputs=[batch_audio_files, auto_download_cb], outputs=None,
            js=batch_download_js, queue=False
        )
        btn_choose_batch_dir.click(
            fn=choose_output_directory, inputs=[batch_output_dir], outputs=[batch_output_dir], queue=False
        )
        batch_event = btn_generate_batch.click(
            fn=synthesize_batch_speech_with_estimate,
            inputs=[text_input, voice_select, custom_audio, custom_text, batch_clone_mode,
                    generation_mode, use_batch, max_batch_size_run,
                    temperature_slider, max_chars_chunk_slider,
                    denoise_checkbox, session_id_state,
                    batch_txt_files, auto_download_cb, batch_output_dir,
                    *[pause_values[key] for key in PAUSE_KEYS], quality_plus_checkbox],
            outputs=[audio_output, status_output, estimate_output, batch_audio_files],
            concurrency_id="tts_generation", concurrency_limit=1
        )
        btn_generate_batch.click(lambda: gr.update(interactive=True), outputs=btn_stop, queue=False)
        batch_event.then(lambda: gr.update(interactive=False), outputs=btn_stop)
        btn_generate.click(lambda: gr.update(visible=False), outputs=[download_btn])
        btn_generate.click(lambda: gr.update(interactive=True), outputs=btn_stop)
        gen_event.then(lambda: gr.update(interactive=False), outputs=btn_stop)

        # --- Stop Button ---
        def request_stop():
            print("🛑 STOP REQUESTED via button click.")
            _STOP_EVENT.set()
            return gr.skip(), "⏹️ Đã dừng tạo giọng nói.", "", gr.skip(), gr.update(interactive=False)

        # Handler: set stop event + update UI
        # Note: We avoid cancels= here to prevent internal Gradio KeyError crashes,
        # relying instead on the frequent _STOP_EVENT.is_set() checks in the code.
        btn_stop.click(fn=request_stop, outputs=[audio_output, status_output, estimate_output, batch_audio_files, btn_stop], queue=False)

        # --- Download Button Event Handlers ---
        def on_audio_generated(audio_path):
            """Show download button when audio is generated."""
            if audio_path and os.path.exists(audio_path):
                return gr.update(value=audio_path, visible=True)
            return gr.update(visible=False)

        # Connect to generation events (must be after gen_event/conv_gen_event are defined)
        gen_event.then(
            fn=on_audio_generated,
            inputs=[audio_output],
            outputs=[download_btn]
        )
        conv_gen_event.then(
            fn=on_audio_generated,
            inputs=[audio_output],
            outputs=[download_btn]
        )
        conv_clone_gen_event.then(
            fn=on_audio_generated,
            inputs=[audio_output],
            outputs=[download_btn]
        )
        audio_output.change(
            fn=on_audio_generated,
            inputs=[audio_output],
            outputs=[download_btn]
        )
        btn_generate_batch.click(lambda: gr.update(visible=False), outputs=[download_btn], queue=False)
        # Also connect the stop button to hide download
        btn_stop.click(
            fn=lambda: gr.update(visible=False),
            outputs=[download_btn]
        )
        
        text_input.change(
            fn=estimate_time_ui,
            inputs=[text_input],
            outputs=[time_estimate_md]
        )
        conv_script_input.change(
            fn=estimate_time_ui,
            inputs=[conv_script_input],
            outputs=[conv_time_estimate_md]
        )

        # Persistence: Restore UI state on load
        btn_load.click(
            fn=lambda: gr.update(interactive=True),
            outputs=[btn_generate_conv_clone]
        )
        demo.load(
            fn=restore_ui_state,
            outputs=[model_status, btn_generate, btn_generate_conv, btn_stop]
        )

def main():
    # Cho phép override từ biến môi trường (hữu ích cho Docker)
    server_name = os.getenv("GRADIO_SERVER_NAME", "127.0.0.1")
    server_port = int(os.getenv("GRADIO_SERVER_PORT", "7860"))

    # Check running in Colab
    is_on_colab = os.getenv("COLAB_RELEASE_TAG") is not None

    # Default:
    # - Colab: share=True (convenient)
    # - Docker/local: share=False (safe)
    share = env_bool("GRADIO_SHARE", default=is_on_colab)
    
    # If server_name is "0.0.0.0" and GRADIO_SHARE is not set, disable sharing
    allowed_paths = [
        os.path.abspath("outputs"),
        os.path.abspath("outputs/batch_cloned"),
        os.path.abspath("examples"),
        r"D:\AUDIO_SLEP",
    ]
    demo.queue().launch(server_name=server_name, server_port=server_port, share=share, allowed_paths=allowed_paths)

if __name__ == "__main__":
    main()
