"""File handling shared by the two batch TXT interfaces."""
import os
import subprocess
import sys
from pathlib import Path
from functools import wraps
from inspect import signature
import re


class UploadedTxtPath(str):
    def __new__(cls, path, original_name):
        value = super().__new__(cls, path)
        value.orig_name = original_name
        return value


def preserve_txt_upload_names(component):
    """Retain FileData.orig_name before Gradio converts uploads into plain paths."""
    original_preprocess = component.preprocess

    def preprocess(payload):
        paths = original_preprocess(payload)
        if not paths:
            return paths
        records = payload.root if hasattr(payload, "root") else [payload]
        if isinstance(paths, list):
            return [UploadedTxtPath(path, record.orig_name) for path, record in zip(paths, records)]
        return UploadedTxtPath(paths, records[0].orig_name)

    component.preprocess = preprocess


def txt_filename(path):
    original = getattr(path, "orig_name", None) or Path(path).name
    # Upload metadata is untrusted: strip paths and characters Windows disallows.
    name = re.split(r"[/\\]", original)[-1]
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name if Path(name).suffix.lower() == ".txt" else Path(path).name


def prepare_batch(files, output_dir):
    selected = (output_dir or "").strip().strip('"') or "outputs/batch_cloned"
    directory = Path(selected).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    # Fail before enrolling the voice or generating a long chapter.
    import tempfile
    with tempfile.TemporaryFile(dir=directory):
        pass
    valid = []
    for item in files or []:
        if isinstance(item, dict):
            path = item.get("path")
            if path:
                path = UploadedTxtPath(path, item.get("orig_name"))
        elif isinstance(item, (str, os.PathLike)):
            path = item
        else:
            path = getattr(item, "name", item)
        if path and Path(path).is_file() and Path(path).suffix.lower() == ".txt":
            valid.append(os.fspath(path))
    return str(directory), valid


def audio_path_for_txt(directory, txt_path):
    # Preserve accents, spaces and punctuation. Never overwrite an earlier run.
    name = Path(txt_filename(txt_path)).stem + ".mp3"
    target = Path(directory) / name
    index = 2
    while target.exists():
        target = Path(directory) / f"lan_{index}" / name
        index += 1
    target.parent.mkdir(parents=True, exist_ok=True)
    return str(target)


def allow_generated_audio(path):
    """Permit this completed export before Gradio copies it to its download cache."""
    from gradio.context import LocalContext

    blocks = LocalContext.blocks.get(None)
    if blocks is None:
        return
    audio = Path(path).resolve(strict=True)
    if audio.suffix.lower() != ".mp3" or not audio.is_file():
        raise ValueError("File audio xuất ra không hợp lệ.")
    absolute = str(audio)
    if absolute not in blocks.allowed_paths:
        blocks.allowed_paths.append(absolute)


def read_batch_text(path):
    data = Path(path).read_bytes()
    encodings = ["utf-16"] if data.startswith((b"\xff\xfe", b"\xfe\xff")) else ["utf-8-sig", "cp1258"]
    for encoding in encodings:
        try:
            return data.decode(encoding).strip()
        except UnicodeError:
            continue
    raise ValueError("Không đọc được mã hóa TXT; hãy lưu file dưới dạng UTF-8.")


def require_batch_files(synthesize):
    @wraps(synthesize)
    def run(*args, **kwargs):
        params = signature(synthesize).bind(*args, **kwargs)
        params.apply_defaults()
        try:
            directory, files = prepare_batch(
                params.arguments["batch_txt_files"], params.arguments["batch_output_dir"]
            )
        except (OSError, ValueError) as err:
            yield None, f"❌ Không thể dùng thư mục lưu audio: {err}", []
            return
        if not files:
            yield None, "⚠️ Vui lòng chọn ít nhất một file TXT để xử lý hàng loạt.", []
            return
        params.arguments.update(batch_txt_files=files, batch_output_dir=directory, mode_tab="custom_mode")
        yield from synthesize(*params.args, **params.kwargs)
    return run


def choose_output_directory(current):
    """Open a folder chooser on the local machine running this desktop app."""
    import gradio as gr
    if sys.platform != "win32":
        gr.Info("Nhập đường dẫn thư mục muốn lưu vào ô Thư mục lưu audio.")
        return current
    script = """
Add-Type -AssemblyName System.Windows.Forms
$picker = New-Object System.Windows.Forms.FolderBrowserDialog
$picker.Description = 'Chon thu muc luu audio VieNeu-TTS'
$picker.ShowNewFolderButton = $true
if (Test-Path -LiteralPath $env:VIENEU_PICKER_DIR -PathType Container) {
    $picker.SelectedPath = $env:VIENEU_PICKER_DIR
}
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
try {
    if ($picker.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) {
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        [Console]::Write($picker.SelectedPath)
    }
} finally { $picker.Dispose(); $owner.Dispose() }
"""
    env = os.environ.copy()
    env["VIENEU_PICKER_DIR"] = os.path.abspath(current or "outputs/batch_cloned")
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command", script],
            env=env, capture_output=True, encoding="utf-8", errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW, check=True,
        )
        return result.stdout.strip().lstrip("\ufeff") or current
    except (OSError, subprocess.CalledProcessError):
        gr.Warning("Không mở được hộp chọn thư mục. Bạn có thể nhập đường dẫn trực tiếp.")
        return current
