from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Callable

import numpy as np
import soundfile as sf

from apps.user_voices import load_user_voices, save_user_voice, delete_user_voice, list_user_voices
from apps.quality_plus import QualitySession
from vieneu import Vieneu
from vieneu_utils.core_utils import gaps_to_silence, join_audio_chunks
from vieneu_utils.phonemize_text import normalize_to_chunks_v3_with_gaps, phonemize_text_with_emotions


class DesktopEngine:
    def __init__(self):
        self.tts = None
        self.model_name = ""
        self.lock = threading.RLock()

    @property
    def loaded(self) -> bool:
        return self.tts is not None

    def load(self, model: str, device: str, precision: str, batch_size: int) -> list[str]:
        with self.lock:
            device_arg = "auto" if device.lower() == "auto" else device.lower()
            if "Nano" in model:
                self.tts = Vieneu(mode="v3nano", device=device_arg)
            else:
                self.tts = Vieneu(mode="v3turbo", device=device_arg, precision=precision,
                                  max_batch_size=max(1, int(batch_size)))
            self.model_name = model
            load_user_voices(self.tts)
            return self.voices()

    def voices(self) -> list[str]:
        if not self.tts:
            return []
        return list(getattr(self.tts, "_preset_voices", {}).keys())

    def user_voices(self) -> list[str]:
        return list_user_voices(self.tts)

    def save_voice(self, name: str, audio: str, denoise: bool = True) -> str:
        return save_user_voice(self.tts, name, audio, denoise=denoise)

    def delete_voice(self, name: str) -> None:
        delete_user_voice(self.tts, name)

    def _turbo_reference(self, voice: str | None, ref_audio: str | None, denoise: bool):
        if ref_audio:
            return self.tts.encode_reference(ref_audio, denoise=denoise)
        preset = self.tts.get_preset_voice(voice)
        return preset["speaker_emb"], preset.get("codes")

    def synthesize(self, text: str, *, voice: str | None = None, ref_audio: str | None = None,
                   denoise: bool = True, temperature: float = .4, max_chars: int = 224,
                   use_batch: bool = True, batch_size: int = 16, pauses: dict | None = None,
                   quality: bool = False, stop_event: threading.Event | None = None,
                   progress: Callable[[str], None] | None = None) -> np.ndarray:
        if not self.tts:
            raise RuntimeError("Hãy tải model trước")
        text = (text or "").strip()
        if not text:
            raise ValueError("Văn bản đang trống")
        stop_event = stop_event or threading.Event()
        progress = progress or (lambda _message: None)

        with self.lock:
            if "Nano" in self.model_name:
                if quality:
                    raise ValueError("Quality+ hiện chỉ hỗ trợ VieNeu-TTS v3 Turbo")
                speaker, codes = self._turbo_reference(voice, ref_audio, denoise)
                chunks, gaps = normalize_to_chunks_v3_with_gaps(text, max_chars=min(max_chars, 224))
                if not chunks:
                    raise ValueError("Không tìm thấy câu có thể đọc")
                wavs: list[np.ndarray] = []
                for index, chunk in enumerate(chunks):
                    if stop_event.is_set():
                        raise InterruptedError("Đã dừng theo yêu cầu")
                    progress(f"Nano đang xử lý đoạn {index + 1}/{len(chunks)}")
                    wavs.append(self.tts.engine.infer(
                        phonemes=phonemize_text_with_emotions(chunk),
                        speaker_emb=speaker,
                        ref_codes=codes,
                    ))
                return join_audio_chunks(
                    wavs,
                    self.tts.sample_rate,
                    silence_ps=gaps_to_silence(gaps, pauses),
                )

            speaker, codes = self._turbo_reference(voice, ref_audio, denoise)
            if quality:
                if not ref_audio:
                    raise ValueError("Quality+ cần audio mẫu trong chế độ Clone")
                session = QualitySession(self.tts, speaker, codes, stop_event)
                final = None
                for wav, message in session.generate(text, temperature, pauses):
                    progress(message)
                    if wav is not None:
                        final = wav
                if final is None:
                    raise RuntimeError("Quality+ đã dừng hoặc không tạo được audio")
                self.last_quality_report = session.report
                return final

            chunks, gaps = normalize_to_chunks_v3_with_gaps(text, max_chars=max_chars)
            if not chunks:
                raise ValueError("Không tìm thấy câu có thể đọc")
            phonemes = [phonemize_text_with_emotions(chunk) for chunk in chunks]
            wavs: list[np.ndarray] = []
            group_size = max(1, int(batch_size)) if use_batch else 1
            for start in range(0, len(chunks), group_size):
                if stop_event.is_set():
                    raise InterruptedError("Đã dừng theo yêu cầu")
                end = min(start + group_size, len(chunks))
                progress(f"Đang xử lý đoạn {start + 1}–{end}/{len(chunks)}")
                if group_size > 1 and getattr(getattr(self.tts, "engine", None), "device", None) is not None:
                    sampling = dict(temperature=temperature, top_k=25, top_p=.95,
                                    max_new_frames=300, repetition_penalty=1.2,
                                    repetition_window=64)
                    wavs.extend(self.tts._infer_chunks(chunks[start:end], speaker, codes, True,
                                                       group_size, sampling))
                else:
                    for ph in phonemes[start:end]:
                        if stop_event.is_set():
                            raise InterruptedError("Đã dừng theo yêu cầu")
                        wavs.append(self.tts.engine.infer(
                            phonemes=ph, speaker_emb=speaker, ref_codes=codes,
                            use_ref_codes=True, temperature=temperature, max_new_frames=300))
            return join_audio_chunks(wavs, self.tts.sample_rate,
                                     silence_ps=gaps_to_silence(gaps, pauses))

    def save_audio(self, path: str | Path, wav: np.ndarray) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + ".part.wav")
        sf.write(temp, wav, self.tts.sample_rate)
        if path.suffix.lower() == ".wav":
            os.replace(temp, path)
        else:
            try:
                from pydub import AudioSegment
                try:
                    import imageio_ffmpeg
                    AudioSegment.converter = imageio_ffmpeg.get_ffmpeg_exe()
                except Exception:
                    pass
                AudioSegment.from_wav(temp).export(path, format=path.suffix.lstrip("."))
                temp.unlink(missing_ok=True)
            except Exception as exc:
                temp.unlink(missing_ok=True)
                raise RuntimeError("Không thể xuất MP3; hãy chọn WAV hoặc chạy lại bộ cài thư viện") from exc
        return path

