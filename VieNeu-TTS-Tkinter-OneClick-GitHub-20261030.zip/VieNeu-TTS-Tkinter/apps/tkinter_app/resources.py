from __future__ import annotations

from pathlib import Path


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def trained_voice_samples(root: str | Path | None = None) -> dict[str, Path]:
    """Return one representative WAV for each finetune dataset voice."""
    base = Path(root) if root is not None else project_root()
    audio_dir = base / "finetune" / "dataset" / "raw_audio"
    grouped: dict[str, list[Path]] = {}
    if not audio_dir.is_dir():
        return {}
    for path in sorted(audio_dir.glob("*.wav"), key=lambda item: item.name.casefold()):
        stem, separator, suffix = path.stem.rpartition("_")
        name = stem if separator and suffix.isdigit() else path.stem
        grouped.setdefault(name, []).append(path)
    return {name: files[len(files) // 2] for name, files in grouped.items()}


def clone_audio_examples(root: str | Path | None = None) -> dict[str, Path]:
    """Return bundled clone examples with a short transcript in the label."""
    base = Path(root) if root is not None else project_root()
    audio_dir = base / "examples" / "audio_ref"
    result: dict[str, Path] = {}
    if not audio_dir.is_dir():
        return result
    for index, path in enumerate(sorted(audio_dir.glob("*.wav"), key=lambda item: item.name.casefold()), 1):
        transcript_path = path.with_suffix(".txt")
        transcript = ""
        if transcript_path.is_file():
            transcript = transcript_path.read_text(encoding="utf-8-sig", errors="replace").strip()
            transcript = " ".join(transcript.split())
        detail = transcript[:58] + ("…" if len(transcript) > 58 else "")
        label = f"Mẫu {index} — {detail or path.stem}"
        result[label] = path
    return result
