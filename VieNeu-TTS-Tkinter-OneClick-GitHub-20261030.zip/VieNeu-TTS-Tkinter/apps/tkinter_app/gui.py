from __future__ import annotations

import json
import os
import queue
import tempfile
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

import numpy as np

from .config import DEFAULTS, load_config, save_config
from .engine import DesktopEngine
from .resources import clone_audio_examples, trained_voice_samples
from .text_processing import analyze_text, parse_conversation, parse_voice_mapping, read_txt


class VieNeuDesktop(tk.Tk):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.engine = DesktopEngine()
        self.events: queue.Queue = queue.Queue()
        self.stop_event = threading.Event()
        self.worker = None
        self.last_audio = None
        self.batch_files: list[str] = []
        self.started_at = None
        self.title("VieNeu-TTS Desktop — Local Vietnamese Voice Studio")
        self.geometry(self.cfg.get("geometry", "1320x820"))
        self.minsize(1080, 700)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._style()
        self._variables()
        self._build()
        self.after(100, self._poll)

    def _style(self):
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground="#3b4cca")
        style.configure("Heading.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 8))
        style.configure("TButton", padding=(8, 5))
        style.configure("TNotebook.Tab", padding=(14, 7))

    def _variables(self):
        self.model_var = tk.StringVar(value=self.cfg["model"])
        self.device_var = tk.StringVar(value=self.cfg["device"])
        self.precision_var = tk.StringVar(value=self.cfg["precision"])
        self.model_status = tk.StringVar(value="Chưa tải model")
        self.mode_var = tk.StringVar(value="preset")
        self.voice_var = tk.StringVar()
        self.ref_var = tk.StringVar()
        self.trained_voice_var = tk.StringVar()
        self.example_audio_var = tk.StringVar()
        self.trained_voice_paths = trained_voice_samples()
        self.example_audio_paths = clone_audio_examples()
        self.output_var = tk.StringVar(value=self.cfg["output_dir"])
        self.temperature_var = tk.DoubleVar(value=self.cfg["temperature"])
        self.max_chars_var = tk.IntVar(value=self.cfg["max_chars"])
        self.batch_size_var = tk.IntVar(value=self.cfg["batch_size"])
        self.use_batch_var = tk.BooleanVar(value=self.cfg["use_batch"])
        self.denoise_var = tk.BooleanVar(value=self.cfg["denoise"])
        self.smart_var = tk.BooleanVar(value=self.cfg["smart_split"])
        self.quality_var = tk.BooleanVar(value=self.cfg["quality_plus"])
        self.output_format = tk.StringVar(value="wav")
        self.status_var = tk.StringVar(value="Sẵn sàng")
        self.progress_var = tk.DoubleVar(value=0)
        self.pause_vars = {key: tk.DoubleVar(value=value) for key, value in self.cfg["pauses"].items()}

    def _build(self):
        header = ttk.Frame(self, padding=(14, 10))
        header.pack(fill="x")
        ttk.Label(header, text="VieNeu-TTS Desktop", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="Tkinter • chạy local • không cần trình duyệt").pack(side="left", padx=12)
        model_box = ttk.Frame(header)
        model_box.pack(side="right")
        ttk.Combobox(model_box, textvariable=self.model_var, state="readonly", width=25,
                     values=["VieNeu-TTS v3 Turbo", "VieNeu-TTS v3 Nano"]).grid(row=0, column=0, padx=3)
        ttk.Combobox(model_box, textvariable=self.device_var, state="readonly", width=9,
                     values=["Auto", "CUDA", "CPU"]).grid(row=0, column=1, padx=3)
        ttk.Combobox(model_box, textvariable=self.precision_var, state="readonly", width=7,
                     values=["fp32", "int8"]).grid(row=0, column=2, padx=3)
        self.load_button = ttk.Button(model_box, text="Tải model", command=self.load_model, style="Accent.TButton")
        self.load_button.grid(row=0, column=3, padx=5)
        ttk.Label(model_box, textvariable=self.model_status).grid(row=1, column=0, columnspan=4, sticky="e")

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=(0, 6))
        self.story_tab = ttk.Frame(self.tabs, padding=10)
        self.batch_tab = ttk.Frame(self.tabs, padding=10)
        self.conversation_tab = ttk.Frame(self.tabs, padding=10)
        self.voices_tab = ttk.Frame(self.tabs, padding=10)
        self.log_tab = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(self.story_tab, text="📖 Đọc truyện / Clone")
        self.tabs.add(self.batch_tab, text="📚 TXT hàng loạt")
        self.tabs.add(self.conversation_tab, text="🎭 Hội thoại")
        self.tabs.add(self.voices_tab, text="🎤 Thư viện giọng")
        self.tabs.add(self.log_tab, text="🧾 Nhật ký")
        self._build_story()
        self._build_batch()
        self._build_conversation()
        self._build_voices()
        self._build_log()

        bottom = ttk.Frame(self, padding=(12, 4, 12, 10))
        bottom.pack(fill="x")
        ttk.Progressbar(bottom, variable=self.progress_var, maximum=100).pack(fill="x", side="left", expand=True)
        ttk.Label(bottom, textvariable=self.status_var, width=70).pack(side="left", padx=10)
        self.stop_button = ttk.Button(bottom, text="⏹ Dừng sau lượt hiện tại", command=self.stop, state="disabled")
        self.stop_button.pack(side="right")

    def _build_story(self):
        self.story_tab.columnconfigure(1, weight=1)
        self.story_tab.rowconfigure(2, weight=1)
        source = ttk.LabelFrame(self.story_tab, text="Nguồn giọng", padding=10)
        source.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 8))
        ttk.Radiobutton(source, text="Preset", variable=self.mode_var, value="preset").grid(row=0, column=0, padx=4)
        ttk.Radiobutton(source, text="Clone từ audio", variable=self.mode_var, value="clone").grid(row=0, column=1, padx=4)
        ttk.Label(source, text="Giọng:").grid(row=0, column=2, padx=(18, 3))
        self.voice_combo = ttk.Combobox(source, textvariable=self.voice_var, state="readonly", width=28)
        self.voice_combo.grid(row=0, column=3, padx=3)
        ttk.Label(source, text="Audio mẫu:").grid(row=0, column=4, padx=(18, 3))
        ttk.Entry(source, textvariable=self.ref_var, width=48).grid(row=0, column=5, sticky="ew")
        ttk.Button(source, text="Chọn…", command=self.choose_reference).grid(row=0, column=6, padx=4)
        ttk.Checkbutton(source, text="Denoise", variable=self.denoise_var).grid(row=0, column=7, padx=4)
        ttk.Label(source, text="Giọng đã train:").grid(row=1, column=0, columnspan=2, padx=4, pady=(8, 0), sticky="e")
        self.trained_voice_combo = ttk.Combobox(
            source, textvariable=self.trained_voice_var, state="readonly", width=28,
            values=list(self.trained_voice_paths),
        )
        self.trained_voice_combo.grid(row=1, column=2, columnspan=2, padx=3, pady=(8, 0), sticky="ew")
        self.trained_voice_combo.bind("<<ComboboxSelected>>", self.load_trained_reference)
        ttk.Label(source, text="Audio clone mẫu:").grid(row=1, column=4, padx=(18, 3), pady=(8, 0))
        self.example_audio_combo = ttk.Combobox(
            source, textvariable=self.example_audio_var, state="readonly",
            values=list(self.example_audio_paths),
        )
        self.example_audio_combo.grid(row=1, column=5, padx=3, pady=(8, 0), sticky="ew")
        self.example_audio_combo.bind("<<ComboboxSelected>>", self.load_example_reference)
        ttk.Button(source, text="Nghe mẫu", command=self.play_reference).grid(row=1, column=6, padx=4, pady=(8, 0))
        ttk.Button(source, text="Làm mới", command=self.refresh_reference_sources).grid(row=1, column=7, padx=4, pady=(8, 0))
        source.columnconfigure(5, weight=1)

        controls = ttk.Frame(self.story_tab)
        controls.grid(row=1, column=0, columnspan=2, sticky="ew", pady=5)
        ttk.Button(controls, text="Mở TXT", command=self.open_text).pack(side="left", padx=3)
        ttk.Button(controls, text="Mở PDF", command=self.open_pdf).pack(side="left", padx=3)
        ttk.Button(controls, text="✂ Tách câu thông minh", command=self.smart_split_preview).pack(side="left", padx=3)
        ttk.Button(controls, text="🎚 Ngắt nghỉ", command=self.pause_dialog).pack(side="left", padx=3)
        ttk.Checkbutton(controls, text="Tự tách trước khi tạo", variable=self.smart_var).pack(side="left", padx=9)
        ttk.Checkbutton(controls, text="Quality+", variable=self.quality_var).pack(side="left", padx=9)
        ttk.Label(controls, text="Temperature").pack(side="left", padx=(15, 2))
        ttk.Spinbox(controls, from_=0.1, to=1.5, increment=.1, width=5, textvariable=self.temperature_var).pack(side="left")
        ttk.Label(controls, text="Max chars").pack(side="left", padx=(10, 2))
        ttk.Spinbox(controls, from_=128, to=512, increment=32, width=6, textvariable=self.max_chars_var).pack(side="left")

        self.story_text = tk.Text(self.story_tab, wrap="word", undo=True, font=("Segoe UI", 11))
        self.story_text.grid(row=2, column=0, columnspan=2, sticky="nsew")
        self.story_text.insert("1.0", "Xin chào, đây là VieNeu-TTS chạy trực tiếp bằng giao diện Tkinter trên máy của bạn.")
        action = ttk.Frame(self.story_tab)
        action.grid(row=3, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Checkbutton(action, text="Batch Processing", variable=self.use_batch_var).pack(side="left")
        ttk.Label(action, text="Batch size").pack(side="left", padx=(10, 2))
        ttk.Spinbox(action, from_=1, to=32, width=5, textvariable=self.batch_size_var).pack(side="left")
        ttk.Label(action, text="Định dạng").pack(side="left", padx=(15, 2))
        ttk.Combobox(action, textvariable=self.output_format, state="readonly", width=6,
                     values=["wav", "mp3"]).pack(side="left")
        ttk.Button(action, text="▶ Tạo audio", command=self.create_story, style="Accent.TButton").pack(side="right", padx=3)
        ttk.Button(action, text="Nghe kết quả", command=self.play_last).pack(side="right", padx=3)

    def _build_batch(self):
        self.batch_tab.columnconfigure(0, weight=1)
        self.batch_tab.rowconfigure(1, weight=1)
        bar = ttk.Frame(self.batch_tab)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Button(bar, text="Thêm file TXT", command=self.add_batch_files).pack(side="left", padx=3)
        ttk.Button(bar, text="Xóa file chọn", command=self.remove_batch_file).pack(side="left", padx=3)
        ttk.Button(bar, text="▲", command=lambda: self.move_batch(-1)).pack(side="left", padx=2)
        ttk.Button(bar, text="▼", command=lambda: self.move_batch(1)).pack(side="left", padx=2)
        ttk.Label(bar, text="Thư mục xuất:").pack(side="left", padx=(18, 3))
        ttk.Entry(bar, textvariable=self.output_var).pack(side="left", fill="x", expand=True)
        ttk.Button(bar, text="Chọn…", command=self.choose_output).pack(side="left", padx=3)
        self.batch_list = tk.Listbox(self.batch_tab, selectmode="extended", font=("Segoe UI", 10))
        self.batch_list.grid(row=1, column=0, sticky="nsew")
        options = ttk.Frame(self.batch_tab)
        options.grid(row=2, column=0, sticky="ew", pady=8)
        ttk.Checkbutton(options, text="Tách câu thông minh cho từng TXT", variable=self.smart_var).pack(side="left")
        ttk.Checkbutton(options, text="Quality+", variable=self.quality_var).pack(side="left", padx=12)
        ttk.Button(options, text="📚 Bắt đầu xử lý", command=self.start_batch, style="Accent.TButton").pack(side="right")

    def _build_conversation(self):
        self.conversation_tab.columnconfigure(0, weight=3)
        self.conversation_tab.columnconfigure(1, weight=1)
        self.conversation_tab.rowconfigure(1, weight=1)
        ttk.Label(self.conversation_tab, text="Kịch bản — mỗi dòng: Tên nhân vật: Nội dung", style="Heading.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(self.conversation_tab, text="Ánh xạ — mỗi dòng: Nhân vật=Giọng preset", style="Heading.TLabel").grid(row=0, column=1, sticky="w", padx=(10, 0))
        self.conversation_text = tk.Text(self.conversation_tab, wrap="word", font=("Segoe UI", 11))
        self.conversation_text.grid(row=1, column=0, sticky="nsew")
        self.conversation_text.insert("1.0", "Lan: Xin chào mọi người.\nMinh: Chúng ta bắt đầu câu chuyện nhé!")
        self.mapping_text = tk.Text(self.conversation_tab, width=32, font=("Segoe UI", 10))
        self.mapping_text.grid(row=1, column=1, sticky="nsew", padx=(10, 0))
        conv_bar = ttk.Frame(self.conversation_tab)
        conv_bar.grid(row=2, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Button(conv_bar, text="Tự điền nhân vật", command=self.detect_speakers).pack(side="left")
        ttk.Button(conv_bar, text="🎭 Tạo hội thoại", command=self.create_conversation, style="Accent.TButton").pack(side="right")

    def _build_voices(self):
        self.voices_tab.columnconfigure(0, weight=1)
        self.voices_tab.rowconfigure(1, weight=1)
        bar = ttk.Frame(self.voices_tab)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(bar, text="Làm mới", command=self.refresh_voices).pack(side="left", padx=3)
        ttk.Button(bar, text="Lưu audio mẫu thành giọng", command=self.save_voice_dialog).pack(side="left", padx=3)
        ttk.Button(bar, text="Xóa giọng người dùng", command=self.delete_voice_dialog).pack(side="left", padx=3)
        self.voice_list = tk.Listbox(self.voices_tab, font=("Segoe UI", 10))
        self.voice_list.grid(row=1, column=0, sticky="nsew")

    def _build_log(self):
        self.log_tab.columnconfigure(0, weight=1)
        self.log_tab.rowconfigure(0, weight=1)
        self.log_text = tk.Text(self.log_tab, wrap="word", state="disabled", font=("Consolas", 9))
        self.log_text.grid(row=0, column=0, sticky="nsew")
        ttk.Button(self.log_tab, text="Xóa màn hình log", command=self.clear_log).grid(row=1, column=0, sticky="e", pady=5)

    def log(self, message):
        stamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"[{stamp}] {message}\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _post(self, kind, value=None):
        self.events.put((kind, value))

    def _poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "status":
                    self.status_var.set(value); self.log(value)
                elif kind == "progress":
                    self.progress_var.set(value)
                elif kind == "loaded":
                    self._finish_busy(); self.model_status.set("Đã tải model")
                    self._set_voices(value); self.log(f"Đã tải {len(value)} giọng")
                elif kind == "audio":
                    self.last_audio = value; self._finish_busy(); self.status_var.set(f"Hoàn tất: {value}")
                    self.log(f"Đã lưu: {value}")
                elif kind == "last_audio":
                    self.last_audio = value
                elif kind == "done":
                    self._finish_busy(); self.status_var.set(value or "Hoàn tất")
                elif kind == "error":
                    self._finish_busy(); self.status_var.set("Có lỗi")
                    self.log(value); messagebox.showerror("VieNeu-TTS", value)
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _run(self, function):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Đang bận", "Ứng dụng đang xử lý một tác vụ.")
            return
        self.stop_event.clear(); self.started_at = time.time(); self.stop_button.configure(state="normal")
        self.load_button.configure(state="disabled"); self.progress_var.set(0)
        def runner():
            try:
                function()
            except InterruptedError as exc:
                self._post("done", str(exc))
            except Exception as exc:
                traceback.print_exc()
                self._post("error", f"{type(exc).__name__}: {exc}")
        self.worker = threading.Thread(target=runner, daemon=True)
        self.worker.start()

    def _finish_busy(self):
        self.stop_button.configure(state="disabled")
        self.load_button.configure(state="normal")
        self.progress_var.set(100)

    def stop(self):
        self.stop_event.set(); self.status_var.set("Đã yêu cầu dừng; sẽ dừng sau lượt hiện tại")

    def load_model(self):
        model = self.model_var.get()
        device = self.device_var.get()
        precision = self.precision_var.get()
        batch_size = self.batch_size_var.get()
        def work():
            self._post("status", "Đang tải model...")
            voices = self.engine.load(model, device, precision, batch_size)
            self._post("loaded", voices)
        self._run(work)

    def _set_voices(self, voices):
        self.voice_combo["values"] = voices
        if voices and self.voice_var.get() not in voices:
            self.voice_var.set(voices[0])
        self.refresh_voices()

    def refresh_voices(self):
        self.voice_list.delete(0, "end")
        for name in self.engine.voices():
            mark = "👤 " if name in self.engine.user_voices() else "🎙 "
            self.voice_list.insert("end", mark + name)

    def choose_reference(self):
        path = filedialog.askopenfilename(filetypes=[("Audio", "*.wav *.mp3 *.flac *.m4a"), ("Tất cả", "*.*")])
        if path:
            self.ref_var.set(path)
            self.mode_var.set("clone")

    def _use_reference(self, path, label):
        if path and Path(path).is_file():
            self.ref_var.set(str(path))
            self.mode_var.set("clone")
            self.status_var.set(f"Đã nạp audio mẫu: {label}")

    def load_trained_reference(self, _event=None):
        name = self.trained_voice_var.get()
        self._use_reference(self.trained_voice_paths.get(name), f"giọng train {name}")

    def load_example_reference(self, _event=None):
        name = self.example_audio_var.get()
        self._use_reference(self.example_audio_paths.get(name), name)

    def refresh_reference_sources(self):
        self.trained_voice_paths = trained_voice_samples()
        self.example_audio_paths = clone_audio_examples()
        self.trained_voice_combo["values"] = list(self.trained_voice_paths)
        self.example_audio_combo["values"] = list(self.example_audio_paths)
        self.status_var.set(
            f"Tìm thấy {len(self.trained_voice_paths)} giọng train và "
            f"{len(self.example_audio_paths)} audio mẫu"
        )

    def play_reference(self):
        path = self.ref_var.get()
        if path and Path(path).is_file():
            os.startfile(path)
        else:
            messagebox.showinfo("Audio mẫu", "Chưa chọn audio mẫu để nghe.")

    def choose_output(self):
        path = filedialog.askdirectory(initialdir=self.output_var.get() or None)
        if path: self.output_var.set(path)

    def open_text(self):
        path = filedialog.askopenfilename(filetypes=[("Text", "*.txt")])
        if path:
            try:
                text = read_txt(path); self.story_text.delete("1.0", "end"); self.story_text.insert("1.0", text)
            except Exception as exc: messagebox.showerror("TXT", str(exc))

    def open_pdf(self):
        path = filedialog.askopenfilename(filetypes=[("PDF", "*.pdf")])
        if not path: return
        try:
            import fitz
            doc = fitz.open(path); text = "\n".join(page.get_text() for page in doc)
            self.story_text.delete("1.0", "end"); self.story_text.insert("1.0", text)
        except Exception as exc: messagebox.showerror("PDF", str(exc))

    def smart_split_preview(self):
        text = self.story_text.get("1.0", "end-1c")
        prepared, segments = analyze_text(text, True, self.max_chars_var.get())
        self.story_text.delete("1.0", "end"); self.story_text.insert("1.0", prepared)
        self.status_var.set(f"Đã tách thành {len(segments)} câu hoàn chỉnh")

    def pause_dialog(self):
        dialog = tk.Toplevel(self); dialog.title("Thiết lập ngắt nghỉ"); dialog.transient(self); dialog.grab_set()
        labels = {"dot":"Dấu chấm .", "comma":"Dấu phẩy ,", "question":"Dấu hỏi ?",
                  "exclamation":"Chấm than !", "colon":"Dấu hai chấm :", "semicolon":"Chấm phẩy ;",
                  "ellipsis":"Dấu ba chấm …", "newline":"Xuống dòng ↵"}
        ttk.Label(dialog, text="Xuống dòng thật và dấu chấm được giữ thành hai loại riêng.").grid(row=0, column=0, columnspan=4, padx=14, pady=10)
        for row, (key, label) in enumerate(labels.items(), 1):
            ttk.Label(dialog, text=label, width=20).grid(row=row, column=0, padx=8, pady=4, sticky="w")
            ttk.Button(dialog, text="−", width=3, command=lambda k=key: self.pause_vars[k].set(max(0, round(self.pause_vars[k].get()-.05, 2)))).grid(row=row, column=1)
            ttk.Spinbox(dialog, from_=0, to=3, increment=.05, width=7, textvariable=self.pause_vars[key]).grid(row=row, column=2, padx=4)
            ttk.Button(dialog, text="+", width=3, command=lambda k=key: self.pause_vars[k].set(min(3, round(self.pause_vars[k].get()+.05, 2)))).grid(row=row, column=3)
        buttons = ttk.Frame(dialog); buttons.grid(row=10, column=0, columnspan=4, pady=12)
        ttk.Button(buttons, text="Đặt mặc định", command=lambda: [self.pause_vars[k].set(v) for k,v in DEFAULTS["pauses"].items()]).pack(side="left", padx=5)
        ttk.Button(buttons, text="Xong", command=dialog.destroy, style="Accent.TButton").pack(side="left", padx=5)

    def _pauses(self): return {key: float(var.get()) for key, var in self.pause_vars.items()}

    def _source_kwargs(self):
        clone = self.mode_var.get() == "clone"
        if clone and not self.ref_var.get(): raise ValueError("Hãy chọn audio mẫu để clone")
        return dict(voice=None if clone else self.voice_var.get(), ref_audio=self.ref_var.get() if clone else None)

    def _generation_snapshot(self, include_source=True):
        """Read every Tk value on the UI thread before background synthesis starts."""
        result = {
            "denoise": bool(self.denoise_var.get()),
            "temperature": float(self.temperature_var.get()),
            "max_chars": int(self.max_chars_var.get()),
            "use_batch": bool(self.use_batch_var.get()),
            "batch_size": int(self.batch_size_var.get()),
            "pauses": self._pauses(),
            "quality": bool(self.quality_var.get()),
        }
        if include_source:
            result.update(self._source_kwargs())
        return result

    def create_story(self):
        text = self.story_text.get("1.0", "end-1c")
        try:
            options = self._generation_snapshot()
        except ValueError as exc:
            messagebox.showinfo("Nguồn giọng", str(exc))
            return
        smart = bool(self.smart_var.get())
        output_dir = Path(self.output_var.get())
        output_format = self.output_format.get()
        def work():
            prepared = text
            if smart: prepared, _ = analyze_text(prepared, True, options["max_chars"])
            wav = self.engine.synthesize(prepared, **options, stop_event=self.stop_event,
                progress=lambda m: self._post("status", m))
            path = output_dir / f"vieneu_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{output_format}"
            self.engine.save_audio(path, wav)
            if options["quality"] and hasattr(self.engine, "last_quality_report"):
                Path(str(path)+".quality.json").write_text(json.dumps(self.engine.last_quality_report, ensure_ascii=False, indent=2), encoding="utf-8")
            self._post("audio", str(path))
        self._run(work)

    def play_last(self):
        if self.last_audio and Path(self.last_audio).exists(): os.startfile(self.last_audio)
        else: messagebox.showinfo("Audio", "Chưa có kết quả để nghe.")

    def add_batch_files(self):
        paths = filedialog.askopenfilenames(filetypes=[("Text", "*.txt")])
        for path in paths:
            if path not in self.batch_files:
                self.batch_files.append(path); self.batch_list.insert("end", path)

    def remove_batch_file(self):
        for index in reversed(self.batch_list.curselection()):
            self.batch_list.delete(index); self.batch_files.pop(index)

    def move_batch(self, delta):
        selected = self.batch_list.curselection()
        if len(selected) != 1: return
        old = selected[0]; new = max(0, min(len(self.batch_files)-1, old+delta))
        if new == old: return
        item = self.batch_files.pop(old); self.batch_files.insert(new, item)
        self.batch_list.delete(old); self.batch_list.insert(new, item); self.batch_list.selection_set(new)

    def start_batch(self):
        files = list(self.batch_files)
        if not files:
            messagebox.showinfo("TXT hàng loạt", "Chưa chọn file TXT")
            return
        try:
            options = self._generation_snapshot()
        except ValueError as exc:
            messagebox.showinfo("Nguồn giọng", str(exc))
            return
        smart = bool(self.smart_var.get())
        output = Path(self.output_var.get())
        output_format = self.output_format.get()
        def work():
            output.mkdir(parents=True, exist_ok=True)
            seen = {}; completed = 0
            for index, source in enumerate(files):
                if self.stop_event.is_set(): raise InterruptedError("Đã dừng hàng đợi")
                src = Path(source); count = seen.get(src.name.casefold(), 0); seen[src.name.casefold()] = count + 1
                folder = output if count == 0 else output / src.parent.name
                target = folder / (src.stem + "." + output_format)
                self._post("status", f"File {index+1}/{len(files)}: {src.name}")
                try:
                    text = read_txt(src)
                    if smart: text, _ = analyze_text(text, True, options["max_chars"])
                    wav = self.engine.synthesize(text, **options, stop_event=self.stop_event,
                        progress=lambda m, n=src.name: self._post("status", f"{n}: {m}"))
                    self.engine.save_audio(target, wav); completed += 1
                    self._post("last_audio", str(target))
                    if options["quality"] and hasattr(self.engine, "last_quality_report"):
                        Path(str(target)+".quality.json").write_text(json.dumps(self.engine.last_quality_report, ensure_ascii=False, indent=2), encoding="utf-8")
                except InterruptedError: raise
                except Exception as exc: self._post("status", f"Lỗi {src.name}: {exc}; tiếp tục file sau")
                self._post("progress", (index+1)*100/len(files))
            self._post("done", f"Hoàn thành {completed}/{len(files)} file tại {output}")
        self._run(work)

    def detect_speakers(self):
        lines = parse_conversation(self.conversation_text.get("1.0", "end-1c")); names=[]
        for name, _ in lines:
            if name not in names: names.append(name)
        voices = self.engine.voices(); self.mapping_text.delete("1.0", "end")
        self.mapping_text.insert("1.0", "\n".join(f"{n}={voices[i%len(voices)] if voices else ''}" for i,n in enumerate(names)))

    def create_conversation(self):
        lines = parse_conversation(self.conversation_text.get("1.0", "end-1c"))
        mapping = parse_voice_mapping(self.mapping_text.get("1.0", "end-1c"))
        if not lines:
            messagebox.showinfo("Hội thoại", "Kịch bản hội thoại đang trống")
            return
        options = self._generation_snapshot(include_source=False)
        fallback_voice = self.voice_var.get()
        output_dir = Path(self.output_var.get())
        def work():
            wavs=[]; sr=self.engine.tts.sample_rate
            for index,(speaker,text) in enumerate(lines):
                if self.stop_event.is_set(): raise InterruptedError("Đã dừng hội thoại")
                voice=mapping.get(speaker) or fallback_voice
                self._post("status", f"{speaker}: đoạn {index+1}/{len(lines)}")
                line_options = dict(options)
                line_options.update(voice=voice, ref_audio=None, quality=False)
                wavs.append(self.engine.synthesize(text, **line_options, stop_event=self.stop_event))
                if index < len(lines)-1: wavs.append(np.zeros(int(sr*.55), dtype=np.float32))
                self._post("progress", (index+1)*100/len(lines))
            wav=np.concatenate(wavs); path=output_dir/f"hoai_thoai_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
            self.engine.save_audio(path,wav); self._post("audio",str(path))
        self._run(work)

    def save_voice_dialog(self):
        if not self.engine.loaded: messagebox.showinfo("Giọng", "Hãy tải model trước."); return
        audio = self.ref_var.get() or filedialog.askopenfilename(filetypes=[("Audio", "*.wav *.mp3 *.flac")])
        if not audio: return
        name = simpledialog.askstring("Lưu giọng", "Tên giọng mới:", parent=self)
        if not name: return
        denoise = bool(self.denoise_var.get())
        def work():
            result=self.engine.save_voice(name,audio,denoise); self._post("loaded",self.engine.voices()); self._post("status",f"Đã lưu giọng {result}")
        self._run(work)

    def delete_voice_dialog(self):
        selection=self.voice_list.curselection()
        if not selection: return
        name=self.voice_list.get(selection[0]).replace("👤 ","").replace("🎙 ","")
        if messagebox.askyesno("Xóa giọng", f"Xóa giọng người dùng '{name}'?"):
            try: self.engine.delete_voice(name); self._set_voices(self.engine.voices())
            except Exception as exc: messagebox.showerror("Xóa giọng",str(exc))

    def _collect_config(self):
        return {"model":self.model_var.get(),"device":self.device_var.get(),"precision":self.precision_var.get(),
                "temperature":self.temperature_var.get(),"max_chars":self.max_chars_var.get(),
                "batch_size":self.batch_size_var.get(),"use_batch":self.use_batch_var.get(),
                "denoise":self.denoise_var.get(),"smart_split":self.smart_var.get(),
                "quality_plus":self.quality_var.get(),"output_dir":self.output_var.get(),
                "pauses":self._pauses(),"geometry":self.geometry()}

    def _on_close(self):
        self.stop_event.set(); save_config(self._collect_config()); self.destroy()


def main():
    app = VieNeuDesktop()
    app.mainloop()

