from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from apps.text_processing import smart_reformat_script
from vieneu_utils.core_utils import split_text_blocks_with_boundaries, split_into_sentences, _classify_gap


@dataclass
class Segment:
    text: str
    boundary_after: str = "none"
    source_line: int = 0
    artificial_break: bool = False


def analyze_text(text: str, smart: bool = False, max_chars: int = 224) -> tuple[str, list[Segment]]:
    prepared = smart_reformat_script(text, max_chars=max_chars) if smart else text
    blocks, boundaries = split_text_blocks_with_boundaries(prepared)
    segments: list[Segment] = []
    for block_index, block in enumerate(blocks):
        sentences = split_into_sentences(block) or [block]
        for sentence_index, sentence in enumerate(sentences):
            segments.append(Segment(sentence.strip(), source_line=block_index + 1))
            if len(segments) > 1:
                previous = segments[-2]
                if sentence_index == 0:
                    boundary = boundaries[block_index - 1]
                    previous.boundary_after = "newline" if boundary == "newline" else _classify_gap(previous.text)
                    previous.artificial_break = boundary == "smart"
                else:
                    previous.boundary_after = _classify_gap(previous.text)
    return prepared, [item for item in segments if item.text]


def parse_conversation(script: str) -> list[tuple[str, str]]:
    lines: list[tuple[str, str]] = []
    for raw in script.splitlines():
        raw = raw.strip()
        if not raw:
            continue
        match = re.match(r"^([^:：]{1,60})[:：]\s*(.+)$", raw)
        if match:
            lines.append((match.group(1).strip(), match.group(2).strip()))
        elif lines:
            name, old = lines[-1]
            lines[-1] = (name, old + " " + raw)
        else:
            lines.append(("Người kể", raw))
    return lines


def parse_voice_mapping(text: str) -> dict[str, str]:
    result = {}
    for raw in text.splitlines():
        if "=" in raw:
            speaker, voice = raw.split("=", 1)
            if speaker.strip() and voice.strip():
                result[speaker.strip()] = voice.strip()
    return result


def read_txt(path: str | Path) -> str:
    data = Path(path).read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "utf-16", "cp1258"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError("Không đọc được TXT bằng UTF-8, UTF-16 hoặc CP1258")

