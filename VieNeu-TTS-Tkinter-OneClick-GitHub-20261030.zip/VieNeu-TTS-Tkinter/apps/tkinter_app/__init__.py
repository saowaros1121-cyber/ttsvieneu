"""Native Tkinter desktop UI for VieNeu-TTS."""

APP_NAME = "VieNeu-TTS Desktop"

