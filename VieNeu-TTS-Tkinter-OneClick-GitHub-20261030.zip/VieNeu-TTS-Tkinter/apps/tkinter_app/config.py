from __future__ import annotations

import json
import os
from copy import deepcopy
from pathlib import Path

DEFAULTS = {
    "model": "VieNeu-TTS v3 Turbo",
    "device": "Auto",
    "precision": "fp32",
    "temperature": 0.4,
    "max_chars": 224,
    "batch_size": 16,
    "use_batch": True,
    "denoise": True,
    "smart_split": True,
    "quality_plus": False,
    "output_dir": str(Path.cwd() / "outputs" / "tkinter"),
    "pauses": {
        "dot": 0.75, "comma": 0.40, "question": 0.80,
        "exclamation": 0.80, "colon": 0.40, "semicolon": 0.40,
        "ellipsis": 0.90, "newline": 1.10,
    },
    "geometry": "1320x820",
}


def config_path() -> Path:
    root = Path(os.environ.get("VIENEU_HOME") or (Path.home() / ".vieneu"))
    return root / "tkinter_config.json"


def load_config() -> dict:
    result = deepcopy(DEFAULTS)
    path = config_path()
    if not path.is_file():
        return result
    try:
        saved = json.loads(path.read_text(encoding="utf-8"))
        for key, value in saved.items():
            if key == "pauses" and isinstance(value, dict):
                result["pauses"].update(value)
            elif key in result:
                result[key] = value
    except Exception:
        try:
            path.replace(path.with_suffix(".broken.json"))
        except OSError:
            pass
    return result


def save_config(config: dict) -> Path:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)
    return path

