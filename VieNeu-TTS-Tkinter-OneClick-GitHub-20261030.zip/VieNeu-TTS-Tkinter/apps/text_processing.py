"""Shared text preparation for manual and batch speech generation."""
import logging

logger = logging.getLogger(__name__)


def smart_reformat_script(text: str, max_chars: int = 400) -> str:
    """Tự động tách script thành các đoạn để TTS đọc liền mạch.

    Thuật toán:
    1. Tách văn bản thành câu hoàn chỉnh dựa trên dấu . ! ? …
    2. Gộp các câu ngắn liền kề lại (greedy) miễn không vượt max_chars.
    3. Trả về văn bản với mỗi nhóm câu trên 1 dòng riêng (\n).

    Kết quả: mỗi dòng = một nhóm câu để đưa vào bộ chia chunk TTS.
    Điểm ngắt luôn nằm SAU dấu kết câu ``. ! ? …`` hoặc tại xuống dòng gốc.
    Câu đơn lẻ quá dài vẫn được giữ nguyên, có thể vượt ``max_chars``; tuyệt đối
    không chặt câu ở giữa chỉ để đạt giới hạn ký tự.
    """
    from vieneu_utils.core_utils import (
        SMART_SPLIT_BREAK,
        split_into_sentences,
        split_text_blocks_with_boundaries,
    )

    if not text or not text.strip():
        return text

    # Khôi phục các block nguồn. Nếu bấm nút nhiều lần, newline vô hình do lần
    # tách trước tạo ra được nối lại; newline gốc của người dùng vẫn được giữ.
    blocks, boundaries = split_text_blocks_with_boundaries(text.strip())
    source_blocks: list[str] = []
    if blocks:
        current = blocks[0]
        for boundary, block in zip(boundaries, blocks[1:]):
            if boundary == "smart":
                current = f"{current} {block}".strip()
            else:
                source_blocks.append(current)
                current = block
        source_blocks.append(current)

    formatted_blocks: list[str] = []
    total_groups = 0

    for block in source_blocks:
        block = block.strip()
        if not block:
            continue

        sentences = split_into_sentences(block)
        if not sentences:
            continue

        block_groups: list[str] = []
        # Gộp câu greedy: thêm vào nhóm hiện tại nếu còn vừa
        current_group = ""
        for sent in sentences:
            sent = sent.strip()
            if not sent:
                continue
            candidate = (current_group + " " + sent).strip() if current_group else sent
            if len(candidate) <= max_chars:
                current_group = candidate
            else:
                if current_group:
                    block_groups.append(current_group)
                # Câu đơn lẻ quá dài: vẫn giữ nguyên (không cắt giữa câu)
                current_group = sent

        if current_group:
            block_groups.append(current_group)

        if block_groups:
            # Chỉ newline do tool tạo mới mang marker. Newline giữa hai block
            # nguồn không có marker nên engine hiểu đúng là "xuống dòng".
            formatted_blocks.append((SMART_SPLIT_BREAK + "\n").join(block_groups))
            total_groups += len(block_groups)

    result = "\n".join(formatted_blocks)
    n_groups = total_groups
    visible_groups = [
        group.replace(SMART_SPLIT_BREAK, "")
        for block in formatted_blocks
        for group in block.splitlines()
        if group.strip()
    ]
    oversized = sum(len(group) > max_chars for group in visible_groups)
    logger.debug(
        "Smart split: %s groups, max_chars=%s, complete sentences over limit=%s",
        n_groups,
        max_chars,
        oversized,
    )
    return result
