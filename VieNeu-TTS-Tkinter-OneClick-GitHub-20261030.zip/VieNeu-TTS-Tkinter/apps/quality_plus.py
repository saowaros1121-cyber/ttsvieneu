"""Opt-in, local v3 Turbo candidate verification and audio assembly."""
import json
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly
from math import gcd

from vieneu_utils.core_utils import (
    split_text_blocks_with_boundaries, split_into_sentences, _classify_gap,
    gaps_to_silence, join_audio_chunks,
)


def words(text):
    text = re.sub(r"<\|[^>]+\|>|\[[^]]+\]", " ", text)
    return re.findall(r"\w+", unicodedata.normalize("NFC", text).casefold())


def word_error(expected, actual):
    a, b = words(expected), words(actual)
    row = list(range(len(b) + 1))
    for i, word in enumerate(a, 1):
        nxt = [i]
        for j, other in enumerate(b, 1):
            nxt.append(min(nxt[-1] + 1, row[j] + 1, row[j-1] + (word != other)))
        row = nxt
    return row[-1] / max(1, len(a))


@lru_cache(maxsize=1)
def recognizer():
    # Reuse installed checkpoint. CPU avoids competing with TTS for VRAM.
    from huggingface_hub import snapshot_download
    from transformers import pipeline, AutoModelForSpeechSeq2Seq, AutoProcessor
    folder = snapshot_download("openai/whisper-large-v3-turbo", local_files_only=True)
    model = AutoModelForSpeechSeq2Seq.from_pretrained(folder, local_files_only=True)
    processor = AutoProcessor.from_pretrained(folder, local_files_only=True)
    return pipeline("automatic-speech-recognition", model=model,
                    tokenizer=processor.tokenizer, feature_extractor=processor.feature_extractor,
                    device=-1)


def transcribe(wav, sr):
    divisor = gcd(int(sr), 16000)
    audio = resample_poly(wav, 16000 // divisor, int(sr) // divisor).astype(np.float32)
    return recognizer()({"raw": audio, "sampling_rate": 16000},
                        generate_kwargs={"task": "transcribe", "do_sample": False})["text"].strip()


def prepare_reference(path):
    """Choose an active, low-clipping window <=8s; this is a heuristic, not MOS."""
    wav, sr = sf.read(path, dtype="float32", always_2d=True)
    wav = wav.mean(axis=1)
    if not np.isfinite(wav).all() or len(wav) < 3 * sr:
        raise ValueError("Quality+: audio mẫu cần ít nhất 3 giây, không chứa dữ liệu lỗi.")
    win = max(1, int(sr * .02))
    frames = wav[:len(wav)//win*win].reshape(-1, win)
    energy = np.sqrt(np.mean(frames ** 2, axis=1))
    threshold = max(.002, float(energy.max()) * .06)
    active = np.flatnonzero(energy > threshold)
    if not len(active):
        raise ValueError("Quality+: audio mẫu quá nhỏ hoặc chỉ có im lặng.")
    start = max(0, int(active[0] * win - .08 * sr))
    end = min(len(wav), int((active[-1] + 1) * win + .08 * sr))
    wav = wav[start:end]
    if len(wav) > 8 * sr:
        size = 8 * sr
        candidates = list(range(0, len(wav) - size + 1, max(1, sr // 2)))
        candidates.append(len(wav) - size)
        def score(i):
            part = wav[i:i+size]
            return np.mean(np.abs(part) > threshold) - 4 * np.mean(np.abs(part) >= .99)
        start = max(candidates, key=score)
        wav = wav[start:start+size]
    rms = float(np.sqrt(np.mean(wav ** 2)))
    wav *= min(.1 / max(rms, 1e-6), .95 / max(float(np.max(np.abs(wav))), 1e-6))
    return wav, sr


def duration_chunks(text, rate=4.0):
    """Keep whole sentences and original newlines. Target 8–15s when feasible.

    Never merge across punctuation pauses: short sentences stay short; long
    sentences stay intact and are reported to the user instead of being cut.
    """
    blocks, boundaries = split_text_blocks_with_boundaries(text)
    chunks, gaps = [], []
    for i, block in enumerate(blocks):
        sentences = split_into_sentences(block)
        for j, sentence in enumerate(sentences):
            if chunks:
                gaps.append("newline" if j == 0 and i and boundaries[i-1] == "newline"
                            else _classify_gap(chunks[-1]))
            chunks.append(sentence)
    return chunks, gaps, [len(words(c)) / max(1., rate) for c in chunks]


def polish(wav, sr):
    wav = np.asarray(wav, dtype=np.float32).reshape(-1).copy()
    if not len(wav) or not np.isfinite(wav).all():
        raise ValueError("Audio rỗng hoặc không hợp lệ")
    # Moderate gain from speech-only samples, bounded to ±6 dB. Preserve silences.
    peak = float(np.max(np.abs(wav)))
    speech = wav[np.abs(wav) > max(.001, peak * .03)]
    rms = float(np.sqrt(np.mean(speech ** 2))) if len(speech) else 0.
    gain = np.clip(.1 / max(rms, 1e-6), .5, 2.)
    wav *= min(gain, .97 / max(peak, 1e-6))
    n = min(int(sr * .005), len(wav) // 2)
    if n:
        ramp = np.linspace(0, 1, n, dtype=np.float32)
        wav[:n] *= ramp
        wav[-n:] *= ramp[::-1]
    return wav


class QualitySession:
    def __init__(self, tts, anchor, ref_codes, stop_event, rate=4.):
        self.tts, self.anchor, self.ref_codes = tts, np.asarray(anchor).reshape(-1), ref_codes
        self.stop = stop_event
        self.rate = rate
        self.report = []

    def generate(self, text, temperature, pauses):
        from vieneu_utils.phonemize_text import normalize_to_chunks_v3_with_gaps, phonemize_text_with_emotions
        import torch
        chunks, gaps, durations = duration_chunks(text, self.rate)
        self.report = []
        selected = []
        sr = self.tts.sample_rate
        for index, (chunk, duration) in enumerate(zip(chunks, durations)):
            if self.stop.is_set():
                return
            # Normalize a complete sentence without fragmenting it at a char limit.
            normalized, _ = normalize_to_chunks_v3_with_gaps(chunk, max_chars=100000, min_chunk_chars=0)
            expected = " ".join(normalized)
            phones = phonemize_text_with_emotions(expected)
            if len(phones) > 650:
                raise ValueError(f"Quality+: câu {index+1} quá dài cho ngữ cảnh model. Hãy thêm dấu chấm; câu chưa bị cắt giữa chừng.")
            attempts = []
            candidates = []
            for attempt in range(3):
                if self.stop.is_set():
                    return
                yield None, f"Quality+: đoạn {index+1}/{len(chunks)}, bản {attempt+1}/3; ước tính {duration:.1f}s."
                wav = self.tts.engine.infer(phonemes=phones, speaker_emb=self.anchor,
                    ref_codes=self.ref_codes, use_ref_codes=True, temperature=temperature,
                    max_new_frames=min(600, max(300, int(duration * 20))))
                if self.stop.is_set():
                    return
                wav = np.asarray(wav, dtype=np.float32).reshape(-1)
                if not len(wav) or not np.isfinite(wav).all() or np.max(np.abs(wav)) < 1e-5:
                    attempts.append({"attempt": attempt+1, "error": "empty/invalid/silent audio"})
                    continue
                heard = transcribe(wav, sr)
                error = word_error(expected, heard)
                emb = self.tts.engine.extract_speaker_emb(torch.from_numpy(wav), sr=sr)
                emb = np.asarray(emb).reshape(-1)
                similarity = float(np.dot(emb, self.anchor) / max(1e-8, np.linalg.norm(emb)*np.linalg.norm(self.anchor)))
                clipping = float(np.mean(np.abs(wav) >= .99))
                score = error + .25 * (1 - similarity) + clipping
                attempts.append(dict(attempt=attempt+1, transcript=heard, word_error=error,
                                     similarity=similarity, clipping=clipping, score=score))
                candidates.append((score, wav, attempts[-1]))
                # Always compare two; third is only needed if both look suspect.
                if attempt >= 1:
                    best_metrics = min(candidates, key=lambda c: c[0])[2]
                    if best_metrics["word_error"] <= .12 and best_metrics["similarity"] >= .55:
                        break
            if not candidates:
                raise ValueError(f"Quality+: cả 3 bản của đoạn {index+1} đều lỗi.")
            _, best, metrics = min(candidates, key=lambda c: c[0])
            suspect = metrics["word_error"] > .2 or metrics["similarity"] < .55
            self.report.append(dict(segment=index+1, text=chunk, estimated_seconds=duration,
                                    selected=metrics["attempt"], suspect=suspect, attempts=attempts))
            selected.append(polish(best, sr))
        if self.stop.is_set():
            return
        wav = join_audio_chunks(selected, sr=sr, silence_ps=gaps_to_silence(gaps, pauses))
        count = sum(r["suspect"] for r in self.report)
        yield wav, f"Quality+: đã chọn {len(selected)} đoạn; {count} đoạn cần nghe kiểm tra. Điểm ASR/giọng chỉ là ước lượng."

    def save_report(self, audio_path):
        Path(str(audio_path) + ".quality.json").write_text(
            json.dumps(self.report, ensure_ascii=False, indent=2), encoding="utf-8")
